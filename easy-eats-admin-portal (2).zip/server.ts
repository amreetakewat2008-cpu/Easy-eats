import "dotenv/config";
import crypto from "crypto";
import { EventEmitter } from "events";
import express, { type NextFunction, type Request, type Response } from "express";
import fs from "fs";
import multer from "multer";
import path from "path";
import { fileURLToPath } from "url";
import { createServer as createViteServer } from "vite";
import { z } from "zod";
import {
  PAYMENT_WEBHOOK_SECRET,
  blindIndex,
  decrypt,
  encrypt,
  hashPassword,
  hashPasswordSync,
  safeEqual,
  sha256,
  signJwt,
  verifyJwt,
  verifyPassword,
} from "./server/crypto";
import { db } from "./server/db";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// ============================================================
// BUSINESS RULES & CONSTANTS (Money = integer paise)
// ============================================================
const RULES = {
  deliveryFeePaise: 3000,
  freeDeliveryAbovePaise: 49900,
  codMaxPaise: 150000,
  codMinDeliveredOrders: 2,
  codMaxRecentFailures: 2,
  highValuePaise: 300000,
  reviewScoreAt: 70,
  maxOrdersPerHour: 5,
  maxUnpaidOrders: 3,
  maxWrongOtp: 5,
  acceptTimeoutMin: 5,
};

const STAFF = ["super_admin", "restaurant_manager", "marketing_lead", "customer_support"] as const;
const ORDER_STAFF = ["super_admin", "restaurant_manager"] as const;
const ORDER_VIEW = [...ORDER_STAFF, "customer_support"] as const;
const CRM = ["super_admin", "customer_support"] as const;
const MARKETING = ["super_admin", "marketing_lead"] as const;
const OWNER = ["super_admin"] as const;

type StaffRole = (typeof STAFF)[number];
type UserRole = StaffRole | "customer" | "rider";

interface AuthedRequest extends Request {
  user?: { id: string; role: UserRole; name: string };
}

class HttpError extends Error {
  status: number;
  constructor(status: number, message: string) {
    super(message);
    this.status = status;
  }
}

const wrap =
  (fn: (req: AuthedRequest, res: Response, next: NextFunction) => Promise<unknown> | unknown) =>
  (req: Request, res: Response, next: NextFunction) => {
    Promise.resolve(fn(req as AuthedRequest, res, next)).catch(next);
  };

const bus = new EventEmitter();
bus.setMaxListeners(100);

const PHONE = z.string().regex(/^[6-9]\d{9}$/, "Enter a 10-digit Indian mobile number");
const UUID = z.string().uuid();
const DUMMY_HASH = hashPasswordSync("not-a-real-password-timing-guard");

const UPLOAD_DIR = path.resolve(process.env.UPLOAD_DIR || "./uploads");
fs.mkdirSync(UPLOAD_DIR, { recursive: true });

// ============================================================
// HELPERS
// ============================================================
function audit(req: Request | null, userId: string | null | undefined, action: string, detail: Record<string, unknown> = {}) {
  try {
    db.prepare("INSERT INTO audit_log (user_id, action, detail, ip) VALUES (?, ?, ?, ?)").run(
      userId ?? null,
      action,
      JSON.stringify(detail),
      req?.ip ?? null
    );
  } catch {
    // Audit logging must not break responses
  }
}

function maskPhone(phone: string): string {
  return "XXXXXX" + phone.slice(-4);
}

function parseJsonArray(raw: string | null | undefined): string[] {
  if (!raw) return [];
  try {
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

function publicOrder(o: Record<string, any>) {
  return {
    id: o.id,
    status: o.status,
    paymentMethod: o.payment_method,
    paid: Boolean(o.paid),
    subtotalPaise: o.subtotal_paise,
    discountPaise: o.discount_paise,
    deliveryPaise: o.delivery_paise,
    totalPaise: o.total_paise,
    createdAt: o.created_at,
    placedAt: o.placed_at,
    rejectReason: o.reject_reason,
  };
}

function orderCard(id: string) {
  const o = db
    .prepare(
      `SELECT o.*, u.name AS customer_name, r.name AS rider_name
       FROM orders o
       JOIN users u ON u.id = o.user_id
       LEFT JOIN users r ON r.id = o.rider_id
       WHERE o.id = ?`
    )
    .get(id) as Record<string, any> | undefined;
  if (!o) return null;
  const items = db
    .prepare('SELECT name, qty, unit_price_paise AS "unitPricePaise" FROM order_items WHERE order_id = ?')
    .all(id);
  const expiresAt =
    o.placed_at && o.status === "placed"
      ? new Date(new Date(o.placed_at).getTime() + RULES.acceptTimeoutMin * 60_000).toISOString()
      : null;

  return {
    ...publicOrder(o),
    customerName: o.customer_name,
    riderName: o.rider_name || null,
    items,
    address: decrypt(o.address_enc),
    riskScore: o.risk_score,
    riskFlags: parseJsonArray(o.risk_flags),
    expiresAt,
  };
}

// Sliding-window rate limiter
function createRateLimiter(windowMs: number, limit: number) {
  const hits = new Map<string, number[]>();
  return (req: Request, res: Response, next: NextFunction) => {
    const ip = req.ip || "unknown";
    const now = Date.now();
    const list = (hits.get(ip) || []).filter((ts) => now - ts < windowMs);
    if (list.length >= limit) {
      res.status(429).json({ error: "Too many requests. Please slow down." });
      return;
    }
    list.push(now);
    hits.set(ip, list);
    next();
  };
}

// Detect valid image magic bytes
function detectImageExt(buf: Buffer): string | null {
  if (buf.length < 12) return null;
  if (buf[0] === 0x89 && buf[1] === 0x50 && buf[2] === 0x4e && buf[3] === 0x47) return "png";
  if (buf[0] === 0xff && buf[1] === 0xd8 && buf[2] === 0xff) return "jpg";
  if (buf.subarray(0, 4).toString("ascii") === "RIFF" && buf.subarray(8, 12).toString("ascii") === "WEBP") return "webp";
  if (buf.subarray(0, 4).toString("ascii") === "GIF8") return "gif";
  return null;
}

// ============================================================
// AUTH HELPERS
// ============================================================
function issueTokens(user: { id: string }) {
  const accessToken = signJwt({ sub: user.id }, 15 * 60);
  const refreshToken = crypto.randomBytes(32).toString("base64url");
  const expiresAt = new Date(Date.now() + 30 * 86400_000).toISOString();
  db.prepare("INSERT INTO refresh_tokens (id, user_id, token_hash, expires_at) VALUES (?, ?, ?, ?)").run(
    crypto.randomUUID(),
    user.id,
    sha256(refreshToken),
    expiresAt
  );
  return { accessToken, refreshToken };
}

function extractIndianMobile(raw: string): string | null {
  const digits = raw.replace(/\D/g, "");
  if (/^[6-9]\d{9}$/.test(digits)) return digits;
  if (digits.length === 12 && digits.startsWith("91") && /^[6-9]\d{9}$/.test(digits.slice(2))) {
    return digits.slice(2);
  }
  return null;
}

async function authenticate(req: Request, identifier: string, password: string) {
  const trimmed = identifier.trim();
  const normalizedPhone = extractIndianMobile(trimmed);
  const u = (
    normalizedPhone
      ? db.prepare("SELECT * FROM users WHERE phone_hash = ?").get(blindIndex(normalizedPhone))
      : db.prepare("SELECT * FROM users WHERE LOWER(username) = LOWER(?)").get(trimmed)
  ) as Record<string, any> | undefined;
  if (u?.locked_until && new Date(u.locked_until) > new Date()) {
    throw new HttpError(429, "Too many failed attempts. Account locked for 15 minutes.");
  }
  const ok = await verifyPassword(password, u ? u.password_hash : DUMMY_HASH);
  if (!u || !ok || u.is_blocked) {
    if (u) {
      const nextFails = (u.failed_logins || 0) + 1;
      const lockedUntil = nextFails >= 5 ? new Date(Date.now() + 15 * 60_000).toISOString() : u.locked_until;
      db.prepare("UPDATE users SET failed_logins = ?, locked_until = ? WHERE id = ?").run(nextFails, lockedUntil, u.id);
    }
    audit(req, u?.id, "login_failed", { reason: u?.is_blocked ? "blocked" : "bad_credentials" });
    throw new HttpError(401, "Invalid credentials");
  }
  db.prepare("UPDATE users SET failed_logins = 0, locked_until = NULL WHERE id = ?").run(u.id);
  return u;
}

function rotateRefresh(req: Request, token: string) {
  const t = db.prepare("SELECT * FROM refresh_tokens WHERE token_hash = ?").get(sha256(token)) as Record<string, any> | undefined;
  if (!t) throw new HttpError(401, "Unauthorized");
  if (t.revoked) {
    db.prepare("UPDATE refresh_tokens SET revoked = 1 WHERE user_id = ?").run(t.user_id);
    audit(req, t.user_id, "refresh_token_reuse");
    throw new HttpError(401, "Unauthorized");
  }
  if (new Date(t.expires_at) < new Date()) throw new HttpError(401, "Unauthorized");
  db.prepare("UPDATE refresh_tokens SET revoked = 1 WHERE id = ?").run(t.id);
  const u = db.prepare("SELECT id, name, role, is_blocked FROM users WHERE id = ?").get(t.user_id) as Record<string, any> | undefined;
  if (!u || u.is_blocked) throw new HttpError(401, "Unauthorized");
  return { user: u, tokens: issueTokens(u as { id: string }) };
}

// Role is read fresh from the database on EVERY request, never trusted from JWT claims.
const requireAuth = (...roles: UserRole[]) =>
  wrap(async (req, _res, next) => {
    const raw = (req.get("authorization") || "").replace(/^Bearer\s+/i, "");
    let claims: { sub: string };
    try {
      claims = verifyJwt(raw);
    } catch {
      throw new HttpError(401, "Unauthorized");
    }
    const u = db.prepare("SELECT id, name, role, is_blocked FROM users WHERE id = ?").get(claims.sub) as
      | { id: string; name: string; role: UserRole; is_blocked: number }
      | undefined;
    if (!u || u.is_blocked) throw new HttpError(401, "Unauthorized");
    if (roles.length && !roles.includes(u.role)) throw new HttpError(403, "Forbidden");
    req.user = { id: u.id, role: u.role, name: u.name };
    next();
  });

// ============================================================
// FRAUD RULES & COUPON REDEMPTION
// ============================================================
function assessRisk(userId: string, opts: { total: number; paymentMethod: "online" | "cod"; addressHash: string }) {
  const hourAgo = new Date(Date.now() - 3600_000).toISOString();
  const monthAgo = new Date(Date.now() - 30 * 86400_000).toISOString();
  const dayAgo = new Date(Date.now() - 86400_000).toISOString();

  const lastHour = (db.prepare("SELECT COUNT(*) as c FROM orders WHERE user_id = ? AND created_at > ?").get(userId, hourAgo) as { c: number }).c;
  const openUnpaid = (db.prepare("SELECT COUNT(*) as c FROM orders WHERE user_id = ? AND status = 'pending_payment'").get(userId) as { c: number }).c;
  const delivered = (db.prepare("SELECT COUNT(*) as c FROM orders WHERE user_id = ? AND status = 'delivered'").get(userId) as { c: number }).c;
  const codFailures = (
    db
      .prepare("SELECT COUNT(*) as c FROM orders WHERE user_id = ? AND status = 'failed' AND payment_method = 'cod' AND created_at > ?")
      .get(userId, monthAgo) as { c: number }
  ).c;
  const addressUsers = (
    db.prepare("SELECT COUNT(DISTINCT user_id) as c FROM orders WHERE address_hash = ? AND created_at > ?").get(opts.addressHash, dayAgo) as { c: number }
  ).c;
  const userRow = db.prepare("SELECT created_at FROM users WHERE id = ?").get(userId) as { created_at: string };

  const block = (message: string, flag: string) => ({ block: true, message, flags: [flag], score: 100 });

  if (lastHour >= RULES.maxOrdersPerHour) return block("Too many orders. Please try later.", "velocity");
  if (openUnpaid >= RULES.maxUnpaidOrders) return block("Please complete your pending payments first.", "unpaid_orders");
  if (opts.paymentMethod === "cod") {
    const codMsg = "Cash on delivery is not available for this order. Please pay online.";
    if (codFailures >= RULES.codMaxRecentFailures) return block(codMsg, "cod_failures");
    if (delivered < RULES.codMinDeliveredOrders) return block(codMsg, "cod_new_customer");
    if (opts.total > RULES.codMaxPaise) return block(codMsg, "cod_over_limit");
  }

  let score = 0;
  const flags: string[] = [];
  if (opts.total > RULES.highValuePaise) {
    score += 40;
    flags.push("high_value");
  }
  if (Date.now() - new Date(userRow.created_at).getTime() < 10 * 60_000 && opts.total > 100000) {
    score += 30;
    flags.push("new_account_big_order");
  }
  if (addressUsers >= 3) {
    score += 40;
    flags.push("shared_address");
  }
  return { block: false, message: "", score, flags };
}

function redeemCoupon(userId: string, code: string, subtotal: number): number {
  const c = db
    .prepare("SELECT * FROM coupons WHERE code = ? AND active = 1 AND expires_at > ?")
    .get(code, new Date().toISOString()) as Record<string, any> | undefined;
  if (!c || subtotal < c.min_order_paise) throw new HttpError(400, "Coupon is not valid for this order");
  const claim = db
    .prepare("UPDATE coupons SET redeemed_count = redeemed_count + 1 WHERE code = ? AND redeemed_count < max_redemptions")
    .run(code);
  if (!claim.changes) throw new HttpError(400, "Coupon is fully redeemed");
  try {
    db.prepare("INSERT INTO coupon_redemptions (code, user_id) VALUES (?, ?)").run(code, userId);
  } catch {
    throw new HttpError(400, "You have already used this coupon");
  }
  if (c.discount_type === "fixed") {
    return Math.min(c.percent_off * 100, c.max_discount_paise);
  }
  return Math.min(Math.floor((subtotal * c.percent_off) / 100), c.max_discount_paise);
}

// ============================================================
// SERVER STARTUP
// ============================================================
async function startServer() {
  const app = express();
  app.set("trust proxy", 1);
  app.disable("x-powered-by");

  // Security headers (iframe-friendly for preview)
  app.use((_req, res, next) => {
    res.setHeader("X-Content-Type-Options", "nosniff");
    res.setHeader("Referrer-Policy", "no-referrer");
    next();
  });

  const apiLimiter = createRateLimiter(60_000, 240);
  const authLimiter = createRateLimiter(15 * 60_000, 30);
  app.use("/admin", apiLimiter);
  app.use("/orders", apiLimiter);

  // Payment webhook (needs raw body BEFORE express.json)
  const PaymentEntity = z.object({
    id: z.string().min(1).max(64),
    amount: z.number().int(),
    notes: z.object({ order_id: UUID }),
  });

  app.post(
    "/webhooks/payment",
    express.raw({ type: "application/json", limit: "100kb" }),
    wrap(async (req, res) => {
      const expected = crypto.createHmac("sha256", PAYMENT_WEBHOOK_SECRET).update(req.body).digest("hex");
      if (!safeEqual(req.get("x-razorpay-signature") || "", expected)) {
        audit(req, null, "webhook_bad_signature");
        return res.sendStatus(401);
      }
      const evt = JSON.parse(req.body.toString("utf8"));
      if (evt.event !== "payment.captured") return res.sendStatus(200);
      const p = PaymentEntity.parse(evt?.payload?.payment?.entity);

      let placedNow: string | null = null;
      const runTx = db.transaction(() => {
        const o = db.prepare("SELECT id, total_paise, status FROM orders WHERE id = ?").get(p.notes.order_id) as Record<string, any> | undefined;
        if (!o) return;
        if (p.amount !== o.total_paise) {
          audit(null, null, "payment_amount_mismatch", { orderId: o.id, paid: p.amount, expected: o.total_paise });
          return;
        }
        const ins = db
          .prepare("INSERT OR IGNORE INTO payments (provider_payment_id, order_id, amount_paise) VALUES (?, ?, ?)")
          .run(p.id, o.id, p.amount);
        if (!ins.changes) return;
        const now = new Date().toISOString();
        if (o.status === "pending_payment") {
          db.prepare("UPDATE orders SET paid = 1, status = 'placed', placed_at = ? WHERE id = ?").run(now, o.id);
          placedNow = o.id;
        } else {
          db.prepare("UPDATE orders SET paid = 1 WHERE id = ?").run(o.id);
        }
        if (o.status === "cancelled") {
          audit(null, null, "paid_after_cancel_needs_refund", { orderId: o.id });
        }
      });
      runTx();
      if (placedNow) bus.emit("order_placed", placedNow);
      res.sendStatus(200);
    })
  );

  app.use(express.json({ limit: "10mb" }));
  app.use(express.urlencoded({ limit: "10mb", extended: true }));

  // Serve uploaded catalogue images
  app.use("/media", express.static(UPLOAD_DIR, { index: false, maxAge: "7d", immutable: true }));

  // ============================================================
  // CUSTOMER & RIDER AUTH
  // ============================================================
  const RegisterSchema = z.object({
    name: z.string().trim().min(2).max(60),
    phone: PHONE,
    password: z.string().min(10).max(72),
  });
  const LoginSchema = z.object({
    phone: PHONE,
    password: z.string().min(1).max(72),
  });

  app.post(
    "/auth/register",
    authLimiter,
    wrap(async (req, res) => {
      const b = RegisterSchema.parse(req.body);
      const passwordHash = await hashPassword(b.password);
      const id = crypto.randomUUID();
      try {
        db.prepare("INSERT INTO users (id, name, phone_enc, phone_hash, password_hash) VALUES (?, ?, ?, ?, ?)").run(
          id,
          b.name,
          encrypt(b.phone),
          blindIndex(b.phone),
          passwordHash
        );
        res.status(201).json(issueTokens({ id }));
      } catch {
        throw new HttpError(409, "Could not create account");
      }
    })
  );

  app.post(
    "/auth/login",
    authLimiter,
    wrap(async (req, res) => {
      const b = LoginSchema.parse(req.body);
      const u = await authenticate(req, b.phone, b.password);
      if ((STAFF as readonly string[]).includes(u.role)) throw new HttpError(401, "Invalid phone or password");
      res.json(issueTokens({ id: u.id }));
    })
  );

  app.post(
    "/auth/refresh",
    authLimiter,
    wrap(async (req, res) => {
      const { refreshToken } = z.object({ refreshToken: z.string().min(20).max(200) }).parse(req.body);
      const { user, tokens } = rotateRefresh(req, refreshToken);
      if ((STAFF as readonly string[]).includes(user.role)) throw new HttpError(401, "Unauthorized");
      res.json(tokens);
    })
  );

  // ============================================================
  // ADMIN AUTH (httpOnly rotating refresh cookie + memory access token)
  // ============================================================
  const COOKIE = "ee_rt";
  const readCookie = (req: Request, name: string) =>
    (req.get("cookie") || "")
      .split(";")
      .map((s) => s.trim().split("="))
      .find(([k]) => k === name)?.[1];

  const getCookieOpts = (req: Request) => {
    const isHttps = req.secure || req.get("x-forwarded-proto") === "https";
    return {
      httpOnly: true,
      secure: isHttps,
      sameSite: (isHttps ? "none" : "lax") as "none" | "lax",
      path: "/admin/auth",
      maxAge: 30 * 86400_000,
    };
  };

  const sendAdminSession = (req: Request, res: Response, user: Record<string, any>, tokens: { accessToken: string; refreshToken: string }) =>
    res
      .cookie(COOKIE, tokens.refreshToken, getCookieOpts(req))
      .json({ accessToken: tokens.accessToken, user: { id: user.id, name: user.name, role: user.role } });

  app.get(
    "/admin/auth/setup-status",
    wrap(async (_req, res) => {
      const row = db.prepare("SELECT COUNT(*) AS c FROM users WHERE role = 'super_admin'").get() as { c: number };
      res.json({ needsSetup: row.c === 0 });
    })
  );

  app.post(
    "/admin/auth/setup",
    authLimiter,
    wrap(async (req, res) => {
      const b = RegisterSchema.parse(req.body);
      const pwHash = await hashPassword(b.password);
      const id = crypto.randomUUID();

      const createOwnerTx = db.transaction(() => {
        const existing = db.prepare("SELECT COUNT(*) AS c FROM users WHERE role = 'super_admin'").get() as { c: number };
        if (existing.c > 0) {
          throw new HttpError(403, "Initial Super Admin setup has already been completed.");
        }
        try {
          db.prepare(
            "INSERT INTO users (id, name, phone_enc, phone_hash, password_hash, role) VALUES (?, ?, ?, ?, ?, 'super_admin')"
          ).run(id, b.name, encrypt(b.phone), blindIndex(b.phone), pwHash);
        } catch {
          throw new HttpError(409, "That mobile number is already registered.");
        }
        return { id, name: b.name, role: "super_admin" };
      });

      const owner = createOwnerTx();
      audit(req, owner.id, "initial_super_admin_created", { role: "super_admin" });
      const tokens = issueTokens({ id: owner.id });
      res
        .status(201)
        .cookie(COOKIE, tokens.refreshToken, getCookieOpts(req))
        .json({ accessToken: tokens.accessToken, user: owner });
    })
  );

  const AdminLoginSchema = z
    .object({
      identifier: z.string().trim().min(2).max(60).optional(),
      phone: z.string().trim().min(2).max(60).optional(),
      password: z.string().min(1).max(72),
    })
    .refine((d) => Boolean(d.identifier || d.phone), { message: "Enter your mobile number or username" });

  app.post(
    "/admin/auth/login",
    authLimiter,
    wrap(async (req, res) => {
      const b = AdminLoginSchema.parse(req.body);
      const u = await authenticate(req, (b.identifier || b.phone)!, b.password);
      if (!(STAFF as readonly string[]).includes(u.role)) throw new HttpError(401, "Invalid credentials");
      audit(req, u.id, "staff_login", { role: u.role });
      sendAdminSession(req, res, u, issueTokens({ id: u.id }));
    })
  );

  app.post(
    "/admin/auth/refresh",
    authLimiter,
    wrap(async (req, res) => {
      const rt = readCookie(req, COOKIE);
      if (!rt) throw new HttpError(401, "Unauthorized");
      const { user, tokens } = rotateRefresh(req, rt);
      if (!(STAFF as readonly string[]).includes(user.role)) throw new HttpError(401, "Unauthorized");
      sendAdminSession(req, res, user, tokens);
    })
  );

  app.post(
    "/admin/auth/logout",
    wrap(async (req, res) => {
      const rt = readCookie(req, COOKIE);
      if (rt) db.prepare("UPDATE refresh_tokens SET revoked = 1 WHERE token_hash = ?").run(sha256(rt));
      const isHttps = req.secure || req.get("x-forwarded-proto") === "https";
      res.clearCookie(COOKIE, { path: "/admin/auth", secure: isHttps, sameSite: isHttps ? "none" : "lax" }).sendStatus(204);
    })
  );

  // ============================================================
  // CUSTOMER + RIDER APP ENDPOINTS
  // ============================================================
  app.get(
    "/menu",
    wrap(async (req, res) => {
      const q = z.object({ q: z.string().trim().max(60).optional(), veg: z.enum(["true", "false"]).optional() }).parse(req.query);
      const conditions = ["is_available = 1"];
      const params: unknown[] = [];
      if (q.veg) {
        conditions.push("is_veg = ?");
        params.push(q.veg === "true" ? 1 : 0);
      }
      if (q.q) {
        const pattern = `%${q.q.toLowerCase()}%`;
        conditions.push("(LOWER(name) LIKE ? OR LOWER(description) LIKE ? OR LOWER(keywords) LIKE ?)");
        params.push(pattern, pattern, pattern);
      }
      const rows = db
        .prepare(
          `SELECT id, name, description, selling_price_paise AS "pricePaise", price_paise AS "mrpPaise",
                  image_url AS "imageUrl", is_veg AS "isVeg", category
           FROM menu_items WHERE ${conditions.join(" AND ")} ORDER BY category, name LIMIT 200`
        )
        .all(...params) as Record<string, any>[];
      res.json(rows.map((r) => ({ ...r, isVeg: Boolean(r.isVeg) })));
    })
  );

  app.post(
    "/devices",
    requireAuth("customer", "rider"),
    wrap(async (req, res) => {
      const b = z.object({ token: z.string().min(20).max(4096), platform: z.enum(["android", "ios"]) }).parse(req.body);
      db.prepare(
        `INSERT INTO device_tokens (token, user_id, platform, updated_at) VALUES (?, ?, ?, ?)
         ON CONFLICT(token) DO UPDATE SET user_id = excluded.user_id, platform = excluded.platform, updated_at = excluded.updated_at`
      ).run(b.token, req.user!.id, b.platform, new Date().toISOString());
      res.sendStatus(204);
    })
  );

  app.delete(
    "/devices",
    requireAuth("customer", "rider"),
    wrap(async (req, res) => {
      const { token } = z.object({ token: z.string().min(20).max(4096) }).parse(req.body);
      db.prepare("DELETE FROM device_tokens WHERE token = ? AND user_id = ?").run(token, req.user!.id);
      res.sendStatus(204);
    })
  );

  app.post(
    "/rider/heartbeat",
    requireAuth("rider"),
    wrap(async (req, res) => {
      const { online } = z.object({ online: z.boolean() }).parse(req.body);
      db.prepare("UPDATE users SET is_online = ?, last_seen_at = ? WHERE id = ?").run(
        online ? 1 : 0,
        new Date().toISOString(),
        req.user!.id
      );
      res.sendStatus(204);
    })
  );

  app.get(
    "/rider/orders",
    requireAuth("rider"),
    wrap(async (req, res) => {
      const rows = db
        .prepare(
          `SELECT id, status, payment_method, total_paise, address_enc, rider_id
           FROM orders
           WHERE (status = 'preparing' AND rider_id IS NULL) OR (status = 'out_for_delivery' AND rider_id = ?)
           ORDER BY created_at LIMIT 30`
        )
        .all(req.user!.id) as Record<string, any>[];
      res.json(
        rows.map((o) => ({
          id: o.id,
          status: o.status,
          collectCashPaise: o.payment_method === "cod" ? o.total_paise : 0,
          address: o.rider_id === req.user!.id ? decrypt(o.address_enc) : undefined,
        }))
      );
    })
  );

  const OrderSchema = z.object({
    items: z
      .array(z.object({ menuItemId: UUID, qty: z.number().int().min(1).max(10) }))
      .min(1)
      .max(30),
    address: z.string().trim().min(10).max(300),
    paymentMethod: z.enum(["online", "cod"]),
    couponCode: z.string().trim().toUpperCase().max(20).optional(),
  });

  app.post(
    "/orders",
    requireAuth("customer"),
    wrap(async (req, res) => {
      const key = req.get("idempotency-key") || "";
      if (!/^[A-Za-z0-9_-]{16,64}$/.test(key)) throw new HttpError(400, "Idempotency-Key header is required");
      const body = OrderSchema.parse(req.body);
      const ids = body.items.map((i) => i.menuItemId);
      if (new Set(ids).size !== ids.length) throw new HttpError(400, "Duplicate items in cart");

      const existing = db
        .prepare("SELECT * FROM orders WHERE user_id = ? AND idempotency_key = ?")
        .get(req.user!.id, key) as Record<string, any> | undefined;
      if (existing) return res.json(publicOrder(existing));

      const createTx = db.transaction(() => {
        const placeholders = ids.map(() => "?").join(",");
        const menu = db
          .prepare(`SELECT id, name, selling_price_paise AS price_paise FROM menu_items WHERE id IN (${placeholders}) AND is_available = 1`)
          .all(...ids) as { id: string; name: string; price_paise: number }[];
        if (menu.length !== ids.length) throw new HttpError(400, "Some items are unavailable");
        const byId = new Map(menu.map((m) => [m.id, m]));
        const lines = body.items.map((i) => ({ ...byId.get(i.menuItemId)!, qty: i.qty }));
        const subtotal = lines.reduce((sum, l) => sum + l.price_paise * l.qty, 0);

        const discount = body.couponCode ? redeemCoupon(req.user!.id, body.couponCode, subtotal) : 0;
        const delivery = subtotal >= RULES.freeDeliveryAbovePaise ? 0 : RULES.deliveryFeePaise;
        const total = Math.max(100, subtotal - discount + delivery);

        const addressHash = blindIndex(body.address.toLowerCase().replace(/\s+/g, " "));
        const risk = assessRisk(req.user!.id, { total, paymentMethod: body.paymentMethod, addressHash });
        if (risk.block) {
          audit(req, req.user!.id, "order_blocked", { flags: risk.flags });
          throw new HttpError(403, risk.message);
        }

        const status =
          risk.score >= RULES.reviewScoreAt ? "under_review" : body.paymentMethod === "cod" ? "placed" : "pending_payment";
        const id = crypto.randomUUID();
        const now = new Date().toISOString();
        const otp = String(crypto.randomInt(1000, 10000));

        db.prepare(
          `INSERT INTO orders (
             id, user_id, idempotency_key, status, payment_method, subtotal_paise, discount_paise,
             delivery_paise, total_paise, coupon_code, address_enc, address_hash, otp_enc,
             risk_score, risk_flags, placed_at, created_at
           ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
        ).run(
          id,
          req.user!.id,
          key,
          status,
          body.paymentMethod,
          subtotal,
          discount,
          delivery,
          total,
          body.couponCode ?? null,
          encrypt(body.address),
          addressHash,
          encrypt(otp),
          risk.score,
          JSON.stringify(risk.flags),
          status === "placed" ? now : null,
          now
        );
        for (const l of lines) {
          db.prepare("INSERT INTO order_items (order_id, menu_item_id, name, unit_price_paise, qty) VALUES (?, ?, ?, ?, ?)").run(
            id,
            l.id,
            l.name,
            l.price_paise,
            l.qty
          );
        }
        return db.prepare("SELECT * FROM orders WHERE id = ?").get(id) as Record<string, any>;
      });

      const order = createTx();
      const flags = parseJsonArray(order.risk_flags);
      if (flags.length) audit(req, req.user!.id, "order_flagged", { orderId: order.id, flags });
      if (order.status === "placed") bus.emit("order_placed", order.id);
      res.status(201).json(publicOrder(order));
    })
  );

  app.get(
    "/orders",
    requireAuth("customer"),
    wrap(async (req, res) => {
      const rows = db
        .prepare("SELECT * FROM orders WHERE user_id = ? ORDER BY created_at DESC LIMIT 50")
        .all(req.user!.id) as Record<string, any>[];
      res.json(rows.map(publicOrder));
    })
  );

  app.get(
    "/orders/:id",
    requireAuth("customer"),
    wrap(async (req, res) => {
      const id = UUID.parse(req.params.id);
      const o = db.prepare("SELECT * FROM orders WHERE id = ? AND user_id = ?").get(id, req.user!.id) as Record<string, any> | undefined;
      if (!o) throw new HttpError(404, "Not found");
      const items = db
        .prepare('SELECT name, unit_price_paise AS "unitPricePaise", qty FROM order_items WHERE order_id = ?')
        .all(id);
      res.json({
        ...publicOrder(o),
        items,
        address: decrypt(o.address_enc),
        deliveryOtp: o.status === "out_for_delivery" ? decrypt(o.otp_enc) : undefined,
      });
    })
  );

  app.post(
    "/orders/:id/cancel",
    requireAuth("customer"),
    wrap(async (req, res) => {
      const id = UUID.parse(req.params.id);
      const o = db
        .prepare("SELECT id, paid FROM orders WHERE id = ? AND user_id = ? AND status IN ('pending_payment','under_review','placed')")
        .get(id, req.user!.id) as { id: string; paid: number } | undefined;
      if (!o) throw new HttpError(409, "This order can no longer be cancelled");
      db.prepare("UPDATE orders SET status = 'cancelled' WHERE id = ?").run(id);
      if (o.paid) audit(req, req.user!.id, "cancelled_paid_order_needs_refund", { orderId: id });
      bus.emit("order_status", { id, to: "cancelled" });
      res.json({ status: "cancelled" });
    })
  );

  app.post(
    "/orders/:id/review",
    requireAuth("customer"),
    wrap(async (req, res) => {
      const id = UUID.parse(req.params.id);
      const b = z.object({ rating: z.number().int().min(1).max(5), comment: z.string().trim().max(500).default("") }).parse(req.body);
      const o = db.prepare("SELECT id FROM orders WHERE id = ? AND user_id = ? AND status = 'delivered'").get(id, req.user!.id);
      if (!o) throw new HttpError(409, "You can review a delivered order once");
      const revId = crypto.randomUUID();
      try {
        db.prepare("INSERT INTO reviews (id, order_id, user_id, rating, comment) VALUES (?, ?, ?, ?, ?)").run(
          revId,
          id,
          req.user!.id,
          b.rating,
          b.comment
        );
      } catch {
        throw new HttpError(409, "You can review a delivered order once");
      }
      res.status(201).json({ id: revId });
    })
  );

  // Order state machine transitions
  const TRANSITIONS: Record<string, string[]> = {
    pending_payment: ["placed", "cancelled"],
    under_review: ["placed", "pending_payment", "cancelled"],
    placed: ["accepted", "cancelled"],
    accepted: ["preparing", "cancelled"],
    preparing: ["out_for_delivery"],
    out_for_delivery: ["delivered", "failed"],
  };
  const RIDER_MAY_SET = new Set(["out_for_delivery", "failed"]);

  app.patch(
    "/orders/:id/status",
    requireAuth("rider", ...ORDER_STAFF),
    wrap(async (req, res) => {
      const id = UUID.parse(req.params.id);
      const { to } = z.object({ to: z.enum(["accepted", "preparing", "out_for_delivery", "failed", "cancelled"]) }).parse(req.body);

      const moveTx = db.transaction(() => {
        const o = db.prepare("SELECT * FROM orders WHERE id = ?").get(id) as Record<string, any> | undefined;
        if (!o) throw new HttpError(404, "Not found");
        if (!(TRANSITIONS[o.status] || []).includes(to)) {
          throw new HttpError(409, `Cannot go from ${o.status} to ${to}`);
        }
        if (req.user!.role === "rider") {
          if (!RIDER_MAY_SET.has(to)) throw new HttpError(403, "Forbidden");
          if (o.rider_id && o.rider_id !== req.user!.id) throw new HttpError(403, "Not your order");
        }
        let riderId = o.rider_id;
        if (to === "out_for_delivery" && req.user!.role === "rider") {
          riderId = req.user!.id;
        } else if (to === "out_for_delivery" && !riderId) {
          const onlineRider = db
            .prepare("SELECT id FROM users WHERE role = 'rider' AND is_blocked = 0 ORDER BY is_online DESC LIMIT 1")
            .get() as { id: string } | undefined;
          riderId = onlineRider?.id ?? null;
        }
        db.prepare("UPDATE orders SET status = ?, rider_id = ? WHERE id = ?").run(to, riderId, id);
        if (to === "cancelled" && o.paid) {
          audit(req, req.user!.id, "cancelled_paid_order_needs_refund", { orderId: id });
        }
        audit(req, req.user!.id, "order_status", { orderId: id, from: o.status, to });
      });

      moveTx();
      bus.emit("order_status", { id, to });
      res.json({ status: to });
    })
  );

  // Delivered requires the customer's 4-digit OTP
  app.post(
    "/orders/:id/deliver",
    requireAuth("rider", ...ORDER_STAFF),
    wrap(async (req, res) => {
      const id = UUID.parse(req.params.id);
      const { otp } = z.object({ otp: z.string().regex(/^\d{4}$/, "Enter a 4-digit delivery code") }).parse(req.body);
      let wrong = false;
      const deliverTx = db.transaction(() => {
        const o = db.prepare("SELECT * FROM orders WHERE id = ?").get(id) as Record<string, any> | undefined;
        if (!o || o.status !== "out_for_delivery") throw new HttpError(409, "Order is not out for delivery");
        if (req.user!.role === "rider" && o.rider_id !== req.user!.id) throw new HttpError(403, "Not your order");
        if (o.otp_attempts >= RULES.maxWrongOtp) throw new HttpError(429, "Too many wrong codes. Contact support.");
        if (!safeEqual(decrypt(o.otp_enc), otp)) {
          db.prepare("UPDATE orders SET otp_attempts = otp_attempts + 1 WHERE id = ?").run(id);
          wrong = true;
          return;
        }
        db.prepare("UPDATE orders SET status = 'delivered', paid = 1 WHERE id = ?").run(id);
        audit(req, req.user!.id, "order_delivered", { orderId: id });
      });
      deliverTx();
      if (wrong) {
        audit(req, req.user!.id, "otp_wrong", { orderId: id });
        throw new HttpError(400, "Wrong delivery code");
      }
      bus.emit("order_status", { id, to: "delivered" });
      res.json({ status: "delivered" });
    })
  );

  // ============================================================
  // ADMIN: LIVE SSE STREAM + ORDERS + AUTO-CANCEL JOB
  // ============================================================
  app.get("/admin/stream", requireAuth(...ORDER_VIEW), (req, res) => {
    res.set({
      "Content-Type": "text/event-stream",
      "Cache-Control": "no-cache, no-transform",
      Connection: "keep-alive",
    });
    res.flushHeaders();
    const send = (event: string, data: unknown) => {
      res.write(`event: ${event}\ndata: ${JSON.stringify(data)}\n\n`);
    };
    const onPlaced = (id: string) => {
      const c = orderCard(id);
      if (c) send("new_order", c);
    };
    const onStatus = (e: unknown) => send("order_status", e);
    bus.on("order_placed", onPlaced);
    bus.on("order_status", onStatus);
    const ping = setInterval(() => res.write(": ping\n\n"), 25_000);
    const recycle = setTimeout(() => res.end(), 10 * 60_000);
    req.on("close", () => {
      clearInterval(ping);
      clearTimeout(recycle);
      bus.off("order_placed", onPlaced);
      bus.off("order_status", onStatus);
    });
  });

  app.get(
    "/admin/orders",
    requireAuth(...ORDER_VIEW),
    wrap(async (req, res) => {
      const q = z
        .object({
          status: z.string().regex(/^[a-z_]+$/).optional(),
          q: z.string().trim().max(60).optional(),
          startDate: z.string().optional(),
          endDate: z.string().optional(),
        })
        .parse(req.query);

      const conditions: string[] = [];
      const params: unknown[] = [];

      if (q.status) {
        conditions.push("o.status = ?");
        params.push(q.status);
      }
      if (q.q) {
        const pattern = `%${q.q.toLowerCase()}%`;
        conditions.push("(LOWER(o.id) LIKE ? OR LOWER(u.name) LIKE ?)");
        params.push(pattern, pattern);
      }
      if (q.startDate && q.startDate.trim()) {
        conditions.push("datetime(o.created_at) >= datetime(?)");
        params.push(q.startDate.trim());
      }
      if (q.endDate && q.endDate.trim()) {
        conditions.push("datetime(o.created_at) <= datetime(?)");
        params.push(q.endDate.trim());
      }

      const whereClause = conditions.length ? `WHERE ${conditions.join(" AND ")}` : "";
      const rows = db
        .prepare(
          `SELECT o.*, u.name AS customer_name, r.name AS rider_name
           FROM orders o
           JOIN users u ON u.id = o.user_id
           LEFT JOIN users r ON r.id = o.rider_id
           ${whereClause}
           ORDER BY o.created_at DESC
           LIMIT 200`
        )
        .all(...params) as Record<string, any>[];

      res.json(
        rows.map((o) => ({
          ...publicOrder(o),
          customerName: o.customer_name,
          riderName: o.rider_name || null,
          riskFlags: parseJsonArray(o.risk_flags),
        }))
      );
    })
  );

  app.get(
    "/admin/orders/:id",
    requireAuth(...ORDER_VIEW),
    wrap(async (req, res) => {
      const card = orderCard(UUID.parse(req.params.id));
      if (!card) throw new HttpError(404, "Not found");
      res.json(card);
    })
  );

  app.post(
    "/admin/orders/:id/review",
    requireAuth(...ORDER_STAFF),
    wrap(async (req, res) => {
      const id = UUID.parse(req.params.id);
      const { approve } = z.object({ approve: z.boolean() }).parse(req.body);
      const o = db.prepare("SELECT * FROM orders WHERE id = ? AND status = 'under_review'").get(id) as Record<string, any> | undefined;
      if (!o) throw new HttpError(409, "Order is not under review");
      const nextStatus = !approve ? "cancelled" : o.paid || o.payment_method === "cod" ? "placed" : "pending_payment";
      const now = new Date().toISOString();
      db.prepare("UPDATE orders SET status = ?, placed_at = CASE WHEN ? = 'placed' THEN ? ELSE placed_at END WHERE id = ?").run(
        nextStatus,
        nextStatus,
        now,
        id
      );
      audit(req, req.user!.id, "order_review", { orderId: id, approve, nextStatus });
      if (nextStatus === "placed") bus.emit("order_placed", id);
      else bus.emit("order_status", { id, to: nextStatus });
      res.json({ status: nextStatus });
    })
  );

  app.post(
    "/admin/orders/:id/reject",
    requireAuth(...ORDER_STAFF),
    wrap(async (req, res) => {
      const id = UUID.parse(req.params.id);
      const { reason } = z.object({ reason: z.string().trim().min(3).max(200) }).parse(req.body);
      const o = db
        .prepare("SELECT id, paid FROM orders WHERE id = ? AND status IN ('placed','under_review','accepted')")
        .get(id) as { id: string; paid: number } | undefined;
      if (!o) throw new HttpError(409, "This order can no longer be rejected");
      db.prepare("UPDATE orders SET status = 'cancelled', reject_reason = ? WHERE id = ?").run(reason, id);
      audit(req, req.user!.id, "order_rejected", { orderId: id, reason, needsRefund: Boolean(o.paid) });
      bus.emit("order_status", { id, to: "cancelled" });
      res.json({ status: "cancelled", needsRefund: Boolean(o.paid) });
    })
  );

  // List non-blocked customers for manual phone-order selection (no PII exposed)
  app.get(
    "/admin/orders/customers",
    requireAuth(...ORDER_STAFF),
    wrap(async (_req, res) => {
      const rows = db
        .prepare("SELECT id, name FROM users WHERE role = 'customer' AND is_blocked = 0 ORDER BY name LIMIT 200")
        .all();
      res.json(rows);
    })
  );

  // Create a real incoming phone/counter COD order (requires real customer, real menu item, and explicit address)
  app.post(
    "/admin/orders/manual",
    requireAuth(...ORDER_STAFF),
    wrap(async (req, res) => {
      const b = z
        .object({
          customerId: UUID,
          menuItemId: UUID,
          qty: z.number().int().min(1).max(10).default(1),
          address: z.string().trim().min(10, "Enter complete delivery address").max(300),
        })
        .parse(req.body);

      const item = db
        .prepare("SELECT id, name, selling_price_paise FROM menu_items WHERE id = ? AND is_available = 1")
        .get(b.menuItemId) as { id: string; name: string; selling_price_paise: number } | undefined;
      if (!item) throw new HttpError(400, "Selected menu item is not available");

      const cust = db
        .prepare("SELECT id FROM users WHERE id = ? AND role = 'customer' AND is_blocked = 0")
        .get(b.customerId) as { id: string } | undefined;
      if (!cust) throw new HttpError(400, "Selected customer account was not found");

      const id = crypto.randomUUID();
      const subtotal = item.selling_price_paise * b.qty;
      const delivery = subtotal >= RULES.freeDeliveryAbovePaise ? 0 : RULES.deliveryFeePaise;
      const total = subtotal + delivery;
      const now = new Date().toISOString();
      const otp = String(crypto.randomInt(1000, 10000));

      const tx = db.transaction(() => {
        db.prepare(
          `INSERT INTO orders (
             id, user_id, idempotency_key, status, payment_method, paid,
             subtotal_paise, discount_paise, delivery_paise, total_paise,
             address_enc, address_hash, otp_enc, placed_at, created_at
           ) VALUES (?, ?, ?, 'placed', 'cod', 0, ?, 0, ?, ?, ?, ?, ?, ?, ?)`
        ).run(
          id,
          cust.id,
          `phone_${crypto.randomBytes(10).toString("hex")}`,
          subtotal,
          delivery,
          total,
          encrypt(b.address),
          blindIndex(b.address.toLowerCase().replace(/\s+/g, " ")),
          encrypt(otp),
          now,
          now
        );
        db.prepare("INSERT INTO order_items (order_id, menu_item_id, name, unit_price_paise, qty) VALUES (?, ?, ?, ?, ?)").run(
          id,
          item.id,
          item.name,
          item.selling_price_paise,
          b.qty
        );
      });
      tx();

      audit(req, req.user!.id, "manual_order_created", { orderId: id, totalPaise: total });
      bus.emit("order_placed", id);
      res.status(201).json(orderCard(id));
    })
  );

  // Safety net: auto-cancel unaccepted placed orders after 5 minutes
  setInterval(() => {
    try {
      const cutoff = new Date(Date.now() - RULES.acceptTimeoutMin * 60_000).toISOString();
      const expired = db
        .prepare("SELECT id, paid FROM orders WHERE status = 'placed' AND placed_at IS NOT NULL AND datetime(placed_at) < datetime(?)")
        .all(cutoff) as { id: string; paid: number }[];
      for (const o of expired) {
        db.prepare("UPDATE orders SET status = 'cancelled', reject_reason = 'Restaurant did not respond in time' WHERE id = ?").run(o.id);
        audit(null, null, "order_auto_cancelled", { orderId: o.id, needsRefund: Boolean(o.paid) });
        bus.emit("order_status", { id: o.id, to: "cancelled" });
      }
    } catch (e: any) {
      console.error("auto-cancel job failed:", e?.message);
    }
  }, 30_000).unref();

  // ============================================================
  // ADMIN: DASHBOARD (real analytics + period comparison)
  // ============================================================
  function computePeriod(fromDaysAgo: number, toDaysAgo: number) {
    const start = new Date(Date.now() - fromDaysAgo * 86400_000).toISOString();
    const end = new Date(Date.now() - toDaysAgo * 86400_000).toISOString();
    const row = db
      .prepare(
        `SELECT
           SUM(CASE WHEN status <> 'pending_payment' THEN 1 ELSE 0 END) AS orders,
           SUM(CASE WHEN status = 'delivered' THEN 1 ELSE 0 END) AS delivered,
           SUM(CASE WHEN status = 'cancelled' THEN 1 ELSE 0 END) AS cancelled,
           COALESCE(SUM(CASE WHEN status = 'delivered' THEN total_paise ELSE 0 END), 0) AS revenue
         FROM orders
         WHERE datetime(created_at) >= datetime(?) AND datetime(created_at) < datetime(?)`
      )
      .get(start, end) as Record<string, number | null>;
    return {
      orders: Number(row?.orders || 0),
      delivered: Number(row?.delivered || 0),
      cancelled: Number(row?.cancelled || 0),
      revenue: Number(row?.revenue || 0),
    };
  }

  app.get(
    "/admin/dashboard",
    requireAuth(...STAFF),
    wrap(async (req, res) => {
      const { days } = z.object({ days: z.coerce.number().int().min(1).max(365).default(7) }).parse(req.query);
      const current = computePeriod(days, 0);
      const previous = computePeriod(days * 2, days);

      // Build daily series in IST (UTC+05:30)
      const IST_OFFSET_MS = 5.5 * 3600_000;
      const nowIst = new Date(Date.now() + IST_OFFSET_MS);
      const dayKeys: string[] = [];
      for (let i = days - 1; i >= 0; i--) {
        const d = new Date(Date.UTC(nowIst.getUTCFullYear(), nowIst.getUTCMonth(), nowIst.getUTCDate() - i));
        dayKeys.push(d.toISOString().slice(0, 10));
      }

      const startIso = new Date(Date.now() - (days + 1) * 86400_000).toISOString();
      const recentOrders = db
        .prepare("SELECT status, total_paise, created_at FROM orders WHERE status <> 'pending_payment' AND datetime(created_at) >= datetime(?)")
        .all(startIso) as { status: string; total_paise: number; created_at: string }[];

      const seriesMap = new Map(dayKeys.map((k) => [k, { day: k, orders: 0, revenue: 0 }]));
      for (const o of recentOrders) {
        const key = new Date(new Date(o.created_at).getTime() + IST_OFFSET_MS).toISOString().slice(0, 10);
        const bucket = seriesMap.get(key);
        if (bucket) {
          bucket.orders += 1;
          if (o.status === "delivered") bucket.revenue += o.total_paise;
        }
      }
      const series = Array.from(seriesMap.values());

      const periodStart = new Date(Date.now() - days * 86400_000).toISOString();
      const top = db
        .prepare(
          `SELECT i.name, SUM(i.qty) AS qty, SUM(i.qty * i.unit_price_paise) AS revenue
           FROM order_items i JOIN orders o ON o.id = i.order_id
           WHERE o.status = 'delivered' AND datetime(o.created_at) >= datetime(?)
           GROUP BY i.name ORDER BY qty DESC LIMIT 5`
        )
        .all(periodStart) as { name: string; qty: number; revenue: number }[];

      const riderStats = db
        .prepare(
          `SELECT
             SUM(CASE WHEN is_online = 1 THEN 1 ELSE 0 END) AS online,
             COUNT(*) AS total
           FROM users WHERE role = 'rider' AND is_blocked = 0`
        )
        .get() as { online: number | null; total: number | null };

      const queueRow = db
        .prepare(
          `SELECT
             SUM(CASE WHEN status = 'placed' THEN 1 ELSE 0 END) AS awaiting,
             SUM(CASE WHEN status = 'under_review' THEN 1 ELSE 0 END) AS review,
             SUM(CASE WHEN status IN ('accepted','preparing','out_for_delivery') THEN 1 ELSE 0 END) AS active
           FROM orders`
        )
        .get() as Record<string, number | null>;

      const refundsDueRow = db
        .prepare(
          `SELECT COUNT(*) AS c FROM payments p JOIN orders x ON x.id = p.order_id
           WHERE x.status = 'cancelled' AND p.refunded_at IS NULL`
        )
        .get() as { c: number };

      res.json({
        current,
        previous,
        series,
        top: top.map((x) => ({ name: x.name, qty: Number(x.qty), revenue: Number(x.revenue) })),
        riders: { online: Number(riderStats?.online || 0), total: Number(riderStats?.total || 0) },
        queue: {
          awaiting: Number(queueRow?.awaiting || 0),
          review: Number(queueRow?.review || 0),
          active: Number(queueRow?.active || 0),
          refundsDue: Number(refundsDueRow?.c || 0),
        },
      });
    })
  );

  // ============================================================
  // ADMIN: CATALOGUE (items are hidden/archived, never deleted)
  // ============================================================
  const ItemSchema = z.object({
    name: z.string().trim().min(2).max(80),
    description: z.string().trim().max(500).default(""),
    pricePaise: z.number().int().min(100).max(1_000_000),
    sellingPricePaise: z.number().int().min(100).max(1_000_000).optional(),
    isVeg: z.boolean(),
    category: z.string().trim().min(2).max(40),
    keywords: z.array(z.string().trim().toLowerCase().min(2).max(30)).max(20).default([]),
    imageUrl: z
      .string()
      .regex(/^\/media\/[a-f0-9]{32}\.(webp|jpg|png|gif)$/, "Image must be uploaded via the admin uploader")
      .nullable()
      .default(null),
    stock: z.number().int().min(0).max(10_000).default(50),
    isAvailable: z.boolean().default(true),
  });

  const itemRow = (r: Record<string, any>) => ({
    id: r.id,
    name: r.name,
    description: r.description,
    pricePaise: r.price_paise,
    sellingPricePaise: r.selling_price_paise,
    isVeg: Boolean(r.is_veg),
    category: r.category,
    keywords: parseJsonArray(r.keywords),
    imageUrl: r.image_url,
    stock: r.stock,
    isAvailable: Boolean(r.is_available),
  });

  app.get(
    "/admin/catalogue",
    requireAuth(...ORDER_STAFF),
    wrap(async (_req, res) => {
      const rows = db.prepare("SELECT * FROM menu_items ORDER BY category, name").all() as Record<string, any>[];
      res.json(rows.map(itemRow));
    })
  );

  app.post(
    "/admin/catalogue",
    requireAuth(...ORDER_STAFF),
    wrap(async (req, res) => {
      const b = ItemSchema.parse(req.body);
      const id = crypto.randomUUID();
      const selling = b.sellingPricePaise ?? b.pricePaise;
      db.prepare(
        `INSERT INTO menu_items (id, name, description, price_paise, selling_price_paise, is_veg, category, keywords, image_url, stock, is_available)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
      ).run(
        id,
        b.name,
        b.description,
        b.pricePaise,
        selling,
        b.isVeg ? 1 : 0,
        b.category,
        JSON.stringify([...new Set(b.keywords)]),
        b.imageUrl,
        b.stock,
        b.isAvailable ? 1 : 0
      );
      audit(req, req.user!.id, "item_created", { itemId: id, pricePaise: selling });
      const created = db.prepare("SELECT * FROM menu_items WHERE id = ?").get(id) as Record<string, any>;
      res.status(201).json(itemRow(created));
    })
  );

  app.put(
    "/admin/catalogue/:id",
    requireAuth(...ORDER_STAFF),
    wrap(async (req, res) => {
      const id = UUID.parse(req.params.id);
      const b = ItemSchema.parse(req.body);
      const selling = b.sellingPricePaise ?? b.pricePaise;
      const result = db
        .prepare(
          `UPDATE menu_items
           SET name = ?, description = ?, price_paise = ?, selling_price_paise = ?, is_veg = ?,
               category = ?, keywords = ?, image_url = ?, stock = ?, is_available = ?, updated_at = ?
           WHERE id = ?`
        )
        .run(
          b.name,
          b.description,
          b.pricePaise,
          selling,
          b.isVeg ? 1 : 0,
          b.category,
          JSON.stringify([...new Set(b.keywords)]),
          b.imageUrl,
          b.stock,
          b.isAvailable ? 1 : 0,
          new Date().toISOString(),
          id
        );
      if (!result.changes) throw new HttpError(404, "Not found");
      audit(req, req.user!.id, "item_updated", { itemId: id, pricePaise: selling, available: b.isAvailable });
      const updated = db.prepare("SELECT * FROM menu_items WHERE id = ?").get(id) as Record<string, any>;
      res.json(itemRow(updated));
    })
  );

  const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 4 * 1024 * 1024, files: 1 } }).single("image");
  app.post(
    "/admin/catalogue/image",
    requireAuth(...ORDER_STAFF),
    (req, res, next) => upload(req, res, (e) => (e ? next(new HttpError(400, "Image must be under 4 MB")) : next())),
    wrap(async (req, res) => {
      if (!req.file) throw new HttpError(400, "No image received");
      const ext = detectImageExt(req.file.buffer);
      if (!ext) throw new HttpError(400, "File is not a valid PNG, JPEG, WebP, or GIF image");
      const filename = `${crypto.randomBytes(16).toString("hex")}.${ext}`;
      await fs.promises.writeFile(path.join(UPLOAD_DIR, filename), req.file.buffer);
      res.status(201).json({ imageUrl: `/media/${filename}` });
    })
  );

  // ============================================================
  // ADMIN: CUSTOMERS (masked phone in lists; full number audit-logged)
  // ============================================================
  app.get(
    "/admin/customers",
    requireAuth(...CRM),
    wrap(async (req, res) => {
      const q = z.object({ q: z.string().trim().max(40).optional() }).parse(req.query);
      const params: unknown[] = [];
      let filter = "";
      if (q.q && /^[6-9]\d{9}$/.test(q.q)) {
        params.push(blindIndex(q.q));
        filter = "AND u.phone_hash = ?";
      } else if (q.q) {
        params.push(`%${q.q.toLowerCase()}%`);
        filter = "AND LOWER(u.name) LIKE ?";
      }
      const rows = db
        .prepare(
          `SELECT u.id, u.name, u.phone_enc, u.created_at, u.is_blocked,
                  SUM(CASE WHEN o.id IS NOT NULL AND o.status <> 'pending_payment' THEN 1 ELSE 0 END) AS orders,
                  COALESCE(SUM(CASE WHEN o.status = 'delivered' THEN o.total_paise ELSE 0 END), 0) AS spent
           FROM users u
           LEFT JOIN orders o ON o.user_id = u.id
           WHERE u.role = 'customer' ${filter}
           GROUP BY u.id
           ORDER BY u.created_at DESC
           LIMIT 100`
        )
        .all(...params) as Record<string, any>[];

      res.json(
        rows.map((u) => ({
          id: u.id,
          name: u.name,
          phone: maskPhone(decrypt(u.phone_enc)),
          joinedAt: u.created_at,
          blocked: Boolean(u.is_blocked),
          orders: Number(u.orders || 0),
          spentPaise: Number(u.spent || 0),
        }))
      );
    })
  );

  app.get(
    "/admin/customers/:id",
    requireAuth(...CRM),
    wrap(async (req, res) => {
      const id = UUID.parse(req.params.id);
      const u = db.prepare("SELECT * FROM users WHERE id = ? AND role = 'customer'").get(id) as Record<string, any> | undefined;
      if (!u) throw new HttpError(404, "Not found");
      const orders = db.prepare("SELECT * FROM orders WHERE user_id = ? ORDER BY created_at DESC LIMIT 20").all(id) as Record<string, any>[];
      audit(req, req.user!.id, "viewed_customer", { customerId: id });
      res.json({
        id,
        name: u.name,
        phone: decrypt(u.phone_enc),
        blocked: Boolean(u.is_blocked),
        joinedAt: u.created_at,
        orders: orders.map(publicOrder),
      });
    })
  );

  app.patch(
    "/admin/users/:id/block",
    requireAuth(...CRM),
    wrap(async (req, res) => {
      const id = UUID.parse(req.params.id);
      const { blocked } = z.object({ blocked: z.boolean() }).parse(req.body);
      if (id === req.user!.id) throw new HttpError(400, "You cannot block yourself");
      const t = db.prepare("SELECT role FROM users WHERE id = ?").get(id) as { role: string } | undefined;
      if (!t) throw new HttpError(404, "Not found");
      if (req.user!.role !== "super_admin" && t.role !== "customer") throw new HttpError(403, "Forbidden");
      db.prepare("UPDATE users SET is_blocked = ? WHERE id = ?").run(blocked ? 1 : 0, id);
      if (blocked) db.prepare("UPDATE refresh_tokens SET revoked = 1 WHERE user_id = ?").run(id);
      audit(req, req.user!.id, blocked ? "user_blocked" : "user_unblocked", { userId: id, targetRole: t.role });
      res.json({ blocked });
    })
  );

  // ============================================================
  // ADMIN: RIDERS
  // ============================================================
  app.get(
    "/admin/riders",
    requireAuth(...ORDER_STAFF),
    wrap(async (_req, res) => {
      const rows = db
        .prepare(
          `SELECT u.id, u.name, u.phone_enc, u.is_blocked, u.is_online, u.last_seen_at,
                  SUM(CASE WHEN o.status = 'out_for_delivery' THEN 1 ELSE 0 END) AS active,
                  SUM(CASE WHEN o.status = 'delivered' THEN 1 ELSE 0 END) AS delivered
           FROM users u
           LEFT JOIN orders o ON o.rider_id = u.id
           WHERE u.role = 'rider'
           GROUP BY u.id
           ORDER BY u.is_online DESC, u.name`
        )
        .all() as Record<string, any>[];
      res.json(
        rows.map((r) => ({
          id: r.id,
          name: r.name,
          phone: decrypt(r.phone_enc),
          online: Boolean(r.is_online),
          blocked: Boolean(r.is_blocked),
          active: Number(r.active || 0),
          delivered: Number(r.delivered || 0),
        }))
      );
    })
  );

  // ============================================================
  // ADMIN: REVIEWS (reply + hide/show)
  // ============================================================
  app.get(
    "/admin/reviews",
    requireAuth(...ORDER_VIEW),
    wrap(async (_req, res) => {
      const rows = db
        .prepare(
          `SELECT r.*, u.name AS customer_name
           FROM reviews r
           JOIN users u ON u.id = r.user_id
           ORDER BY r.created_at DESC
           LIMIT 100`
        )
        .all() as Record<string, any>[];
      const summary = db
        .prepare("SELECT COUNT(*) AS count, COALESCE(ROUND(AVG(rating), 2), 0) AS avg FROM reviews WHERE hidden = 0")
        .get() as { count: number; avg: number };
      res.json({
        summary: { count: Number(summary?.count || 0), avg: Number(summary?.avg || 0) },
        reviews: rows.map((r) => ({
          id: r.id,
          orderId: r.order_id,
          customerName: r.customer_name,
          rating: r.rating,
          comment: r.comment,
          reply: r.reply,
          hidden: Boolean(r.hidden),
          createdAt: r.created_at,
        })),
      });
    })
  );

  app.patch(
    "/admin/reviews/:id",
    requireAuth(...ORDER_VIEW),
    wrap(async (req, res) => {
      const id = UUID.parse(req.params.id);
      const b = z
        .object({ hidden: z.boolean().optional(), reply: z.string().trim().min(1).max(300).optional() })
        .refine((v) => v.hidden !== undefined || v.reply, { message: "Nothing to change" })
        .parse(req.body);
      const existing = db.prepare("SELECT id, hidden, reply FROM reviews WHERE id = ?").get(id) as Record<string, any> | undefined;
      if (!existing) throw new HttpError(404, "Not found");
      db.prepare("UPDATE reviews SET hidden = ?, reply = ? WHERE id = ?").run(
        b.hidden !== undefined ? (b.hidden ? 1 : 0) : existing.hidden,
        b.reply !== undefined ? b.reply : existing.reply,
        id
      );
      audit(req, req.user!.id, "review_updated", { reviewId: id, hidden: b.hidden });
      res.sendStatus(204);
    })
  );

  // ============================================================
  // ADMIN: MARKETING (push notifications + coupons)
  // ============================================================
  app.get(
    "/admin/notifications",
    requireAuth(...STAFF),
    wrap(async (_req, res) => {
      const rows = db
        .prepare('SELECT id, audience, title, body, sent_count AS "sentCount", created_at AS "createdAt" FROM notifications ORDER BY created_at DESC LIMIT 50')
        .all();
      res.json(rows);
    })
  );

  app.post(
    "/admin/notifications",
    requireAuth(...MARKETING),
    wrap(async (req, res) => {
      const b = z
        .object({
          title: z.string().trim().min(2).max(60),
          body: z.string().trim().min(2).max(200),
          audience: z.enum(["all", "one"]),
          phone: PHONE.optional(),
        })
        .refine((v) => v.audience === "all" || v.phone, { message: "Customer phone is required" })
        .parse(req.body);

      let userId: string | null = null;
      let sent = 0;

      if (b.audience === "one") {
        const u = db.prepare("SELECT id FROM users WHERE phone_hash = ? AND role = 'customer'").get(blindIndex(b.phone!)) as
          | { id: string }
          | undefined;
        if (!u) throw new HttpError(404, "No customer with that mobile number");
        userId = u.id;
        sent = (db.prepare("SELECT COUNT(*) as c FROM device_tokens WHERE user_id = ?").get(u.id) as { c: number }).c;
      } else {
        const tenMinAgo = new Date(Date.now() - 10 * 60_000).toISOString();
        const recentBroadcast = db
          .prepare("SELECT 1 FROM notifications WHERE audience = 'all' AND datetime(created_at) > datetime(?) LIMIT 1")
          .get(tenMinAgo);
        if (recentBroadcast) {
          throw new HttpError(429, "A broadcast was already sent in the last 10 minutes");
        }
        sent = (
          db
            .prepare("SELECT COUNT(*) as c FROM device_tokens t JOIN users u ON u.id = t.user_id WHERE u.role = 'customer' AND u.is_blocked = 0")
            .get() as { c: number }
        ).c;
      }

      const id = crypto.randomUUID();
      db.prepare("INSERT INTO notifications (id, sent_by, audience, user_id, title, body, sent_count) VALUES (?, ?, ?, ?, ?, ?, ?)").run(
        id,
        req.user!.id,
        b.audience,
        userId,
        b.title,
        b.body,
        sent
      );
      audit(req, req.user!.id, "notification_sent", { audience: b.audience, sent });
      res.status(201).json({ id, sent });
    })
  );

  app.get(
    "/admin/coupons",
    requireAuth(...MARKETING),
    wrap(async (_req, res) => {
      const rows = db.prepare("SELECT * FROM coupons ORDER BY active DESC, expires_at DESC").all() as Record<string, any>[];
      res.json(
        rows.map((c) => ({
          code: c.code,
          discountType: c.discount_type,
          discountValue: c.percent_off,
          maxDiscountPaise: c.max_discount_paise,
          minOrderPaise: c.min_order_paise,
          maxRedemptions: c.max_redemptions,
          redeemedCount: c.redeemed_count,
          expiresAt: c.expires_at,
          active: Boolean(c.active),
        }))
      );
    })
  );

  app.post(
    "/admin/coupons",
    requireAuth(...MARKETING),
    wrap(async (req, res) => {
      const b = z
        .object({
          code: z.string().trim().toUpperCase().min(3).max(20).regex(/^[A-Z0-9_-]+$/),
          discountType: z.enum(["percentage", "fixed"]),
          discountValue: z.number().int().min(1).max(10000),
          maxDiscountPaise: z.number().int().min(100).max(500_000).default(15000),
          minOrderPaise: z.number().int().min(0).max(500_000).default(0),
          maxRedemptions: z.number().int().min(1).max(100_000).default(100),
          expiresAt: z.string().min(8),
        })
        .parse(req.body);
      if (b.discountType === "percentage" && b.discountValue > 50) {
        throw new HttpError(400, "Percentage discount cannot exceed 50%");
      }
      try {
        db.prepare(
          `INSERT INTO coupons (code, discount_type, percent_off, max_discount_paise, min_order_paise, max_redemptions, expires_at, active)
           VALUES (?, ?, ?, ?, ?, ?, ?, 1)`
        ).run(b.code, b.discountType, b.discountValue, b.maxDiscountPaise, b.minOrderPaise, b.maxRedemptions, b.expiresAt);
      } catch {
        throw new HttpError(409, "Coupon code already exists");
      }
      audit(req, req.user!.id, "coupon_created", { code: b.code });
      res.status(201).json({ code: b.code });
    })
  );

  app.put(
    "/admin/coupons/:code/deactivate",
    requireAuth(...MARKETING),
    wrap(async (req, res) => {
      const code = z.string().trim().toUpperCase().min(3).max(20).parse(req.params.code);
      const r = db.prepare("UPDATE coupons SET active = 0 WHERE code = ?").run(code);
      if (!r.changes) throw new HttpError(404, "Not found");
      audit(req, req.user!.id, "coupon_deactivated", { code });
      res.json({ ok: true });
    })
  );

  // ============================================================
  // ADMIN: 4:5 IN-APP POPUP CAMPAIGNS (persistent + real uploads)
  // ============================================================
  const PopupSchema = z.object({
    tag: z.string().trim().max(30).default(""),
    title: z.string().trim().min(2).max(80),
    description: z.string().trim().max(240).default(""),
    buttonText: z.string().trim().min(1).max(40),
    imageUrl: z.string().regex(/^\/media\/[a-f0-9]{32}\.(webp|jpg|png|gif)$/, "Upload a valid 4:5 campaign image"),
  });

  const popupRow = (r: Record<string, any>) => ({
    id: r.id,
    tag: r.tag,
    title: r.title,
    description: r.description,
    buttonText: r.button_text,
    imageUrl: r.image_url,
    active: Boolean(r.active),
    createdAt: r.created_at,
  });

  app.get(
    "/popups/active",
    wrap(async (_req, res) => {
      const rows = db
        .prepare("SELECT * FROM popup_campaigns WHERE active = 1 ORDER BY created_at DESC LIMIT 10")
        .all() as Record<string, any>[];
      res.json(rows.map(popupRow));
    })
  );

  app.get(
    "/admin/popups",
    requireAuth(...MARKETING),
    wrap(async (_req, res) => {
      const rows = db.prepare("SELECT * FROM popup_campaigns ORDER BY created_at DESC LIMIT 50").all() as Record<string, any>[];
      res.json(rows.map(popupRow));
    })
  );

  app.post(
    "/admin/popups/image",
    requireAuth(...MARKETING),
    (req, res, next) => upload(req, res, (e) => (e ? next(new HttpError(400, "Image must be under 4 MB")) : next())),
    wrap(async (req, res) => {
      if (!req.file) throw new HttpError(400, "No image received");
      const ext = detectImageExt(req.file.buffer);
      if (!ext) throw new HttpError(400, "File is not a valid PNG, JPEG, WebP, or GIF image");
      const filename = `${crypto.randomBytes(16).toString("hex")}.${ext}`;
      await fs.promises.writeFile(path.join(UPLOAD_DIR, filename), req.file.buffer);
      res.status(201).json({ imageUrl: `/media/${filename}` });
    })
  );

  app.post(
    "/admin/popups",
    requireAuth(...MARKETING),
    wrap(async (req, res) => {
      const b = PopupSchema.parse(req.body);
      const id = crypto.randomUUID();
      db.prepare(
        `INSERT INTO popup_campaigns (id, tag, title, description, button_text, image_url, active, created_by)
         VALUES (?, ?, ?, ?, ?, ?, 1, ?)`
      ).run(id, b.tag, b.title, b.description, b.buttonText, b.imageUrl, req.user!.id);
      audit(req, req.user!.id, "popup_created", { popupId: id, title: b.title });
      const created = db.prepare("SELECT * FROM popup_campaigns WHERE id = ?").get(id) as Record<string, any>;
      res.status(201).json(popupRow(created));
    })
  );

  app.patch(
    "/admin/popups/:id",
    requireAuth(...MARKETING),
    wrap(async (req, res) => {
      const id = UUID.parse(req.params.id);
      const { active } = z.object({ active: z.boolean() }).parse(req.body);
      const r = db.prepare("UPDATE popup_campaigns SET active = ? WHERE id = ?").run(active ? 1 : 0, id);
      if (!r.changes) throw new HttpError(404, "Not found");
      audit(req, req.user!.id, "popup_updated", { popupId: id, active });
      const updated = db.prepare("SELECT * FROM popup_campaigns WHERE id = ?").get(id) as Record<string, any>;
      res.json(popupRow(updated));
    })
  );

  app.delete(
    "/admin/popups/:id",
    requireAuth(...MARKETING),
    wrap(async (req, res) => {
      const id = UUID.parse(req.params.id);
      const r = db.prepare("DELETE FROM popup_campaigns WHERE id = ?").run(id);
      if (!r.changes) throw new HttpError(404, "Not found");
      audit(req, req.user!.id, "popup_deleted", { popupId: id });
      res.sendStatus(204);
    })
  );

  // ============================================================
  // ADMIN: PAYMENTS (Super Admin only — strict live Razorpay mode)
  // ============================================================
  const PID = z.string().regex(/^[A-Za-z0-9_]{6,40}$/);

  function isRazorpayConfigured(): boolean {
    return Boolean(process.env.RAZORPAY_KEY_ID?.trim() && process.env.RAZORPAY_KEY_SECRET?.trim());
  }

  async function razorpayGateway(method: string, endpoint: string, body?: unknown, headers: Record<string, string> = {}) {
    const keyId = process.env.RAZORPAY_KEY_ID?.trim();
    const keySecret = process.env.RAZORPAY_KEY_SECRET?.trim();
    if (!keyId || !keySecret) {
      throw new HttpError(
        503,
        "Razorpay credentials (RAZORPAY_KEY_ID and RAZORPAY_KEY_SECRET) are not configured on the server."
      );
    }
    const r = await fetch(`https://api.razorpay.com/v1${endpoint}`, {
      method,
      signal: AbortSignal.timeout(10_000),
      body: body ? JSON.stringify(body) : undefined,
      headers: {
        Authorization: "Basic " + Buffer.from(`${keyId}:${keySecret}`).toString("base64"),
        "Content-Type": "application/json",
        ...headers,
      },
    });
    const j = (await r.json().catch(() => ({}))) as any;
    if (!r.ok) throw new HttpError(502, j?.error?.description || "Payment gateway error");
    return j;
  }

  app.get(
    "/admin/payments",
    requireAuth(...OWNER),
    wrap(async (_req, res) => {
      const rows = db
        .prepare(
          `SELECT p.provider_payment_id AS id, p.order_id AS "orderId", p.amount_paise AS "amountPaise",
                  p.created_at AS "createdAt", p.refund_id AS "refundId", p.refunded_at AS "refundedAt",
                  o.status AS "orderStatus", o.total_paise AS "orderTotalPaise"
           FROM payments p
           JOIN orders o ON o.id = p.order_id
           ORDER BY p.created_at DESC
           LIMIT 100`
        )
        .all() as Record<string, any>[];
      res.json({
        gatewayConfigured: isRazorpayConfigured(),
        payments: rows.map((p) => ({
          ...p,
          refundDue: p.orderStatus === "cancelled" && !p.refundedAt,
          mismatch: p.amountPaise !== p.orderTotalPaise,
        })),
      });
    })
  );

  app.post(
    "/admin/payments/:pid/verify",
    requireAuth(...OWNER),
    wrap(async (req, res) => {
      const pid = PID.parse(req.params.pid);
      const p = db
        .prepare(
          `SELECT p.amount_paise, p.refunded_at, o.total_paise
           FROM payments p JOIN orders o ON o.id = p.order_id
           WHERE p.provider_payment_id = ?`
        )
        .get(pid) as { amount_paise: number; refunded_at: string | null; total_paise: number } | undefined;
      if (!p) throw new HttpError(404, "Not found");

      const g = await razorpayGateway("GET", `/payments/${pid}`);
      res.json({
        gatewayStatus: g.status,
        gatewayAmountPaise: g.amount,
        refundedPaise: g.amount_refunded,
        matches: g.amount === p.amount_paise && ["captured", "refunded"].includes(g.status),
      });
    })
  );

  app.post(
    "/admin/payments/:pid/refund",
    requireAuth(...OWNER),
    wrap(async (req, res) => {
      const pid = PID.parse(req.params.pid);
      const p = db
        .prepare(
          `SELECT p.*, o.status AS order_status
           FROM payments p JOIN orders o ON o.id = p.order_id
           WHERE p.provider_payment_id = ?`
        )
        .get(pid) as Record<string, any> | undefined;
      if (!p) throw new HttpError(404, "Not found");
      if (p.refunded_at) throw new HttpError(409, "Already refunded");
      if (p.order_status !== "cancelled") throw new HttpError(409, "Only cancelled orders can be refunded");

      const g = await razorpayGateway("POST", `/payments/${pid}/refund`, { amount: p.amount_paise }, { "X-Refund-Idempotency": pid });
      if (!g?.id) throw new HttpError(502, "Razorpay did not return a refund ID");
      const refundId = String(g.id);
      db.prepare("UPDATE payments SET refund_id = ?, refunded_at = ? WHERE provider_payment_id = ?").run(
        refundId,
        new Date().toISOString(),
        pid
      );
      audit(req, req.user!.id, "payment_refunded", { paymentId: pid, refundId });
      res.json({ ok: true, refundId });
    })
  );

  // ============================================================
  // ADMIN: STAFF ACCOUNTS + AUDIT LOG (Super Admin only)
  // ============================================================
  app.get(
    "/admin/staff",
    requireAuth(...OWNER),
    wrap(async (_req, res) => {
      const rows = db
        .prepare("SELECT id, name, role, phone_enc, is_blocked, created_at FROM users WHERE role <> 'customer' ORDER BY role, name")
        .all() as Record<string, any>[];
      res.json(
        rows.map((u) => ({
          id: u.id,
          name: u.name,
          role: u.role,
          phone: decrypt(u.phone_enc),
          blocked: Boolean(u.is_blocked),
          createdAt: u.created_at,
        }))
      );
    })
  );

  app.post(
    "/admin/staff",
    requireAuth(...OWNER),
    wrap(async (req, res) => {
      const b = z
        .object({
          name: z.string().trim().min(2).max(60),
          phone: PHONE,
          password: z.string().min(10).max(72),
          role: z.enum([...STAFF, "rider"]),
        })
        .parse(req.body);
      const id = crypto.randomUUID();
      const pwHash = await hashPassword(b.password);
      try {
        db.prepare("INSERT INTO users (id, name, phone_enc, phone_hash, password_hash, role) VALUES (?, ?, ?, ?, ?, ?)").run(
          id,
          b.name,
          encrypt(b.phone),
          blindIndex(b.phone),
          pwHash,
          b.role
        );
        audit(req, req.user!.id, "staff_created", { userId: id, role: b.role });
        res.status(201).json({ id });
      } catch {
        throw new HttpError(409, "That mobile number is already registered");
      }
    })
  );

  app.get(
    "/admin/audit",
    requireAuth(...OWNER),
    wrap(async (_req, res) => {
      const rows = db
        .prepare(
          `SELECT a.id, a.action, a.detail, a.ip, a.created_at AS "createdAt", u.name AS "actorName", u.role AS "actorRole"
           FROM audit_log a
           LEFT JOIN users u ON u.id = a.user_id
           ORDER BY a.id DESC
           LIMIT 50`
        )
        .all() as Record<string, any>[];
      res.json(
        rows.map((r) => ({
          ...r,
          detail: (() => {
            try {
              return JSON.parse(r.detail);
            } catch {
              return {};
            }
          })(),
        }))
      );
    })
  );

  // ============================================================
  // ADMIN: RESTAURANT SETTINGS + WEB PUSH SUBSCRIPTION
  // ============================================================
  app.get(
    "/admin/settings",
    requireAuth(...STAFF),
    wrap(async (_req, res) => {
      const rows = db.prepare("SELECT key, value FROM settings").all() as { key: string; value: string }[];
      const map: Record<string, string> = {};
      for (const r of rows) map[r.key] = r.value;
      res.json({
        restaurantOpen: map.restaurantOpen === "true",
        autoAcceptOrders: map.autoAcceptOrders === "true",
        orderSoundEnabled: map.orderSoundEnabled !== "false",
        restaurantName: map.restaurantName || "",
        restaurantPhone: map.restaurantPhone || "",
        restaurantAddress: map.restaurantAddress || "",
      });
    })
  );

  app.put(
    "/admin/settings",
    requireAuth(...ORDER_STAFF),
    wrap(async (req, res) => {
      const b = z
        .object({
          restaurantOpen: z.boolean(),
          autoAcceptOrders: z.boolean(),
          orderSoundEnabled: z.boolean(),
          restaurantName: z.string().trim().min(2).max(80),
          restaurantPhone: z.string().trim().min(6).max(25),
          restaurantAddress: z.string().trim().min(5).max(250),
        })
        .parse(req.body);
      const upsert = db.prepare("INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)");
      const tx = db.transaction(() => {
        upsert.run("restaurantOpen", String(b.restaurantOpen));
        upsert.run("autoAcceptOrders", String(b.autoAcceptOrders));
        upsert.run("orderSoundEnabled", String(b.orderSoundEnabled));
        upsert.run("restaurantName", b.restaurantName);
        upsert.run("restaurantPhone", b.restaurantPhone);
        upsert.run("restaurantAddress", b.restaurantAddress);
      });
      tx();
      audit(req, req.user!.id, "settings_updated", { restaurantOpen: b.restaurantOpen });
      res.json(b);
    })
  );

  app.get("/admin/push/key", requireAuth(...ORDER_STAFF), (_req, res) => {
    res.json({ key: process.env.VAPID_PUBLIC_KEY || null });
  });

  const PUSH_HOSTS = /^https:\/\/([a-z0-9-]+\.)*(googleapis\.com|mozilla\.com|push\.apple\.com|windows\.com)\//;
  app.post(
    "/admin/push/subscribe",
    requireAuth(...ORDER_STAFF),
    wrap(async (req, res) => {
      const b = z
        .object({
          endpoint: z.string().url().max(1000).regex(PUSH_HOSTS),
          keys: z.object({ p256dh: z.string().max(200), auth: z.string().max(100) }),
        })
        .parse(req.body);
      db.prepare(
        `INSERT INTO push_subscriptions (endpoint, user_id, p256dh, auth) VALUES (?, ?, ?, ?)
         ON CONFLICT(endpoint) DO UPDATE SET user_id = excluded.user_id, p256dh = excluded.p256dh, auth = excluded.auth`
      ).run(b.endpoint, req.user!.id, b.keys.p256dh, b.keys.auth);
      res.sendStatus(204);
    })
  );

  app.get("/health", (_req, res) => res.json({ ok: true }));

  // ============================================================
  // VITE MIDDLEWARE (DEV) OR STATIC DIST (PROD)
  // ============================================================
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.join(__dirname, "dist")));
    app.get("*", (_req, res) => {
      res.sendFile(path.join(__dirname, "dist", "index.html"));
    });
  }

  // Centralized error handler (never leaks stack traces or request bodies)
  app.use((err: any, _req: Request, res: Response, _next: NextFunction) => {
    if (err instanceof z.ZodError) {
      return res.status(400).json({ error: "Invalid input", fields: err.issues.map((i) => i.path.join(".")) });
    }
    if (err instanceof HttpError) {
      return res.status(err.status).json({ error: err.message });
    }
    console.error("Unhandled error:", err?.message);
    res.status(500).json({ error: "Something went wrong" });
  });

  const PORT = Number(process.env.PORT) || 3000;
  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Easy Admin server running on http://localhost:${PORT}`);
  });
}

startServer();
