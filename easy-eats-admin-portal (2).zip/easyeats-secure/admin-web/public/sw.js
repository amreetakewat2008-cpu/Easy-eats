// Shows a new-order alert even when the panel tab is closed (Web Push).
self.addEventListener('push', (e) => {
  const d = e.data ? e.data.json() : {};
  e.waitUntil(self.registration.showNotification(d.title || 'New order', {
    body: d.body, tag: d.orderId, renotify: true, requireInteraction: true,
    vibrate: [300, 150, 300, 150, 300], data: d,
  }));
});
self.addEventListener('notificationclick', (e) => {
  e.notification.close();
  e.waitUntil(self.clients.matchAll({ type: 'window', includeUncontrolled: true }).then((list) => {
    const open = list.find((c) => c.url.includes('/panel/'));
    return open ? open.focus() : self.clients.openWindow('/panel/#/orders');
  }));
});
