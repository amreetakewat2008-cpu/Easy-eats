// "Call-style" order alert: a looping ringtone (generated with Web Audio, no sound file needed),
// vibration, and Web Push so the phone alerts even when the panel tab is closed.
import { api } from './api';

let ctx = null;
let timer = null;

export const audioReady = () => ctx?.state === 'running';
export function unlockAudio() {          // browsers only allow sound after a tap, so call this from a button
  ctx ??= new (window.AudioContext || window.webkitAudioContext)();
  return ctx.resume();
}

function beep(at, freq) {
  const o = ctx.createOscillator();
  const g = ctx.createGain();
  o.frequency.value = freq;
  o.connect(g);
  g.connect(ctx.destination);
  g.gain.setValueAtTime(0.0001, at);
  g.gain.exponentialRampToValueAtTime(0.5, at + 0.03);
  g.gain.exponentialRampToValueAtTime(0.0001, at + 0.35);
  o.start(at);
  o.stop(at + 0.4);
}
export function startRing() {
  if (timer || !audioReady()) return;
  const play = () => {
    const t = ctx.currentTime;
    beep(t, 880); beep(t + 0.45, 660); beep(t + 0.9, 880);
    navigator.vibrate?.([300, 150, 300]);
  };
  play();
  timer = setInterval(play, 2200);
}
export function stopRing() { clearInterval(timer); timer = null; }

const b64ToU8 = (s) => Uint8Array.from(atob(s.replace(/-/g, '+').replace(/_/g, '/')), (c) => c.charCodeAt(0));

export async function enablePush() {
  if (!('serviceWorker' in navigator) || !('PushManager' in window) || typeof Notification === 'undefined') return false;
  if ((await Notification.requestPermission()) !== 'granted') return false;
  const reg = await navigator.serviceWorker.register('/panel/sw.js');
  const { key } = await api('/admin/push/key');
  const sub = (await reg.pushManager.getSubscription())
    ?? (await reg.pushManager.subscribe({ userVisibleOnly: true, applicationServerKey: b64ToU8(key) }));
  await api('/admin/push/subscribe', { method: 'POST', body: sub.toJSON() });
  return true;
}
