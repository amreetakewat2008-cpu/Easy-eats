import { useCallback, useEffect, useRef, useState } from 'react';
import { BarChart3, Bike, CreditCard, LogOut, Megaphone, Menu, Package, ShieldCheck, ShoppingBag, Star, Users, X } from 'lucide-react';
import { api, login, logout, onSessionExpired, openStream, restoreSession } from './api';
import { audioReady, enablePush, unlockAudio } from './alerts';
import { Err } from './ui';
import Incoming from './Incoming';
import Dashboard from './pages/Dashboard';
import Orders from './pages/Orders';
import Catalogue from './pages/Catalogue';
import Riders from './pages/Riders';
import Customers from './pages/Customers';
import Marketing from './pages/Marketing';
import Reviews from './pages/Reviews';
import Payments from './pages/Payments';
import Staff from './pages/Staff';

const ALL = ['super_admin', 'restaurant_manager', 'marketing_lead', 'customer_support'];
const KITCHEN = ['super_admin', 'restaurant_manager'];
// The server enforces these same rules; this only decides what the menu shows.
const NAV = [
  { id: 'dashboard', label: 'Dashboard', icon: BarChart3, roles: ALL, Page: Dashboard },
  { id: 'orders', label: 'Orders', icon: ShoppingBag, roles: [...KITCHEN, 'customer_support'], Page: Orders },
  { id: 'catalogue', label: 'Catalogue', icon: Package, roles: KITCHEN, Page: Catalogue },
  { id: 'riders', label: 'Riders', icon: Bike, roles: KITCHEN, Page: Riders },
  { id: 'customers', label: 'Customers', icon: Users, roles: ['super_admin', 'customer_support'], Page: Customers },
  { id: 'marketing', label: 'Marketing', icon: Megaphone, roles: ['super_admin', 'marketing_lead'], Page: Marketing },
  { id: 'reviews', label: 'Reviews', icon: Star, roles: [...KITCHEN, 'customer_support'], Page: Reviews },
  { id: 'payments', label: 'Payments', icon: CreditCard, roles: ['super_admin'], Page: Payments },
  { id: 'staff', label: 'Staff', icon: ShieldCheck, roles: ['super_admin'], Page: Staff },
];
const ROLE_LABEL = { super_admin: 'Super Admin', restaurant_manager: 'Restaurant Manager', marketing_lead: 'Marketing Lead', customer_support: 'Customer Support' };

function useHash() {
  const read = () => location.hash.replace(/^#\/?/, '');
  const [h, setH] = useState(read);
  useEffect(() => {
    const f = () => setH(read());
    addEventListener('hashchange', f);
    return () => removeEventListener('hashchange', f);
  }, []);
  return h;
}

function Login({ onLogin }) {
  const [phone, setPhone] = useState('');
  const [password, setPassword] = useState('');
  const [err, setErr] = useState('');
  const [busy, setBusy] = useState(false);
  const submit = async (e) => {
    e.preventDefault();
    unlockAudio();                       // must happen inside the tap so order alerts can play later
    setBusy(true); setErr('');
    try { onLogin(await login(phone.trim(), password)); } catch (x) { setErr(x.message); } finally { setBusy(false); }
  };
  return (
    <div className="center">
      <form className="card login" onSubmit={submit}>
        <h1>Easy Admin</h1>
        <input inputMode="numeric" autoComplete="username" placeholder="Mobile number" value={phone} onChange={(e) => setPhone(e.target.value)} required />
        <input type="password" autoComplete="current-password" placeholder="Password" value={password} onChange={(e) => setPassword(e.target.value)} required />
        <Err msg={err} />
        <button className="primary" disabled={busy}>{busy ? 'Signing in…' : 'Sign in'}</button>
      </form>
    </div>
  );
}

function Shell({ me, onLogout }) {
  const route = useHash();
  const [open, setOpen] = useState(false);
  const [tick, setTick] = useState(0);
  const [queue, setQueue] = useState([]);
  const queueRef = useRef([]);
  queueRef.current = queue;
  const nav = NAV.filter((n) => n.roles.includes(me.role));
  const current = nav.find((n) => n.id === route) ?? nav[0];
  const canAct = KITCHEN.includes(me.role);

  const addOrder = useCallback(async (id) => {
    try {
      const o = await api(`/admin/orders/${id}`);
      if (o.status === 'placed') setQueue((q) => (q.some((x) => x.id === id) ? q : [...q, o]));
    } catch { /* the next poll retries */ }
  }, []);

  useEffect(() => {
    if (!canAct) return undefined;
    if (typeof Notification !== 'undefined' && Notification.permission === 'granted') enablePush().catch(() => {});
    // The stream is instant; the poll is a safety net for anything missed while offline.
    const poll = async () => {
      try { for (const o of await api('/admin/orders?status=placed')) if (!queueRef.current.some((x) => x.id === o.id)) await addOrder(o.id); } catch { /* retry */ }
    };
    poll();
    const t = setInterval(poll, 15000);
    const stop = openStream((ev, d) => {
      if (ev === 'new_order') setQueue((q) => (q.some((x) => x.id === d.id) ? q : [...q, d]));
      if (ev === 'order_status') setQueue((q) => q.filter((x) => x.id !== d.id));
      setTick((n) => n + 1);
    });
    return () => { clearInterval(t); stop(); };
  }, [canAct, addOrder]);

  const needAlerts = canAct && (!audioReady() || (typeof Notification !== 'undefined' && Notification.permission === 'default'));
  const turnOn = async () => { await unlockAudio(); await enablePush().catch(() => {}); setTick((n) => n + 1); };

  return (
    <div className="shell">
      <aside className={open ? 'side open' : 'side'}>
        <div className="row between brand"><b>Easy Admin</b><button className="ghost mobile-only" onClick={() => setOpen(false)}><X size={18} /></button></div>
        {nav.map(({ id, label, icon: Icon }) => (
          <a key={id} href={`#/${id}`} className={current.id === id ? 'active' : ''} onClick={() => setOpen(false)}><Icon size={18} />{label}</a>
        ))}
      </aside>
      <main>
        <header className="top row between">
          <button className="ghost mobile-only" onClick={() => setOpen(true)}><Menu size={22} /></button>
          <span className="muted">{me.name} · {ROLE_LABEL[me.role]}</span>
          <button className="ghost" onClick={onLogout}><LogOut size={18} /> Sign out</button>
        </header>
        {needAlerts && (
          <div className="banner"><span>Turn on alerts so new orders ring like a call.</span><button className="primary" onClick={turnOn}>Turn on</button></div>
        )}
        <div className="page"><current.Page tick={tick} canAct={canAct} me={me} /></div>
      </main>
      {canAct && <Incoming queue={queue} onResolved={(id) => setQueue((q) => q.filter((x) => x.id !== id))} />}
    </div>
  );
}

export default function App() {
  const [me, setMe] = useState(undefined);   // undefined = still checking for an existing session
  useEffect(() => {
    onSessionExpired(() => setMe(null));
    restoreSession().then(setMe);
  }, []);
  if (me === undefined) return <div className="center muted">Loading…</div>;
  if (!me) return <Login onLogin={setMe} />;
  return <Shell me={me} onLogout={async () => { await logout(); setMe(null); }} />;
}
