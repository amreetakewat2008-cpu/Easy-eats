import { useEffect, useState } from 'react';
import { PhoneCall } from 'lucide-react';
import { api } from './api';
import { startRing, stopRing } from './alerts';
import { Err, money } from './ui';

const REASONS = ['Item unavailable', 'Kitchen is closed', 'Too busy right now'];

// Full-screen "incoming call" for the oldest order waiting for a decision. Rings until answered.
export default function Incoming({ queue, onResolved }) {
  const order = queue[0];
  const [now, setNow] = useState(Date.now());
  const [err, setErr] = useState('');
  const [rejecting, setRejecting] = useState(false);

  useEffect(() => {
    if (!order) return undefined;
    startRing();
    const t = setInterval(() => setNow(Date.now()), 1000);
    return () => { stopRing(); clearInterval(t); };
  }, [order?.id]);   // eslint-disable-line react-hooks/exhaustive-deps

  if (!order) return null;
  const left = order.expiresAt ? Math.max(0, Math.floor((new Date(order.expiresAt).getTime() - now) / 1000)) : null;
  const run = async (fn) => {
    setErr('');
    try { await fn(); setRejecting(false); onResolved(order.id); } catch (e) { setErr(e.message); }
  };
  const accept = () => run(() => api(`/orders/${order.id}/status`, { method: 'PATCH', body: { to: 'accepted' } }));
  const reject = (reason) => run(() => api(`/admin/orders/${order.id}/reject`, { method: 'POST', body: { reason } }));

  return (
    <div className="ring">
      <div className="ring-card">
        <div className="pulse"><PhoneCall size={34} /></div>
        <h2>Incoming order</h2>
        <p className="muted">{order.customerName} · {order.paymentMethod === 'cod' ? 'Cash on delivery' : 'Paid online'}</p>
        <ul className="plain">{order.items.map((i) => <li key={i.name}>{i.qty} × {i.name}</li>)}</ul>
        <p className="big">{money(order.totalPaise)}</p>
        {left !== null && <p className="muted">Auto-cancels in {Math.floor(left / 60)}:{String(left % 60).padStart(2, '0')}</p>}
        {queue.length > 1 && <p className="muted">+{queue.length - 1} more waiting</p>}
        <Err msg={err} />
        {rejecting ? (
          <div className="col">
            {REASONS.map((r) => <button key={r} onClick={() => reject(r)}>{r}</button>)}
            <button className="ghost" onClick={() => setRejecting(false)}>Back</button>
          </div>
        ) : (
          <div className="row">
            <button className="danger" onClick={() => setRejecting(true)}>Reject</button>
            <button className="ok" onClick={accept}>Accept</button>
          </div>
        )}
      </div>
    </div>
  );
}
