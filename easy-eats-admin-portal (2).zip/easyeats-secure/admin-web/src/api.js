// All server calls. The access token lives in memory only; the refresh token is an httpOnly cookie.
let accessToken = null;
let onExpired = () => {};
export const onSessionExpired = (fn) => { onExpired = fn; };

let refreshing = null;
function refresh() {
  refreshing ??= fetch('/admin/auth/refresh', { method: 'POST' })
    .then(async (r) => {
      if (!r.ok) return null;
      const j = await r.json();
      accessToken = j.accessToken;
      return j.user;
    })
    .catch(() => null)
    .finally(() => { refreshing = null; });
  return refreshing;
}
export const restoreSession = refresh;

export async function login(phone, password) {
  const r = await fetch('/admin/auth/login', {
    method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ phone, password }),
  });
  const j = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(j.error || 'Could not sign in');
  accessToken = j.accessToken;
  return j.user;
}

export async function logout() {
  await fetch('/admin/auth/logout', { method: 'POST' }).catch(() => {});
  accessToken = null;
}

export async function api(path, { method = 'GET', body, form } = {}, retried = false) {
  const headers = { Authorization: `Bearer ${accessToken}` };
  if (body) headers['Content-Type'] = 'application/json';
  const r = await fetch(path, { method, headers, body: form ?? (body ? JSON.stringify(body) : undefined) });
  if (r.status === 401 && !retried) {
    if (await refresh()) return api(path, { method, body, form }, true);
    onExpired();
  }
  const data = r.status === 204 ? null : await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(data?.fields?.length ? `${data.error}: ${data.fields.join(', ')}` : data?.error || 'Request failed');
  return data;
}

// Live events (new_order, order_status). Reconnects by itself; the server recycles the stream every 10 minutes.
export function openStream(onEvent) {
  const ctrl = new AbortController();
  (async () => {
    let wait = 1000;
    while (!ctrl.signal.aborted) {
      try {
        const r = await fetch('/admin/stream', { headers: { Authorization: `Bearer ${accessToken}` }, signal: ctrl.signal });
        if (r.status === 401) await refresh();
        else if (r.ok && r.body) {
          wait = 1000;
          const reader = r.body.pipeThrough(new TextDecoderStream()).getReader();
          let buf = '';
          for (;;) {
            const { value, done } = await reader.read();
            if (done) break;
            buf += value;
            let i;
            while ((i = buf.indexOf('\n\n')) >= 0) {
              const chunk = buf.slice(0, i);
              buf = buf.slice(i + 2);
              const ev = /^event: (.*)$/m.exec(chunk)?.[1];
              const data = /^data: (.*)$/m.exec(chunk)?.[1];
              if (ev && data) onEvent(ev, JSON.parse(data));
            }
          }
        }
      } catch { if (ctrl.signal.aborted) return; }
      await new Promise((res) => setTimeout(res, wait));
      wait = Math.min(wait * 2, 15000);
    }
  })();
  return () => ctrl.abort();
}
