import { useState } from 'react';
import { api } from '../api';
import { Badge, Err, Modal, Veg, money, useLoad } from '../ui';

const EMPTY = { name: '', description: '', price: '', isVeg: true, category: '', keywords: '', imageUrl: null, isAvailable: true };

function ItemForm({ item, categories, onClose, onSaved }) {
  const [f, setF] = useState(item ? { ...item, price: String(item.pricePaise / 100), keywords: item.keywords.join(', ') } : EMPTY);
  const [err, setErr] = useState('');
  const [busy, setBusy] = useState(false);
  const set = (k) => (e) => setF({ ...f, [k]: e.target.type === 'checkbox' ? e.target.checked : e.target.value });

  const upload = async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    const form = new FormData();
    form.append('image', file);
    setBusy(true); setErr('');
    try { const r = await api('/admin/catalogue/image', { method: 'POST', form }); setF((x) => ({ ...x, imageUrl: r.imageUrl })); }
    catch (x) { setErr(x.message); } finally { setBusy(false); }
  };
  const save = async (e) => {
    e.preventDefault();
    setBusy(true); setErr('');
    const body = {
      name: f.name, description: f.description, pricePaise: Math.round(parseFloat(f.price) * 100), isVeg: f.isVeg,
      category: f.category, keywords: f.keywords.split(',').map((k) => k.trim()).filter(Boolean),
      imageUrl: f.imageUrl, isAvailable: f.isAvailable,
    };
    try { await api(item ? `/admin/catalogue/${item.id}` : '/admin/catalogue', { method: item ? 'PUT' : 'POST', body }); onSaved(); }
    catch (x) { setErr(x.message); } finally { setBusy(false); }
  };

  return (
    <Modal title={item ? 'Edit item' : 'Add item'} onClose={onClose}>
      <form className="col" onSubmit={save}>
        {f.imageUrl && <img className="photo" src={f.imageUrl} alt="" />}
        <input type="file" accept="image/*" onChange={upload} />
        <input placeholder="Title" value={f.name} onChange={set('name')} required />
        <textarea placeholder="Description" rows={3} value={f.description} onChange={set('description')} />
        <input type="number" step="0.01" min="1" placeholder="Price (₹)" value={f.price} onChange={set('price')} required />
        <input list="cats" placeholder="Category (e.g. Burgers)" value={f.category} onChange={set('category')} required />
        <datalist id="cats">{categories.map((c) => <option key={c} value={c} />)}</datalist>
        <div className="row">
          <label><input type="radio" checked={f.isVeg} onChange={() => setF({ ...f, isVeg: true })} /> Veg</label>
          <label><input type="radio" checked={!f.isVeg} onChange={() => setF({ ...f, isVeg: false })} /> Non-veg</label>
        </div>
        <input placeholder="Search keywords, comma separated (e.g. cheese, spicy, snack)" value={f.keywords} onChange={set('keywords')} />
        <label><input type="checkbox" checked={f.isAvailable} onChange={set('isAvailable')} /> Available to order</label>
        <Err msg={err} />
        <button className="primary" disabled={busy}>{busy ? 'Please wait…' : 'Save'}</button>
      </form>
    </Modal>
  );
}

export default function Catalogue() {
  const { data, error, reload } = useLoad(() => api('/admin/catalogue'));
  const [edit, setEdit] = useState(null);   // null = closed, {} = new item, item = editing
  const [q, setQ] = useState('');
  const items = (data ?? []).filter((i) => `${i.name} ${i.category} ${i.keywords.join(' ')}`.toLowerCase().includes(q.toLowerCase()));
  const categories = [...new Set((data ?? []).map((i) => i.category))];
  return (
    <>
      <div className="row between"><h2>Catalogue</h2><button className="primary" onClick={() => setEdit({})}>Add item</button></div>
      <input placeholder="Search items" value={q} onChange={(e) => setQ(e.target.value)} />
      <Err msg={error} />
      {items.map((i) => (
        <button key={i.id} className="item row" onClick={() => setEdit(i)}>
          {i.imageUrl ? <img className="thumb" src={i.imageUrl} alt="" /> : <div className="thumb" />}
          <div className="grow">
            <div className="row"><Veg veg={i.isVeg} /><b>{i.name}</b></div>
            <span className="muted">{i.category} · {money(i.pricePaise)}</span>
          </div>
          {!i.isAvailable && <Badge tone="red">Hidden</Badge>}
        </button>
      ))}
      {edit && <ItemForm item={edit.id ? edit : null} categories={categories} onClose={() => setEdit(null)} onSaved={() => { setEdit(null); reload(); }} />}
    </>
  );
}
