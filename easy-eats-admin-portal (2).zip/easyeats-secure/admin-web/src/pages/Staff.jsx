import { useState } from 'react';
import { api } from '../api';
import { Badge, Card, Err, useLoad } from '../ui';

const ROLES = [['restaurant_manager', 'Restaurant Manager'], ['marketing_lead', 'Marketing Lead'], ['customer_support', 'Customer Support'],
  ['super_admin', 'Super Admin'], ['rider', 'Rider']];

export default function Staff({ me }) {
  const { data, error, reload } = useLoad(() => api('/admin/staff'));
  const [f, setF] = useState({ name: '', phone: '', password: '', role: 'restaurant_manager' });
  const [err, setErr] = useState('');
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });
  const add = async (e) => {
    e.preventDefault(); setErr('');
    try { await api('/admin/staff', { method: 'POST', body: f }); setF({ name: '', phone: '', password: '', role: f.role }); reload(); } catch (x) { setErr(x.message); }
  };
  const block = async (u) => {
    if (!window.confirm(`${u.blocked ? 'Unblock' : 'Block'} ${u.name}?`)) return;
    try { await api(`/admin/users/${u.id}/block`, { method: 'PATCH', body: { blocked: !u.blocked } }); reload(); } catch (x) { setErr(x.message); }
  };
  return (
    <>
      <h2>Staff &amp; riders</h2>
      <Card title="Add an account">
        <form className="col" onSubmit={add}>
          <input placeholder="Full name" value={f.name} onChange={set('name')} required />
          <input inputMode="numeric" placeholder="Mobile number (they sign in with this)" value={f.phone} onChange={set('phone')} required />
          <input type="password" autoComplete="new-password" placeholder="Temporary password (10+ characters)" minLength={10} value={f.password} onChange={set('password')} required />
          <select value={f.role} onChange={set('role')}>{ROLES.map(([v, l]) => <option key={v} value={v}>{l}</option>)}</select>
          <Err msg={err || error} />
          <button className="primary">Create account</button>
        </form>
      </Card>
      {data?.map((u) => (
        <div key={u.id} className="item row between">
          <span><b>{u.name}</b><br /><span className="muted">{u.phone} · {u.role.replace(/_/g, ' ')}</span></span>
          <span>{u.blocked && <Badge tone="red">Blocked</Badge>} {u.id !== me.id && <button onClick={() => block(u)}>{u.blocked ? 'Unblock' : 'Block'}</button>}</span>
        </div>
      ))}
    </>
  );
}
