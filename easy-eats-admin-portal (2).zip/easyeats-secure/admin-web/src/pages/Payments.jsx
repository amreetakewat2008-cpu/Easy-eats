import { useState } from 'react';
import { api } from '../api';
import { Badge, Err, money, useLoad, when } from '../ui';

export default function Payments() {
  const { data, error, reload } = useLoad(() => api('/admin/payments'));
  const [note, setNote] = useState({});
  const [err, setErr] = useState('');
  const verify = async (id) => {
    setErr('');
    try {
      const r = await api(`/admin/payments/${id}/verify`, { method: 'POST' });
      setNote((n) => ({ ...n, [id]: r.matches ? `Verified with gateway: ${r.gatewayStatus}, ${money(r.gatewayAmountPaise)}` : `MISMATCH: gateway says ${r.gatewayStatus}, ${money(r.gatewayAmountPaise)}` }));
    } catch (e) { setErr(e.message); }
  };
  const refund = async (p) => {
    if (!window.confirm(`Refund ${money(p.amountPaise)} to the customer?`)) return;
    setErr('');
    try { await api(`/admin/payments/${p.id}/refund`, { method: 'POST' }); reload(); } catch (e) { setErr(e.message); }
  };
  return (
    <>
      <h2>Payments</h2>
      <Err msg={error || err} />
      {data?.length === 0 && <p className="muted">No payments yet.</p>}
      {data?.map((p) => (
        <div key={p.id} className="item">
          <div className="row between"><b>{money(p.amountPaise)}</b><span>{p.refundedAt ? <Badge tone="gray">Refunded</Badge> : p.refundDue ? <Badge tone="red">Refund due</Badge> : <Badge tone="green">Captured</Badge>}{p.mismatch && <Badge tone="red">Amount mismatch</Badge>}</span></div>
          <span className="muted">{p.id} · order #{p.orderId.slice(0, 8)} ({p.orderStatus}) · {when(p.createdAt)}</span>
          {note[p.id] && <span>{note[p.id]}</span>}
          <div className="row"><button onClick={() => verify(p.id)}>Verify with gateway</button>{p.refundDue && <button className="danger" onClick={() => refund(p)}>Refund</button>}</div>
        </div>
      ))}
    </>
  );
}
