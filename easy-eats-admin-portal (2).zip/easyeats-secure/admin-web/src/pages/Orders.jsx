import { useState } from 'react';
import { api } from '../api';
import { Badge, Err, Modal, STATUS_TONE, label, money, useLoad, when } from '../ui';

const TABS = [['', 'All'], ['placed', 'New'], ['under_review', 'Review'], ['accepted', 'Accepted'], ['preparing', 'Preparing'],
  ['out_for_delivery', 'On the way'], ['delivered', 'Delivered'], ['cancelled', 'Cancelled']];

function Detail({ id, canAct, onClose, onChange }) {
  const { data: o, error, reload } = useLoad(() => api(`/admin/orders/${id}`), [id]);
  const [err, setErr] = useState('');
  const [reason, setReason] = useState('');
  const run = async (fn) => { setErr(''); try { await fn(); await reload(); onChange(); } catch (e) { setErr(e.message); } };
  const move = (to) => run(() => api(`/orders/${id}/status`, { method: 'PATCH', body: { to } }));
  const approve = (yes) => run(() => api(`/admin/orders/${id}/review`, { method: 'POST', body: { approve: yes } }));
  const reject = () => run(() => api(`/admin/orders/${id}/reject`, { method: 'POST', body: { reason } }));
  const canReject = o && ['placed', 'under_review', 'accepted'].includes(o.status);
  return (
    <Modal title={`Order ${id.slice(0, 8)}`} onClose={onClose}>
      <Err msg={error || err} />
      {o && (
        <>
          <p><Badge tone={STATUS_TONE[o.status]}>{label(o.status)}</Badge> {o.paymentMethod === 'cod' ? 'Cash on delivery' : o.paid ? 'Paid online' : 'Awaiting payment'}</p>
          <p><b>{o.customerName}</b><br />{o.address}</p>
          <ul className="plain">{o.items.map((i) => <li key={i.name} className="row between"><span>{i.qty} × {i.name}</span><span>{money(i.unitPricePaise * i.qty)}</span></li>)}</ul>
          <p className="muted">Subtotal {money(o.subtotalPaise)} · Discount {money(o.discountPaise)} · Delivery {money(o.deliveryPaise)}</p>
          <p className="big">{money(o.totalPaise)}</p>
          {o.riskFlags.length > 0 && <p className="warn">Risk flags: {o.riskFlags.join(', ')} (score {o.riskScore})</p>}
          {o.rejectReason && <p className="muted">Reason: {o.rejectReason}</p>}
          {canAct && (
            <div className="col">
              {o.status === 'placed' && <button className="ok" onClick={() => move('accepted')}>Accept</button>}
              {o.status === 'under_review' && <button className="ok" onClick={() => approve(true)}>Approve order</button>}
              {o.status === 'accepted' && <button className="ok" onClick={() => move('preparing')}>Start preparing</button>}
              {canReject && (
                <div className="row">
                  <input placeholder="Reason for rejecting" value={reason} onChange={(e) => setReason(e.target.value)} />
                  <button className="danger" disabled={reason.trim().length < 3} onClick={reject}>Reject</button>
                </div>
              )}
            </div>
          )}
        </>
      )}
    </Modal>
  );
}

export default function Orders({ tick, canAct }) {
  const [status, setStatus] = useState('placed');
  const [text, setText] = useState('');
  const [search, setSearch] = useState('');
  const [open, setOpen] = useState(null);
  const { data, error, reload } = useLoad(() => api(`/admin/orders?status=${status}&q=${encodeURIComponent(search)}`), [status, search, tick]);
  return (
    <>
      <h2>Orders</h2>
      <div className="tabs">{TABS.map(([v, l]) => <button key={v} className={status === v ? 'on' : ''} onClick={() => setStatus(v)}>{l}</button>)}</div>
      <form className="row" onSubmit={(e) => { e.preventDefault(); setSearch(text.trim()); }}>
        <input placeholder="Search by customer or order ID" value={text} onChange={(e) => setText(e.target.value)} /><button>Search</button>
      </form>
      <Err msg={error} />
      {data?.length === 0 && <p className="muted">No orders here.</p>}
      {data?.map((o) => (
        <button key={o.id} className="item" onClick={() => setOpen(o.id)}>
          <div className="row between"><b>{o.customerName}</b><b>{money(o.totalPaise)}</b></div>
          <div className="row between muted"><span>#{o.id.slice(0, 8)} · {when(o.createdAt)}</span><Badge tone={STATUS_TONE[o.status]}>{label(o.status)}</Badge></div>
          {o.riskFlags.length > 0 && <span className="warn">⚠ {o.riskFlags.join(', ')}</span>}
        </button>
      ))}
      {open && <Detail id={open} canAct={canAct} onClose={() => setOpen(null)} onChange={reload} />}
    </>
  );
}
