import { useState } from 'react';
import { api } from '../api';
import { Badge, Card, Err, useLoad, when } from '../ui';

function Review({ r, onChange }) {
  const [reply, setReply] = useState('');
  const [err, setErr] = useState('');
  const patch = async (body) => { setErr(''); try { await api(`/admin/reviews/${r.id}`, { method: 'PATCH', body }); setReply(''); onChange(); } catch (e) { setErr(e.message); } };
  return (
    <div className="item">
      <div className="row between"><b>{r.customerName}</b><span>{'★'.repeat(r.rating)}{'☆'.repeat(5 - r.rating)}</span></div>
      <span className="muted">{when(r.createdAt)} · order #{r.orderId.slice(0, 8)} {r.hidden && <Badge tone="red">Hidden</Badge>}</span>
      {r.comment && <p>{r.comment}</p>}
      {r.reply && <p className="muted">Your reply: {r.reply}</p>}
      <div className="row">
        <input placeholder="Write a reply" maxLength={300} value={reply} onChange={(e) => setReply(e.target.value)} />
        <button disabled={!reply.trim()} onClick={() => patch({ reply })}>Reply</button>
        <button onClick={() => patch({ hidden: !r.hidden })}>{r.hidden ? 'Show' : 'Hide'}</button>
      </div>
      <Err msg={err} />
    </div>
  );
}

export default function Reviews() {
  const { data, error, reload } = useLoad(() => api('/admin/reviews'));
  return (
    <>
      <h2>Reviews</h2>
      <Err msg={error} />
      {data && (
        <>
          <Card><p className="big">{data.summary.avg.toFixed(2)} ★</p><p className="muted">{data.summary.count} visible reviews</p></Card>
          {data.reviews.length === 0 && <p className="muted">No reviews yet.</p>}
          {data.reviews.map((r) => <Review key={r.id} r={r} onChange={reload} />)}
        </>
      )}
    </>
  );
}
