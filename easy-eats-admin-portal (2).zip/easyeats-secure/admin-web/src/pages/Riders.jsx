import { api } from '../api';
import { Badge, Err, useLoad } from '../ui';

export default function Riders({ tick }) {
  const { data, error } = useLoad(() => api('/admin/riders'), [tick]);
  return (
    <>
      <h2>Riders</h2>
      <Err msg={error} />
      {data?.length === 0 && <p className="muted">No riders yet. Add them from the Staff page.</p>}
      {data?.map((r) => (
        <div key={r.id} className="item">
          <div className="row between"><b>{r.name}</b><Badge tone={r.blocked ? 'red' : r.online ? 'green' : 'gray'}>{r.blocked ? 'Blocked' : r.online ? 'Online' : 'Offline'}</Badge></div>
          <div className="row between muted"><span>{r.phone}</span><span>{r.active} active · {r.delivered} delivered</span></div>
        </div>
      ))}
    </>
  );
}
