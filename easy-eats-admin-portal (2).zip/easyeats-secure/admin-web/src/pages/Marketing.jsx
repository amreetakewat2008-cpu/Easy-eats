import { useState } from 'react';
import { api } from '../api';
import { Card, Err, useLoad, when } from '../ui';

export default function Marketing() {
  const { data: history, reload } = useLoad(() => api('/admin/notifications'));
  const [f, setF] = useState({ title: '', body: '', audience: 'all', phone: '' });
  const [msg, setMsg] = useState('');
  const [err, setErr] = useState('');
  const [busy, setBusy] = useState(false);
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });

  const send = async (e) => {
    e.preventDefault();
    if (f.audience === 'all' && !window.confirm('Send this to ALL customers?')) return;
    setBusy(true); setErr(''); setMsg('');
    try {
      const body = { title: f.title, body: f.body, audience: f.audience, ...(f.audience === 'one' ? { phone: f.phone } : {}) };
      const r = await api('/admin/notifications', { method: 'POST', body });
      setMsg(`Delivered to ${r.sent} device(s).`); setF({ ...f, title: '', body: '' }); reload();
    } catch (x) { setErr(x.message); } finally { setBusy(false); }
  };

  return (
    <>
      <h2>Marketing</h2>
      <Card title="Send a notification to the customer app">
        <form className="col" onSubmit={send}>
          <select value={f.audience} onChange={set('audience')}>
            <option value="all">All customers</option>
            <option value="one">One customer</option>
          </select>
          {f.audience === 'one' && <input inputMode="numeric" placeholder="Customer mobile number" value={f.phone} onChange={set('phone')} required />}
          <input placeholder="Title (max 60)" maxLength={60} value={f.title} onChange={set('title')} required />
          <textarea placeholder="Message (max 200)" maxLength={200} rows={3} value={f.body} onChange={set('body')} required />
          <Err msg={err} />
          {msg && <p className="up">{msg}</p>}
          <button className="primary" disabled={busy}>{busy ? 'Sending…' : 'Send'}</button>
        </form>
      </Card>
      <Card title="History">
        {history?.length === 0 && <p className="muted">Nothing sent yet.</p>}
        {history?.map((n) => (
          <div key={n.id} className="item"><b>{n.title}</b><span>{n.body}</span><span className="muted">{when(n.createdAt)} · {n.audience === 'all' ? 'All customers' : 'One customer'} · {n.sentCount} delivered</span></div>
        ))}
      </Card>
    </>
  );
}
