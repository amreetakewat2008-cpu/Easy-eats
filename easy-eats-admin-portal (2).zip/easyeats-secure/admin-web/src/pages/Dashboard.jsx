import { useState } from 'react';
import { api } from '../api';
import { Card, Err, money, useLoad } from '../ui';

const change = (cur, prev) => (prev ? Math.round(((cur - prev) / prev) * 100) : null);

function Stat({ label, value, cur, prev }) {
  const d = prev === undefined ? null : change(cur, prev);
  return (
    <Card>
      <p className="muted">{label}</p>
      <p className="big">{value}</p>
      {d !== null && <p className={d >= 0 ? 'up' : 'down'}>{d >= 0 ? '+' : ''}{d}% vs previous period</p>}
    </Card>
  );
}

export default function Dashboard({ tick }) {
  const [days, setDays] = useState(7);
  const { data: d, error } = useLoad(() => api(`/admin/dashboard?days=${days}`), [days, tick]);
  if (error) return <Err msg={error} />;
  if (!d) return <p className="muted">Loading…</p>;
  const { current: c, previous: p, queue: q } = d;
  const max = Math.max(1, ...d.series.map((x) => x.revenue));
  return (
    <>
      <div className="row between">
        <h2>Dashboard</h2>
        <select value={days} onChange={(e) => setDays(+e.target.value)}>
          {[7, 30, 90].map((n) => <option key={n} value={n}>Last {n} days</option>)}
        </select>
      </div>
      <div className="grid">
        <Stat label="Total orders" value={c.orders} cur={c.orders} prev={p.orders} />
        <Stat label="Revenue (delivered)" value={money(c.revenue)} cur={c.revenue} prev={p.revenue} />
        <Stat label="Average order" value={money(c.delivered ? Math.round(c.revenue / c.delivered) : 0)} />
        <Stat label="Cancelled" value={`${c.orders ? Math.round((c.cancelled / c.orders) * 100) : 0}%`} />
        <Stat label="Riders online" value={`${d.riders.online} / ${d.riders.total}`} />
      </div>
      <div className="grid">
        <Stat label="Waiting to accept" value={q.awaiting} />
        <Stat label="Needs review" value={q.review} />
        <Stat label="In progress" value={q.active} />
        <Stat label="Refunds due" value={q.refundsDue} />
      </div>
      <Card title="Revenue by day">
        <div className="bars">
          {d.series.map((x) => (
            <div key={x.day} className="bar" title={`${x.day}: ${money(x.revenue)} · ${x.orders} orders`}>
              <i style={{ height: `${(x.revenue / max) * 100}%` }} /><span>{x.day.slice(days > 14 ? 5 : 8)}</span>
            </div>
          ))}
        </div>
      </Card>
      <Card title="Top items">
        {d.top.length === 0 && <p className="muted">No delivered orders in this period.</p>}
        {d.top.map((t) => <div key={t.name} className="row between"><span>{t.name}</span><span className="muted">{t.qty} sold · {money(t.revenue)}</span></div>)}
      </Card>
    </>
  );
}
