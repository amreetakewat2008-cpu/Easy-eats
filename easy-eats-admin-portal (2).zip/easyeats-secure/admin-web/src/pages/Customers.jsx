import { useState } from 'react';
import { api } from '../api';
import { Badge, Err, Modal, STATUS_TONE, label, money, useLoad, when } from '../ui';

function Detail({ id, onClose, onChange }) {
  const { data: c, error, reload } = useLoad(() => api(`/admin/customers/${id}`), [id]);
  const [err, setErr] = useState('');
  const toggle = async () => {
    if (!window.confirm(c.blocked ? 'Unblock this customer?' : 'Block this customer? They will be signed out.')) return;
    try { await api(`/admin/users/${id}/block`, { method: 'PATCH', body: { blocked: !c.blocked } }); await reload(); onChange(); } catch (e) { setErr(e.message); }
  };
  return (
    <Modal title="Customer" onClose={onClose}>
      <Err msg={error || err} />
      {c && (
        <>
          <p><b>{c.name}</b> {c.blocked && <Badge tone="red">Blocked</Badge>}<br />{c.phone}<br /><span className="muted">Joined {when(c.joinedAt)}</span></p>
          <button className={c.blocked ? 'ok' : 'danger'} onClick={toggle}>{c.blocked ? 'Unblock' : 'Block customer'}</button>
          <h4>Recent orders</h4>
          {c.orders.length === 0 && <p className="muted">No orders yet.</p>}
          {c.orders.map((o) => (
            <div key={o.id} className="row between"><span>#{o.id.slice(0, 8)} · {when(o.createdAt)}</span><span>{money(o.totalPaise)} <Badge tone={STATUS_TONE[o.status]}>{label(o.status)}</Badge></span></div>
          ))}
          <p className="muted">Opening this screen is recorded in the audit log.</p>
        </>
      )}
    </Modal>
  );
}

export default function Customers() {
  const [text, setText] = useState('');
  const [q, setQ] = useState('');
  const [open, setOpen] = useState(null);
  const { data, error, reload } = useLoad(() => api(`/admin/customers?q=${encodeURIComponent(q)}`), [q]);
  return (
    <>
      <h2>Customers</h2>
      <form className="row" onSubmit={(e) => { e.preventDefault(); setQ(text.trim()); }}>
        <input placeholder="Search by name or full mobile number" value={text} onChange={(e) => setText(e.target.value)} /><button>Search</button>
      </form>
      <Err msg={error} />
      {data?.map((c) => (
        <button key={c.id} className="item" onClick={() => setOpen(c.id)}>
          <div className="row between"><b>{c.name}</b>{c.blocked && <Badge tone="red">Blocked</Badge>}</div>
          <div className="row between muted"><span>{c.phone}</span><span>{c.orders} orders · {money(c.spentPaise)}</span></div>
        </button>
      ))}
      {open && <Detail id={open} onClose={() => setOpen(null)} onChange={reload} />}
    </>
  );
}
