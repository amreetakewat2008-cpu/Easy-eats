import { useCallback, useEffect, useState } from 'react';

export const money = (paise) => '₹' + (paise / 100).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
export const when = (iso) => new Date(iso).toLocaleString('en-IN', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' });
export const label = (s) => s.replace(/_/g, ' ');

export const STATUS_TONE = {
  placed: 'amber', under_review: 'amber', pending_payment: 'gray', accepted: 'blue', preparing: 'blue',
  out_for_delivery: 'blue', delivered: 'green', cancelled: 'red', failed: 'red',
};

export function useLoad(fn, deps = []) {
  const [s, set] = useState({ data: null, error: '', loading: true });
  const run = useCallback(async () => {
    try { set((x) => ({ ...x, loading: true })); set({ data: await fn(), error: '', loading: false }); }
    catch (e) { set({ data: null, error: e.message, loading: false }); }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, deps);
  useEffect(() => { run(); }, [run]);
  return { ...s, reload: run };
}

export const Card = ({ title, action, children }) => (
  <section className="card">
    {(title || action) && <header className="row between"><h3>{title}</h3>{action}</header>}
    {children}
  </section>
);
export const Badge = ({ tone = 'gray', children }) => <span className={`badge ${tone}`}>{children}</span>;
export const Err = ({ msg }) => (msg ? <p className="err">{msg}</p> : null);
export const Veg = ({ veg }) => <i className={`dot ${veg ? 'veg' : 'nonveg'}`} title={veg ? 'Veg' : 'Non-veg'} />;
export const Modal = ({ title, onClose, children }) => (
  <div className="overlay" onClick={onClose}>
    <div className="modal" onClick={(e) => e.stopPropagation()}>
      <header className="row between"><h3>{title}</h3><button className="ghost" onClick={onClose}>Close</button></header>
      {children}
    </div>
  </div>
);
