import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// Production: `npm run build` -> the API server serves dist/ at /panel/ (same origin = no CORS, cookies stay strict).
// Development: `npm run dev` proxies API calls to the backend on :3000.
const api = 'http://localhost:3000';
export default defineConfig({
  base: '/panel/',
  plugins: [react()],
  server: { proxy: { '/admin': api, '/orders': api, '/media': api } },
});
