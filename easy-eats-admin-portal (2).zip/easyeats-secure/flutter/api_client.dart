// lib/services/api_client.dart
//
// pubspec.yaml dependencies:
//   dio: ^5.7.0
//   flutter_secure_storage: ^9.2.2
//   crypto: ^3.0.5
//   uuid: ^4.5.1
//
// Rules this file follows:
//  1. Tokens live in the phone's secure keystore, never in SharedPreferences.
//  2. HTTPS only, and the server certificate is pinned.
//  3. The app NEVER sends prices. The server calculates every amount.
//  4. One Idempotency-Key per checkout, so a double-tap or bad network can't create two orders.
import 'package:crypto/crypto.dart';
import 'package:dio/dio.dart';
import 'package:dio/io.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:uuid/uuid.dart';

/// A cart line. There is NO price field on purpose.
class CartLine {
  final String menuItemId;
  final int qty;
  const CartLine(this.menuItemId, this.qty);
  Map<String, dynamic> toJson() => {'menuItemId': menuItemId, 'qty': qty};
}

class ApiClient {
  static const _baseUrl = 'https://api.easyeats.example'; // must be https://

  // SHA-256 fingerprints (lowercase hex) of your server certificate.
  // Keep a BACKUP pin so a certificate renewal does not lock every user out.
  static const _pins = <String>{
    'REPLACE_WITH_CERT_SHA256_HEX',
    'REPLACE_WITH_BACKUP_CERT_SHA256_HEX',
  };

  static const _store = FlutterSecureStorage(
    aOptions: AndroidOptions(encryptedSharedPreferences: true),
  );
  static const _kAccess = 'access_token';
  static const _kRefresh = 'refresh_token';

  static final ApiClient instance = ApiClient._();

  late final Dio _dio;
  Future<bool>? _refreshing;
  String? _checkoutKey;

  ApiClient._() {
    _dio = _build();
    _dio.interceptors.add(InterceptorsWrapper(
      onRequest: (options, handler) async {
        final token = await _store.read(key: _kAccess);
        if (token != null) options.headers['Authorization'] = 'Bearer $token';
        handler.next(options);
      },
      onError: (e, handler) async {
        final alreadyRetried = e.requestOptions.extra['retried'] == true;
        if (e.response?.statusCode == 401 && !alreadyRetried && await _refresh()) {
          final opts = e.requestOptions..extra['retried'] = true;
          try {
            return handler.resolve(await _dio.fetch(opts)); // onRequest adds the new token
          } on DioException catch (err) {
            return handler.next(err);
          }
        }
        handler.next(e);
      },
    ));
  }

  static Dio _build() {
    final dio = Dio(BaseOptions(
      baseUrl: _baseUrl,
      connectTimeout: const Duration(seconds: 10),
      receiveTimeout: const Duration(seconds: 15),
    ));
    dio.httpClientAdapter = IOHttpClientAdapter(
      // Runs after normal TLS checks. If the certificate isn't ours, the request is refused.
      validateCertificate: (cert, host, port) =>
          cert != null && _pins.contains(sha256.convert(cert.der).toString()),
    );
    return dio;
  }

  // ---------------- Auth ----------------
  Future<void> register(String name, String phone, String password) async {
    final res = await _build().post('/auth/register',
        data: {'name': name, 'phone': phone, 'password': password});
    await _saveTokens(res.data);
  }

  Future<void> login(String phone, String password) async {
    final res = await _build().post('/auth/login',
        data: {'phone': phone, 'password': password});
    await _saveTokens(res.data);
  }

  Future<void> logout() async {
    await _store.delete(key: _kAccess);
    await _store.delete(key: _kRefresh);
  }

  Future<void> _saveTokens(dynamic data) async {
    await _store.write(key: _kAccess, value: data['accessToken'] as String);
    await _store.write(key: _kRefresh, value: data['refreshToken'] as String);
  }

  // One refresh at a time, even if several requests fail together.
  Future<bool> _refresh() =>
      _refreshing ??= _doRefresh().whenComplete(() => _refreshing = null);

  Future<bool> _doRefresh() async {
    final refresh = await _store.read(key: _kRefresh);
    if (refresh == null) return false;
    try {
      final res = await _build().post('/auth/refresh', data: {'refreshToken': refresh});
      await _saveTokens(res.data);
      return true;
    } on DioException {
      await logout(); // refresh refused: session is over (or the token was stolen)
      return false;
    }
  }

  // ---------------- Orders ----------------
  /// Call this whenever the cart changes, so a new cart gets a new key.
  void resetCheckout() => _checkoutKey = null;

  /// Safe to call again after a timeout: the same key returns the SAME order.
  Future<Map<String, dynamic>> placeOrder({
    required List<CartLine> items,
    required String address,
    required String paymentMethod, // 'online' or 'cod'
    String? couponCode,
  }) async {
    _checkoutKey ??= const Uuid().v4();
    final res = await _dio.post(
      '/orders',
      data: {
        'items': items.map((i) => i.toJson()).toList(),
        'address': address,
        'paymentMethod': paymentMethod,
        if (couponCode != null && couponCode.isNotEmpty) 'couponCode': couponCode,
      },
      options: Options(headers: {'Idempotency-Key': _checkoutKey}),
    );
    _checkoutKey = null; // success: the next order gets a fresh key
    return Map<String, dynamic>.from(res.data as Map);
  }

  Future<Map<String, dynamic>> getOrder(String id) async {
    final res = await _dio.get('/orders/$id');
    return Map<String, dynamic>.from(res.data as Map);
  }
}

// UI tips:
//  - Disable the "Place order" button while placeOrder() is running.
//  - Show the total returned by the SERVER (totalPaise / 100), not one you calculated.
//  - Never print tokens, phone numbers or addresses with print()/debugPrint().
