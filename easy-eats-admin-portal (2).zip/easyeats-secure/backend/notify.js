'use strict';
// Push notifications.
//  - Customer + rider phones: Firebase Cloud Messaging (FCM)
//  - Staff browsers (new-order alerts when the panel tab is closed): Web Push (VAPID)
const firebase = require('firebase-admin');
const webpush = require('web-push');

module.exports = ({ db, bus, ORDER_STAFF }) => {
  const { FIREBASE_SERVICE_ACCOUNT_JSON, VAPID_PUBLIC_KEY, VAPID_PRIVATE_KEY, VAPID_SUBJECT } = process.env;
  if (!FIREBASE_SERVICE_ACCOUNT_JSON || !VAPID_PUBLIC_KEY || !VAPID_PRIVATE_KEY || !VAPID_SUBJECT) {
    throw new Error('Push is not configured. Set FIREBASE_SERVICE_ACCOUNT_JSON and VAPID_* in .env');
  }
  firebase.initializeApp({ credential: firebase.credential.cert(JSON.parse(FIREBASE_SERVICE_ACCOUNT_JSON)) });
  const fcm = firebase.messaging();
  webpush.setVapidDetails(VAPID_SUBJECT, VAPID_PUBLIC_KEY, VAPID_PRIVATE_KEY);

  const DEAD = ['messaging/registration-token-not-registered', 'messaging/invalid-registration-token'];

  // target: array of user ids, 'all_customers', or 'online_riders'
  async function pushToUsers(target, { title, body, data = {} }) {
    const sql = {
      all_customers: "SELECT t.token FROM device_tokens t JOIN users u ON u.id = t.user_id WHERE u.role = 'customer' AND NOT u.is_blocked",
      online_riders: "SELECT t.token FROM device_tokens t JOIN users u ON u.id = t.user_id WHERE u.role = 'rider' AND NOT u.is_blocked AND u.is_online AND u.last_seen_at > now() - interval '2 minutes'",
    }[target];
    const { rows } = sql
      ? await db.query(sql)
      : await db.query('SELECT token FROM device_tokens WHERE user_id = ANY($1::uuid[])', [target]);
    const tokens = rows.map((r) => r.token);
    let sent = 0;
    for (let i = 0; i < tokens.length; i += 500) {
      const chunk = tokens.slice(i, i + 500);
      const r = await fcm.sendEachForMulticast({ tokens: chunk, notification: { title, body }, data, android: { priority: 'high' } });
      sent += r.successCount;
      const dead = chunk.filter((_, j) => DEAD.includes(r.responses[j].error?.code));
      if (dead.length) await db.query('DELETE FROM device_tokens WHERE token = ANY($1)', [dead]);
    }
    return sent;
  }

  async function pushToStaff(payload) {
    const { rows } = await db.query(
      'SELECT s.* FROM push_subscriptions s JOIN users u ON u.id = s.user_id WHERE u.role = ANY($1) AND NOT u.is_blocked', [ORDER_STAFF]);
    await Promise.all(rows.map(async (s) => {
      try {
        await webpush.sendNotification({ endpoint: s.endpoint, keys: { p256dh: s.p256dh, auth: s.auth } },
          JSON.stringify(payload), { TTL: 120, urgency: 'high' });
      } catch (e) {
        if (e.statusCode === 404 || e.statusCode === 410) await db.query('DELETE FROM push_subscriptions WHERE endpoint = $1', [s.endpoint]);
      }
    }));
  }

  const SAFE = (fn) => (arg) => fn(arg).catch((e) => console.error('push failed:', e.message));

  bus.on('order_placed', SAFE(async (id) => {
    const { rows: [o] } = await db.query('SELECT total_paise, payment_method FROM orders WHERE id = $1', [id]);
    await pushToStaff({
      orderId: id, title: 'New order',
      body: `₹${(o.total_paise / 100).toFixed(2)} · ${o.payment_method === 'cod' ? 'Cash on delivery' : 'Paid online'}`,
    });
  }));

  const CUSTOMER_MSG = {
    accepted: ['Order accepted', 'The restaurant has accepted your order.'],
    preparing: ['Being prepared', 'Your food is being prepared.'],
    out_for_delivery: ['On the way', 'Your rider is on the way. Share your delivery code at the door.'],
    delivered: ['Delivered', 'Enjoy your meal! Tell us how it was.'],
    cancelled: ['Order cancelled', 'Your order was cancelled. Any online payment will be refunded.'],
  };
  bus.on('order_status', SAFE(async ({ id, to }) => {
    const { rows: [o] } = await db.query('SELECT user_id FROM orders WHERE id = $1', [id]);
    if (CUSTOMER_MSG[to] && o) {
      await pushToUsers([o.user_id], { title: CUSTOMER_MSG[to][0], body: CUSTOMER_MSG[to][1], data: { type: 'order_status', orderId: id, status: to } });
    }
    if (to === 'preparing') {
      await pushToUsers('online_riders', { title: 'Order ready soon', body: 'A new order is available to pick up.', data: { type: 'rider_new_order', orderId: id } });
    }
  }));

  return { pushToUsers };
};
