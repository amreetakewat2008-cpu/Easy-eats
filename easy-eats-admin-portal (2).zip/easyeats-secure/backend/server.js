'use strict';
require('dotenv').config();
const crypto = require('crypto');
const express = require('express');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const { Pool } = require('pg');
const { z } = require('zod');

// ============================================================
// CONFIG - the server refuses to start if a secret is missing
// ============================================================
const { DATABASE_URL, JWT_SECRET, DATA_KEY_HEX, PAYMENT_WEBHOOK_SECRET } = process.env;
if (!DATABASE_URL || !JWT_SECRET || !DATA_KEY_HEX || !PAYMENT_WEBHOOK_SECRET) {
  throw new Error('Missing env vars. See .env.example');
}
if (JWT_SECRET.length < 32) throw new Error('JWT_SECRET must be at least 32 characters');

// All business rules live here, in one place. Money = integer paise.
const RULES = {
  deliveryFeePaise: 3000,
  freeDeliveryAbovePaise: 49900,
  codMaxPaise: 150000,          // cash-on-delivery cap
  codMinDeliveredOrders: 2,     // new customers must pay online first
  codMaxRecentFailures: 2,      // refused/failed COD orders in last 30 days
  highValuePaise: 300000,
  reviewScoreAt: 70,            // risk score that sends an order to manual review
  maxOrdersPerHour: 5,
  maxUnpaidOrders: 3,
  maxWrongOtp: 5,
};

const db = new Pool({
  connectionString: DATABASE_URL,
  ssl: process.env.NODE_ENV === 'production' ? { rejectUnauthorized: true } : false,
  max: 10,
});

const { EventEmitter } = require('events');
const bus = new EventEmitter();   // in-process events: order_placed, order_status (one server instance)
const STAFF = ['super_admin', 'restaurant_manager', 'marketing_lead', 'customer_support'];
const ORDER_STAFF = ['super_admin', 'restaurant_manager'];   // may accept / reject / move orders

// ============================================================
// HELPERS
// ============================================================
class HttpError extends Error {
  constructor(status, message) { super(message); this.status = status; }
}
const wrap = (fn) => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);

const { sha256, blindIndex, encrypt, decrypt, safeEqual } = require('./lib/crypto');

// Transaction helper: everything inside succeeds together or not at all.
async function withTx(fn) {
  const client = await db.connect();
  try {
    await client.query('BEGIN');
    const result = await fn(client);
    await client.query('COMMIT');
    return result;
  } catch (e) {
    await client.query('ROLLBACK').catch(() => {});
    throw e;
  } finally {
    client.release();
  }
}

// Audit trail. Never put passwords, tokens, phone numbers or addresses in here.
const audit = (req, userId, action, detail = {}) =>
  db.query('INSERT INTO audit_log (user_id, action, detail, ip) VALUES ($1,$2,$3,$4)',
    [userId ?? null, action, detail, req?.ip ?? null]).catch(() => {});

const publicOrder = (o) => ({
  id: o.id, status: o.status, paymentMethod: o.payment_method, paid: o.paid,
  subtotalPaise: o.subtotal_paise, discountPaise: o.discount_paise,
  deliveryPaise: o.delivery_paise, totalPaise: o.total_paise, createdAt: o.created_at, placedAt: o.placed_at, rejectReason: o.reject_reason,
});

// ============================================================
// APP SETUP
// ============================================================
const app = express();
app.set('trust proxy', 1);            // we run behind a load balancer / reverse proxy
app.disable('x-powered-by');
app.use(helmet());
app.use(rateLimit({ windowMs: 60_000, limit: 120, standardHeaders: true, legacyHeaders: false }));
const authLimiter = rateLimit({ windowMs: 15 * 60_000, limit: 20, standardHeaders: true, legacyHeaders: false });

// ============================================================
// PAYMENT WEBHOOK  (needs the RAW body, so it is mounted BEFORE express.json)
// Razorpay-style: header x-razorpay-signature = HMAC-SHA256(rawBody, secret). Adjust for your gateway.
// ============================================================
const PaymentEntity = z.object({
  id: z.string().min(1).max(64),
  amount: z.number().int(),
  notes: z.object({ order_id: z.string().uuid() }),
});

app.post('/webhooks/payment', express.raw({ type: 'application/json', limit: '100kb' }), wrap(async (req, res) => {
  const expected = crypto.createHmac('sha256', PAYMENT_WEBHOOK_SECRET).update(req.body).digest('hex');
  if (!safeEqual(req.get('x-razorpay-signature') || '', expected)) {
    await audit(req, null, 'webhook_bad_signature');
    return res.sendStatus(401);
  }
  const evt = JSON.parse(req.body.toString('utf8'));
  if (evt.event !== 'payment.captured') return res.sendStatus(200);
  const p = PaymentEntity.parse(evt?.payload?.payment?.entity);

  let placedNow = null;
  await withTx(async (tx) => {
    const { rows: [o] } = await tx.query(
      'SELECT id, total_paise, status FROM orders WHERE id=$1 FOR UPDATE', [p.notes.order_id]);
    if (!o) return;
    // The amount paid must match what WE calculated, not what anyone claims.
    if (p.amount !== o.total_paise) {
      await audit(null, null, 'payment_amount_mismatch', { orderId: o.id, paid: p.amount, expected: o.total_paise });
      return;
    }
    const ins = await tx.query(
      'INSERT INTO payments (provider_payment_id, order_id, amount_paise) VALUES ($1,$2,$3) ON CONFLICT DO NOTHING',
      [p.id, o.id, p.amount]);
    if (!ins.rowCount) return;                       // replayed webhook: already processed
    await tx.query(
      `UPDATE orders SET paid = true,
         status = CASE WHEN status = 'pending_payment' THEN 'placed' ELSE status END
       WHERE id = $1`, [o.id]);
    if (o.status === 'pending_payment') placedNow = o.id;   // paid online: ring the restaurant
    if (o.status === 'cancelled') await audit(null, null, 'paid_after_cancel_needs_refund', { orderId: o.id });
  });
  if (placedNow) bus.emit('order_placed', placedNow);
  res.sendStatus(200);
}));

app.use(express.json({ limit: '50kb' }));

// ============================================================
// AUTH
// ============================================================
const RegisterSchema = z.object({
  name: z.string().trim().min(2).max(60),
  phone: z.string().regex(/^[6-9]\d{9}$/, 'Enter a 10-digit Indian mobile number'),
  password: z.string().min(10).max(72),     // 72 = bcrypt's limit
});
const LoginSchema = z.object({
  phone: z.string().regex(/^[6-9]\d{9}$/),
  password: z.string().min(1).max(72),
});
const DUMMY_HASH = bcrypt.hashSync('not-a-real-password', 12);  // keeps timing equal for unknown users

async function issueTokens(user) {
  const accessToken = jwt.sign({ sub: user.id }, JWT_SECRET, { algorithm: 'HS256', expiresIn: '15m' });
  const refreshToken = crypto.randomBytes(32).toString('base64url');
  await db.query(
    `INSERT INTO refresh_tokens (user_id, token_hash, expires_at) VALUES ($1,$2, now() + interval '30 days')`,
    [user.id, sha256(refreshToken)]);
  return { accessToken, refreshToken };
}

app.post('/auth/register', authLimiter, wrap(async (req, res) => {
  const b = RegisterSchema.parse(req.body);
  const passwordHash = await bcrypt.hash(b.password, 12);
  try {
    const { rows: [u] } = await db.query(
      'INSERT INTO users (name, phone_enc, phone_hash, password_hash) VALUES ($1,$2,$3,$4) RETURNING id',
      [b.name, encrypt(b.phone), blindIndex(b.phone), passwordHash]);
    // TODO before launch: verify the phone with an SMS OTP so fake accounts are costly.
    res.status(201).json(await issueTokens(u));
  } catch (e) {
    if (e.code === '23505') throw new HttpError(409, 'Could not create account');
    throw e;
  }
}));

async function authenticate(req, phone, password) {
  const { rows: [u] } = await db.query('SELECT * FROM users WHERE phone_hash=$1', [blindIndex(phone)]);
  if (u?.locked_until && u.locked_until > new Date()) throw new HttpError(429, 'Too many attempts. Try again later.');
  const ok = await bcrypt.compare(password, u ? u.password_hash : DUMMY_HASH);
  if (!u || !ok || u.is_blocked) {
    if (u) {
      await db.query(
        `UPDATE users SET failed_logins = failed_logins + 1,
           locked_until = CASE WHEN failed_logins + 1 >= 5 THEN now() + interval '15 minutes' ELSE locked_until END
         WHERE id = $1`, [u.id]);
    }
    await audit(req, u?.id, 'login_failed');
    throw new HttpError(401, 'Invalid phone or password');   // same message for every failure
  }
  await db.query('UPDATE users SET failed_logins = 0, locked_until = NULL WHERE id=$1', [u.id]);
  return u;
}

// Refresh tokens are single-use. Re-using an old one means it was probably stolen,
// so we kill every session for that user.
async function rotateRefresh(req, token) {
  const { rows: [t] } = await db.query('SELECT * FROM refresh_tokens WHERE token_hash=$1', [sha256(token)]);
  if (!t) throw new HttpError(401, 'Unauthorized');
  if (t.revoked) {
    await db.query('UPDATE refresh_tokens SET revoked = true WHERE user_id=$1', [t.user_id]);
    await audit(req, t.user_id, 'refresh_token_reuse');
    throw new HttpError(401, 'Unauthorized');
  }
  if (t.expires_at < new Date()) throw new HttpError(401, 'Unauthorized');
  await db.query('UPDATE refresh_tokens SET revoked = true WHERE id=$1', [t.id]);
  const { rows: [u] } = await db.query('SELECT id, name, role, is_blocked FROM users WHERE id=$1', [t.user_id]);
  if (!u || u.is_blocked) throw new HttpError(401, 'Unauthorized');
  return { user: u, tokens: await issueTokens(u) };
}

// Customer + rider apps. Staff sign in through the admin panel instead (/admin/auth/login).
app.post('/auth/login', authLimiter, wrap(async (req, res) => {
  const b = LoginSchema.parse(req.body);
  const u = await authenticate(req, b.phone, b.password);
  if (STAFF.includes(u.role)) throw new HttpError(401, 'Invalid phone or password');
  res.json(await issueTokens(u));
}));

app.post('/auth/refresh', authLimiter, wrap(async (req, res) => {
  const { refreshToken } = z.object({ refreshToken: z.string().min(20).max(200) }).parse(req.body);
  const { user, tokens } = await rotateRefresh(req, refreshToken);
  if (STAFF.includes(user.role)) throw new HttpError(401, 'Unauthorized');
  res.json(tokens);
}));

// Role is read from the DATABASE every request, never trusted from the token.
const requireAuth = (...roles) => wrap(async (req, _res, next) => {
  let claims;
  try {
    claims = jwt.verify((req.get('authorization') || '').replace(/^Bearer /, ''), JWT_SECRET, { algorithms: ['HS256'] });
  } catch {
    throw new HttpError(401, 'Unauthorized');
  }
  const { rows: [u] } = await db.query('SELECT id, role, is_blocked FROM users WHERE id=$1', [claims.sub]);
  if (!u || u.is_blocked) throw new HttpError(401, 'Unauthorized');
  if (roles.length && !roles.includes(u.role)) throw new HttpError(403, 'Forbidden');
  req.user = { id: u.id, role: u.role };
  next();
});

// ============================================================
// FRAUD RULES
// ============================================================
async function assessRisk(tx, userId, { total, paymentMethod, addressHash }) {
  const { rows: [s] } = await tx.query(`
    SELECT
      (SELECT count(*) FROM orders WHERE user_id=$1 AND created_at > now() - interval '1 hour') AS last_hour,
      (SELECT count(*) FROM orders WHERE user_id=$1 AND status='pending_payment') AS open_unpaid,
      (SELECT count(*) FROM orders WHERE user_id=$1 AND status='delivered') AS delivered,
      (SELECT count(*) FROM orders WHERE user_id=$1 AND status='failed' AND payment_method='cod'
         AND created_at > now() - interval '30 days') AS cod_failures,
      (SELECT count(DISTINCT user_id) FROM orders WHERE address_hash=$2
         AND created_at > now() - interval '1 day') AS address_users,
      (SELECT created_at FROM users WHERE id=$1) AS joined`, [userId, addressHash]);
  const n = (v) => Number(v);
  const block = (message, flag) => ({ block: true, message, flags: [flag], score: 100 });

  // Hard blocks
  if (n(s.last_hour) >= RULES.maxOrdersPerHour) return block('Too many orders. Please try later.', 'velocity');
  if (n(s.open_unpaid) >= RULES.maxUnpaidOrders) return block('Please complete your pending payments first.', 'unpaid_orders');
  if (paymentMethod === 'cod') {
    const codMsg = 'Cash on delivery is not available for this order. Please pay online.';
    if (n(s.cod_failures) >= RULES.codMaxRecentFailures) return block(codMsg, 'cod_failures');
    if (n(s.delivered) < RULES.codMinDeliveredOrders) return block(codMsg, 'cod_new_customer');
    if (total > RULES.codMaxPaise) return block(codMsg, 'cod_over_limit');
  }

  // Soft signals add to a score; a high score sends the order to manual review.
  let score = 0;
  const flags = [];
  if (total > RULES.highValuePaise) { score += 40; flags.push('high_value'); }
  if (Date.now() - new Date(s.joined).getTime() < 10 * 60_000 && total > 100000) { score += 30; flags.push('new_account_big_order'); }
  if (n(s.address_users) >= 3) { score += 40; flags.push('shared_address'); }
  return { block: false, score, flags };
}

// Coupons: one use per customer (DB primary key) and a global cap (atomic UPDATE).
async function redeemCoupon(tx, userId, code, subtotal) {
  const { rows: [c] } = await tx.query('SELECT * FROM coupons WHERE code=$1 AND expires_at > now()', [code]);
  if (!c || subtotal < c.min_order_paise) throw new HttpError(400, 'Coupon is not valid for this order');
  const claim = await tx.query(
    'UPDATE coupons SET redeemed_count = redeemed_count + 1 WHERE code=$1 AND redeemed_count < max_redemptions', [code]);
  if (!claim.rowCount) throw new HttpError(400, 'Coupon is fully redeemed');
  try {
    await tx.query('INSERT INTO coupon_redemptions (code, user_id) VALUES ($1,$2)', [code, userId]);
  } catch (e) {
    if (e.code === '23505') throw new HttpError(400, 'You have already used this coupon');
    throw e;
  }
  return Math.min(Math.floor((subtotal * c.percent_off) / 100), c.max_discount_paise);
}

// ============================================================
// ORDERS
// ============================================================
const OrderSchema = z.object({
  items: z.array(z.object({
    menuItemId: z.string().uuid(),
    qty: z.number().int().min(1).max(10),
  })).min(1).max(30),                                   // NOTE: no price field. Prices come from the DB.
  address: z.string().trim().min(10).max(300),
  paymentMethod: z.enum(['online', 'cod']),
  couponCode: z.string().trim().toUpperCase().max(20).optional(),
});

async function findOrderByKey(userId, key) {
  const { rows } = await db.query('SELECT * FROM orders WHERE user_id=$1 AND idempotency_key=$2', [userId, key]);
  return rows[0];
}

app.post('/orders', requireAuth('customer'), wrap(async (req, res) => {
  const key = req.get('idempotency-key') || '';
  if (!/^[A-Za-z0-9_-]{16,64}$/.test(key)) throw new HttpError(400, 'Idempotency-Key header is required');
  const body = OrderSchema.parse(req.body);
  const ids = body.items.map((i) => i.menuItemId);
  if (new Set(ids).size !== ids.length) throw new HttpError(400, 'Duplicate items in cart');

  const existing = await findOrderByKey(req.user.id, key);       // retry of the same checkout
  if (existing) return res.json(publicOrder(existing));

  try {
    const order = await withTx(async (tx) => {
      // 1. Price everything on the server
      const { rows: menu } = await tx.query(
        'SELECT id, name, price_paise FROM menu_items WHERE id = ANY($1::uuid[]) AND is_available', [ids]);
      if (menu.length !== ids.length) throw new HttpError(400, 'Some items are unavailable');
      const byId = new Map(menu.map((m) => [m.id, m]));
      const lines = body.items.map((i) => ({ ...byId.get(i.menuItemId), qty: i.qty }));
      const subtotal = lines.reduce((sum, l) => sum + l.price_paise * l.qty, 0);

      // 2. Coupon + delivery fee
      const discount = body.couponCode ? await redeemCoupon(tx, req.user.id, body.couponCode, subtotal) : 0;
      const delivery = subtotal >= RULES.freeDeliveryAbovePaise ? 0 : RULES.deliveryFeePaise;
      const total = subtotal - discount + delivery;

      // 3. Fraud check
      const addressHash = blindIndex(body.address.toLowerCase().replace(/\s+/g, ' '));
      const risk = await assessRisk(tx, req.user.id, { total, paymentMethod: body.paymentMethod, addressHash });
      if (risk.block) {
        await audit(req, req.user.id, 'order_blocked', { flags: risk.flags });
        throw new HttpError(403, risk.message);
      }

      // 4. Save
      const status = risk.score >= RULES.reviewScoreAt ? 'under_review'
        : body.paymentMethod === 'cod' ? 'placed' : 'pending_payment';
      const otp = String(crypto.randomInt(1000, 10000));
      const { rows: [o] } = await tx.query(
        `INSERT INTO orders (user_id, idempotency_key, status, payment_method, subtotal_paise, discount_paise,
           delivery_paise, total_paise, coupon_code, address_enc, address_hash, otp_enc, risk_score, risk_flags)
         VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14) RETURNING *`,
        [req.user.id, key, status, body.paymentMethod, subtotal, discount, delivery, total,
          body.couponCode ?? null, encrypt(body.address), addressHash, encrypt(otp), risk.score, risk.flags]);
      for (const l of lines) {
        await tx.query(
          'INSERT INTO order_items (order_id, menu_item_id, name, unit_price_paise, qty) VALUES ($1,$2,$3,$4,$5)',
          [o.id, l.id, l.name, l.price_paise, l.qty]);
      }
      return o;
    });
    if (order.risk_flags.length) await audit(req, req.user.id, 'order_flagged', { orderId: order.id, flags: order.risk_flags });
    if (order.status === 'placed') bus.emit('order_placed', order.id);   // COD orders ring the restaurant now
    res.status(201).json(publicOrder(order));
  } catch (e) {
    // Two identical requests raced: the DB unique key let only one through. Return that one.
    if (e.code === '23505' && e.constraint === 'orders_user_id_idempotency_key_key') {
      return res.json(publicOrder(await findOrderByKey(req.user.id, key)));
    }
    throw e;
  }
}));

app.get('/orders', requireAuth('customer'), wrap(async (req, res) => {
  const { rows } = await db.query('SELECT * FROM orders WHERE user_id=$1 ORDER BY created_at DESC LIMIT 50', [req.user.id]);
  res.json(rows.map(publicOrder));
}));

// "AND user_id = me" on every query stops customers reading each other's orders.
app.get('/orders/:id', requireAuth('customer'), wrap(async (req, res) => {
  const id = z.string().uuid().parse(req.params.id);
  const { rows: [o] } = await db.query('SELECT * FROM orders WHERE id=$1 AND user_id=$2', [id, req.user.id]);
  if (!o) throw new HttpError(404, 'Not found');
  const { rows: items } = await db.query(
    'SELECT name, unit_price_paise AS "unitPricePaise", qty FROM order_items WHERE order_id=$1', [id]);
  res.json({
    ...publicOrder(o), items, address: decrypt(o.address_enc),
    deliveryOtp: o.status === 'out_for_delivery' ? decrypt(o.otp_enc) : undefined,   // shown only when rider is on the way
  });
}));

app.post('/orders/:id/cancel', requireAuth('customer'), wrap(async (req, res) => {
  const id = z.string().uuid().parse(req.params.id);
  const r = await db.query(
    `UPDATE orders SET status='cancelled'
     WHERE id=$1 AND user_id=$2 AND status IN ('pending_payment','under_review','placed') RETURNING id, paid`,
    [id, req.user.id]);
  if (!r.rowCount) throw new HttpError(409, 'This order can no longer be cancelled');
  if (r.rows[0].paid) await audit(req, req.user.id, 'cancelled_paid_order_needs_refund', { orderId: id });
  bus.emit('order_status', { id, to: 'cancelled' });
  res.json({ status: 'cancelled' });
}));

// ---------- Staff: state machine so orders can only move in allowed steps ----------
const TRANSITIONS = {
  pending_payment: ['placed', 'cancelled'],
  under_review: ['placed', 'pending_payment', 'cancelled'],
  placed: ['accepted', 'cancelled'],
  accepted: ['preparing', 'cancelled'],
  preparing: ['out_for_delivery'],
  out_for_delivery: ['delivered', 'failed'],
};
const RIDER_MAY_SET = new Set(['out_for_delivery', 'failed']);

app.patch('/orders/:id/status', requireAuth('rider', ...ORDER_STAFF), wrap(async (req, res) => {
  const id = z.string().uuid().parse(req.params.id);
  const { to } = z.object({ to: z.enum(['accepted', 'preparing', 'out_for_delivery', 'failed', 'cancelled']) }).parse(req.body);
  await withTx(async (tx) => {
    const { rows: [o] } = await tx.query('SELECT * FROM orders WHERE id=$1 FOR UPDATE', [id]);
    if (!o) throw new HttpError(404, 'Not found');
    if (!(TRANSITIONS[o.status] || []).includes(to)) throw new HttpError(409, `Cannot go from ${o.status} to ${to}`);
    if (req.user.role === 'rider') {
      if (!RIDER_MAY_SET.has(to)) throw new HttpError(403, 'Forbidden');
      if (o.rider_id && o.rider_id !== req.user.id) throw new HttpError(403, 'Not your order');
    }
    const riderId = to === 'out_for_delivery' && req.user.role === 'rider' ? req.user.id : o.rider_id;
    await tx.query('UPDATE orders SET status=$1, rider_id=$2 WHERE id=$3', [to, riderId, id]);
    if (to === 'cancelled' && o.paid) await audit(req, req.user.id, 'cancelled_paid_order_needs_refund', { orderId: id });
    await audit(req, req.user.id, 'order_status', { orderId: id, from: o.status, to });
  });
  bus.emit('order_status', { id, to });
  res.json({ status: to });
}));

// "Delivered" can ONLY happen through the customer's 4-digit code: no code, no delivery, no fake deliveries.
app.post('/orders/:id/deliver', requireAuth('rider', ...ORDER_STAFF), wrap(async (req, res) => {
  const id = z.string().uuid().parse(req.params.id);
  const { otp } = z.object({ otp: z.string().regex(/^\d{4}$/) }).parse(req.body);
  let wrong = false;
  await withTx(async (tx) => {
    const { rows: [o] } = await tx.query('SELECT * FROM orders WHERE id=$1 FOR UPDATE', [id]);
    if (!o || o.status !== 'out_for_delivery') throw new HttpError(409, 'Order is not out for delivery');
    if (req.user.role === 'rider' && o.rider_id !== req.user.id) throw new HttpError(403, 'Not your order');
    if (o.otp_attempts >= RULES.maxWrongOtp) throw new HttpError(429, 'Too many wrong codes. Contact support.');
    if (!safeEqual(decrypt(o.otp_enc), otp)) {
      await tx.query('UPDATE orders SET otp_attempts = otp_attempts + 1 WHERE id=$1', [id]);
      wrong = true;
      return;                                   // commit the attempt counter
    }
    await tx.query("UPDATE orders SET status='delivered' WHERE id=$1", [id]);
  });
  if (wrong) {
    await audit(req, req.user.id, 'otp_wrong', { orderId: id });
    throw new HttpError(400, 'Wrong code');
  }
  bus.emit('order_status', { id, to: 'delivered' });
  res.json({ status: 'delivered' });
}));

// ---------- Admin: manual review of risky orders ----------
app.post('/admin/orders/:id/review', requireAuth(...ORDER_STAFF), wrap(async (req, res) => {
  const id = z.string().uuid().parse(req.params.id);
  const { approve } = z.object({ approve: z.boolean() }).parse(req.body);
  const r = await db.query(
    `UPDATE orders SET status = CASE
         WHEN NOT $2 THEN 'cancelled'
         WHEN paid OR payment_method = 'cod' THEN 'placed'
         ELSE 'pending_payment' END
     WHERE id=$1 AND status='under_review' RETURNING status`, [id, approve]);
  if (!r.rowCount) throw new HttpError(409, 'Order is not under review');
  await audit(req, req.user.id, 'order_review', { orderId: id, approve });
  bus.emit(r.rows[0].status === 'placed' ? 'order_placed' : 'order_status', r.rows[0].status === 'placed' ? id : { id, to: r.rows[0].status });
  res.json({ status: r.rows[0].status });
}));

// ============================================================
// ERRORS - users get safe messages, details stay in server logs
// ============================================================
// ---------- Feature modules ----------
const ctx = { app, db, wrap, HttpError, z, requireAuth, audit, withTx, encrypt, decrypt, blindIndex, sha256,
  issueTokens, authenticate, rotateRefresh, authLimiter, bus, STAFF, ORDER_STAFF, publicOrder };
ctx.pushToUsers = require('./notify')(ctx).pushToUsers;
require('./appApi')(ctx);   // customer + rider apps
require('./admin')(ctx);    // admin panel

app.get('/health', (_req, res) => res.json({ ok: true }));
app.use((_req, res) => res.status(404).json({ error: 'Not found' }));
app.use((err, _req, res, _next) => {
  if (err instanceof z.ZodError) return res.status(400).json({ error: 'Invalid input', fields: err.issues.map((i) => i.path.join('.')) });
  if (err instanceof HttpError) return res.status(err.status).json({ error: err.message });
  console.error('Unhandled error:', err.message);        // never log request bodies (they hold personal data)
  res.status(500).json({ error: 'Something went wrong' });
});

process.on('unhandledRejection', (e) => console.error('Unhandled rejection:', e?.message));

const port = process.env.PORT || 3000;
app.listen(port, () => console.log(`Easy Eats API listening on ${port}`));
