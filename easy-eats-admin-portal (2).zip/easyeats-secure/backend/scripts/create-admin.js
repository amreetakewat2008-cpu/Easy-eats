'use strict';
// Creates the FIRST super admin. Afterwards create staff from the panel (Staff page).
//   read -rs ADMIN_PASSWORD && export ADMIN_PASSWORD
//   ADMIN_NAME="Your Name" ADMIN_PHONE=9XXXXXXXXX npm run create-admin
require('dotenv').config();
const bcrypt = require('bcrypt');
const { Pool } = require('pg');
const { encrypt, blindIndex } = require('../lib/crypto');

const { ADMIN_NAME, ADMIN_PHONE, ADMIN_PASSWORD, DATABASE_URL } = process.env;
if (!ADMIN_NAME || !/^[6-9]\d{9}$/.test(ADMIN_PHONE || '') || (ADMIN_PASSWORD || '').length < 10) {
  console.error('Set ADMIN_NAME, ADMIN_PHONE (10 digits) and ADMIN_PASSWORD (10+ characters).');
  process.exit(1);
}
(async () => {
  const db = new Pool({ connectionString: DATABASE_URL });
  const { rowCount } = await db.query("SELECT 1 FROM users WHERE role = 'super_admin'");
  if (rowCount) { console.error('A super admin already exists. Add staff from the panel.'); process.exit(1); }
  await db.query(
    "INSERT INTO users (name, phone_enc, phone_hash, password_hash, role) VALUES ($1,$2,$3,$4,'super_admin')",
    [ADMIN_NAME, encrypt(ADMIN_PHONE), blindIndex(ADMIN_PHONE), await bcrypt.hash(ADMIN_PASSWORD, 12)]);
  console.log('Super admin created. Sign in at /panel/');
  await db.end();
})().catch((e) => { console.error(e.message); process.exit(1); });
