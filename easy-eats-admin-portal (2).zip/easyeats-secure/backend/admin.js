'use strict';
// Admin panel API. Every route is protected by requireAuth(<roles>); roles are read from the DB.
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const express = require('express');
const multer = require('multer');
const sharp = require('sharp');
const bcrypt = require('bcrypt');

module.exports = (ctx) => {
  const { app, db, wrap, HttpError, z, requireAuth, audit, withTx, encrypt, decrypt, blindIndex, sha256,
    issueTokens, authenticate, rotateRefresh, authLimiter, bus, STAFF, ORDER_STAFF, publicOrder, pushToUsers } = ctx;

  const { RAZORPAY_KEY_ID, RAZORPAY_KEY_SECRET } = process.env;
  if (!RAZORPAY_KEY_ID || !RAZORPAY_KEY_SECRET) throw new Error('Set RAZORPAY_KEY_ID and RAZORPAY_KEY_SECRET in .env');
  const UPLOAD_DIR = path.resolve(process.env.UPLOAD_DIR || './uploads');
  fs.mkdirSync(UPLOAD_DIR, { recursive: true });

  const TZ = 'Asia/Kolkata';
  const ACCEPT_TIMEOUT_MIN = 5;                       // unaccepted orders auto-cancel after this
  const ORDER_VIEW = [...ORDER_STAFF, 'customer_support'];
  const CRM = ['super_admin', 'customer_support'];
  const MARKETING = ['super_admin', 'marketing_lead'];
  const OWNER = ['super_admin'];

  const uuid = (v) => z.string().uuid().parse(v);
  const paging = (q) => {
    const n = z.coerce.number().int().min(1).max(1000).catch(1).parse(q.page);
    return { limit: 25, offset: (n - 1) * 25 };
  };
  const mask = (phone) => 'XXXXXX' + phone.slice(-4);
  const PHONE = z.string().regex(/^[6-9]\d{9}$/, 'Enter a 10-digit Indian mobile number');

  // ---------- static: uploaded food photos + the admin panel itself ----------
  app.use('/media', express.static(UPLOAD_DIR, { index: false, maxAge: '7d', immutable: true }));
  const PANEL = path.resolve(__dirname, '../admin-web/dist');
  app.use('/panel', express.static(PANEL, { index: false }));
  app.get(['/panel', '/panel/*'], (_req, res) => res.sendFile(path.join(PANEL, 'index.html')));

  // ============================================================
  // AUTH: staff sign in with phone + password. The refresh token lives in an
  // httpOnly cookie (JavaScript can't read it); the access token stays in memory.
  // ============================================================
  const COOKIE = 'ee_rt';
  const cookieOpts = { httpOnly: true, secure: process.env.NODE_ENV === 'production', sameSite: 'strict', path: '/admin/auth', maxAge: 30 * 864e5 };
  const readCookie = (req, name) =>
    (req.get('cookie') || '').split(';').map((s) => s.trim().split('=')).find(([k]) => k === name)?.[1];
  const session = (res, user, tokens) =>
    res.cookie(COOKIE, tokens.refreshToken, cookieOpts).json({ accessToken: tokens.accessToken, user: { id: user.id, name: user.name, role: user.role } });

  app.post('/admin/auth/login', authLimiter, wrap(async (req, res) => {
    const b = z.object({ phone: PHONE, password: z.string().min(1).max(72) }).parse(req.body);
    const u = await authenticate(req, b.phone, b.password);
    if (!STAFF.includes(u.role)) throw new HttpError(401, 'Invalid phone or password');
    session(res, u, await issueTokens(u));
  }));
  app.post('/admin/auth/refresh', authLimiter, wrap(async (req, res) => {
    const rt = readCookie(req, COOKIE);
    if (!rt) throw new HttpError(401, 'Unauthorized');
    const { user, tokens } = await rotateRefresh(req, rt);
    if (!STAFF.includes(user.role)) throw new HttpError(401, 'Unauthorized');
    session(res, user, tokens);
  }));
  app.post('/admin/auth/logout', wrap(async (req, res) => {
    const rt = readCookie(req, COOKIE);
    if (rt) await db.query('UPDATE refresh_tokens SET revoked = true WHERE token_hash = $1', [sha256(rt)]);
    res.clearCookie(COOKIE, { path: '/admin/auth' }).sendStatus(204);
  }));

  // ============================================================
  // ORDERS: live stream, list, detail, reject, review queue
  // ============================================================
  async function orderCard(id) {
    const { rows: [o] } = await db.query('SELECT o.*, u.name AS customer_name FROM orders o JOIN users u ON u.id = o.user_id WHERE o.id = $1', [id]);
    if (!o) return null;
    const { rows: items } = await db.query('SELECT name, qty, unit_price_paise AS "unitPricePaise" FROM order_items WHERE order_id = $1', [id]);
    return {
      ...publicOrder(o), customerName: o.customer_name, items, address: decrypt(o.address_enc),
      riskScore: o.risk_score, riskFlags: o.risk_flags,
      expiresAt: o.placed_at && o.status === 'placed' ? new Date(o.placed_at.getTime() + ACCEPT_TIMEOUT_MIN * 60000) : null,
    };
  }

  // Server-Sent Events: the panel gets a "new_order" the moment an order needs accepting.
  app.get('/admin/stream', requireAuth(...ORDER_VIEW), (req, res) => {
    res.set({ 'Content-Type': 'text/event-stream', 'Cache-Control': 'no-cache, no-transform', Connection: 'keep-alive' });
    res.flushHeaders();
    const send = (event, data) => res.write(`event: ${event}\ndata: ${JSON.stringify(data)}\n\n`);
    const onPlaced = (id) => orderCard(id).then((c) => c && send('new_order', c)).catch(() => {});
    const onStatus = (e) => send('order_status', e);
    bus.on('order_placed', onPlaced);
    bus.on('order_status', onStatus);
    const ping = setInterval(() => res.write(': ping\n\n'), 25000);
    const recycle = setTimeout(() => res.end(), 10 * 60000);        // forces the panel to re-authenticate
    req.on('close', () => { clearInterval(ping); clearTimeout(recycle); bus.off('order_placed', onPlaced); bus.off('order_status', onStatus); });
  });

  app.get('/admin/orders', requireAuth(...ORDER_VIEW), wrap(async (req, res) => {
    const q = z.object({ status: z.string().regex(/^[a-z_]+$/).optional(), q: z.string().trim().max(40).optional() }).parse(req.query);
    const { limit, offset } = paging(req.query);
    const params = [];
    const where = [];
    if (q.status) { params.push(q.status); where.push(`o.status = $${params.length}`); }
    if (q.q) { params.push(`%${q.q.replace(/[%_\\]/g, '\\$&')}%`); where.push(`(o.id::text ILIKE $${params.length} OR u.name ILIKE $${params.length})`); }
    const { rows } = await db.query(
      `SELECT o.*, u.name AS customer_name FROM orders o JOIN users u ON u.id = o.user_id
       ${where.length ? 'WHERE ' + where.join(' AND ') : ''} ORDER BY o.created_at DESC LIMIT ${limit} OFFSET ${offset}`, params);
    res.json(rows.map((o) => ({ ...publicOrder(o), customerName: o.customer_name, riskFlags: o.risk_flags })));
  }));

  app.get('/admin/orders/:id', requireAuth(...ORDER_VIEW), wrap(async (req, res) => {
    const card = await orderCard(uuid(req.params.id));
    if (!card) throw new HttpError(404, 'Not found');
    res.json(card);
  }));

  // Accept = PATCH /orders/:id/status {to:'accepted'}; reject needs a reason the customer can be told about.
  app.post('/admin/orders/:id/reject', requireAuth(...ORDER_STAFF), wrap(async (req, res) => {
    const id = uuid(req.params.id);
    const { reason } = z.object({ reason: z.string().trim().min(3).max(200) }).parse(req.body);
    const r = await db.query(
      `UPDATE orders SET status = 'cancelled', reject_reason = $2
       WHERE id = $1 AND status IN ('placed','under_review','accepted') RETURNING paid`, [id, reason]);
    if (!r.rowCount) throw new HttpError(409, 'This order can no longer be rejected');
    await audit(req, req.user.id, 'order_rejected', { orderId: id, needsRefund: r.rows[0].paid });
    bus.emit('order_status', { id, to: 'cancelled' });
    res.json({ status: 'cancelled', needsRefund: r.rows[0].paid });
  }));

  // Safety net: nobody answered the "call" in time, so the customer is not left waiting.
  setInterval(async () => {
    try {
      const { rows } = await db.query(
        `UPDATE orders SET status = 'cancelled', reject_reason = 'Restaurant did not respond in time'
         WHERE status = 'placed' AND placed_at < now() - ($1::int * interval '1 minute') RETURNING id, paid`, [ACCEPT_TIMEOUT_MIN]);
      for (const o of rows) {
        await audit(null, null, 'order_auto_cancelled', { orderId: o.id, needsRefund: o.paid });
        bus.emit('order_status', { id: o.id, to: 'cancelled' });
      }
    } catch (e) { console.error('auto-cancel job failed:', e.message); }
  }, 30000).unref();

  // ============================================================
  // DASHBOARD
  // ============================================================
  const num = (row) => Object.fromEntries(Object.entries(row).map(([k, v]) => [k, Number(v)]));
  const period = async (from, to) => num((await db.query(
    `SELECT count(*) FILTER (WHERE status <> 'pending_payment') AS orders,
            count(*) FILTER (WHERE status = 'delivered') AS delivered,
            count(*) FILTER (WHERE status = 'cancelled') AS cancelled,
            COALESCE(sum(total_paise) FILTER (WHERE status = 'delivered'), 0) AS revenue
     FROM orders WHERE created_at >= now() - $1::int * interval '1 day' AND created_at < now() - $2::int * interval '1 day'`,
    [from, to])).rows[0]);

  app.get('/admin/dashboard', requireAuth(...STAFF), wrap(async (req, res) => {
    const { days } = z.object({ days: z.coerce.number().int().min(1).max(365).default(7) }).parse(req.query);
    const [current, previous, series, top, riders, queue] = await Promise.all([
      period(days, 0),
      period(days * 2, days),
      db.query(
        `SELECT to_char(d, 'YYYY-MM-DD') AS day, count(o.id)::int AS orders,
                COALESCE(sum(o.total_paise) FILTER (WHERE o.status = 'delivered'), 0)::bigint AS revenue
         FROM generate_series((now() AT TIME ZONE '${TZ}')::date - ($1::int - 1), (now() AT TIME ZONE '${TZ}')::date, interval '1 day') d
         LEFT JOIN orders o ON (o.created_at AT TIME ZONE '${TZ}')::date = d::date AND o.status <> 'pending_payment'
         GROUP BY d ORDER BY d`, [days]).then((r) => r.rows.map(num)),
      db.query(
        `SELECT i.name, sum(i.qty)::int AS qty, sum(i.qty * i.unit_price_paise)::bigint AS revenue
         FROM order_items i JOIN orders o ON o.id = i.order_id
         WHERE o.status = 'delivered' AND o.created_at >= now() - $1::int * interval '1 day'
         GROUP BY i.name ORDER BY qty DESC LIMIT 5`, [days]).then((r) => r.rows.map((x) => ({ ...x, revenue: Number(x.revenue) }))),
      db.query(
        `SELECT count(*) FILTER (WHERE is_online AND last_seen_at > now() - interval '2 minutes') AS online, count(*) AS total
         FROM users WHERE role = 'rider' AND NOT is_blocked`).then((r) => num(r.rows[0])),
      db.query(
        `SELECT count(*) FILTER (WHERE status = 'placed') AS awaiting,
                count(*) FILTER (WHERE status = 'under_review') AS review,
                count(*) FILTER (WHERE status IN ('accepted','preparing','out_for_delivery')) AS active,
                (SELECT count(*) FROM payments p JOIN orders x ON x.id = p.order_id WHERE x.status = 'cancelled' AND p.refunded_at IS NULL) AS "refundsDue"
         FROM orders`).then((r) => num(r.rows[0])),
    ]);
    res.json({ current, previous, series, top, riders, queue });
  }));

  // ============================================================
  // CATALOGUE (items are archived, never deleted, so order history stays intact)
  // ============================================================
  const ItemSchema = z.object({
    name: z.string().trim().min(2).max(80),
    description: z.string().trim().max(500).default(''),
    pricePaise: z.number().int().min(100).max(1000000),
    isVeg: z.boolean(),
    category: z.string().trim().min(2).max(40),
    keywords: z.array(z.string().trim().toLowerCase().min(2).max(30)).max(20).default([]),
    imageUrl: z.string().regex(/^\/media\/[a-f0-9]{32}\.webp$/).nullable().default(null),
    isAvailable: z.boolean().default(true),
  });
  const itemRow = (r) => ({ id: r.id, name: r.name, description: r.description, pricePaise: r.price_paise, isVeg: r.is_veg,
    category: r.category, keywords: r.keywords, imageUrl: r.image_url, isAvailable: r.is_available });
  const imageExists = (url) => !url || fs.existsSync(path.join(UPLOAD_DIR, path.basename(url)));
  const itemParams = (b) => [b.name, b.description, b.pricePaise, b.isVeg, b.category, [...new Set(b.keywords)], b.imageUrl, b.isAvailable];

  app.get('/admin/catalogue', requireAuth(...ORDER_STAFF), wrap(async (_req, res) => {
    const { rows } = await db.query('SELECT * FROM menu_items ORDER BY category, name');
    res.json(rows.map(itemRow));
  }));
  app.post('/admin/catalogue', requireAuth(...ORDER_STAFF), wrap(async (req, res) => {
    const b = ItemSchema.parse(req.body);
    if (!imageExists(b.imageUrl)) throw new HttpError(400, 'Image not found. Upload it again.');
    const { rows: [r] } = await db.query(
      `INSERT INTO menu_items (name, description, price_paise, is_veg, category, keywords, image_url, is_available)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8) RETURNING *`, itemParams(b));
    await audit(req, req.user.id, 'item_created', { itemId: r.id, pricePaise: r.price_paise });
    res.status(201).json(itemRow(r));
  }));
  app.put('/admin/catalogue/:id', requireAuth(...ORDER_STAFF), wrap(async (req, res) => {
    const id = uuid(req.params.id);
    const b = ItemSchema.parse(req.body);
    if (!imageExists(b.imageUrl)) throw new HttpError(400, 'Image not found. Upload it again.');
    const { rows: [r] } = await db.query(
      `UPDATE menu_items SET name=$1, description=$2, price_paise=$3, is_veg=$4, category=$5, keywords=$6,
         image_url=$7, is_available=$8, updated_at=now() WHERE id=$9 RETURNING *`, [...itemParams(b), id]);
    if (!r) throw new HttpError(404, 'Not found');
    await audit(req, req.user.id, 'item_updated', { itemId: id, pricePaise: r.price_paise, available: r.is_available });
    res.json(itemRow(r));
  }));

  // Photos are re-encoded with sharp: proves it is a real image, strips metadata, caps the size.
  const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 4 * 1024 * 1024, files: 1 } }).single('image');
  app.post('/admin/catalogue/image', requireAuth(...ORDER_STAFF),
    (req, res, next) => upload(req, res, (e) => (e ? next(new HttpError(400, 'Image must be under 4 MB')) : next())),
    wrap(async (req, res) => {
      if (!req.file) throw new HttpError(400, 'No image received');
      let out;
      try {
        out = await sharp(req.file.buffer, { limitInputPixels: 40e6 }).rotate()
          .resize({ width: 1000, height: 1000, fit: 'inside', withoutEnlargement: true }).webp({ quality: 80 }).toBuffer();
      } catch { throw new HttpError(400, 'That file is not a valid image'); }
      const name = `${crypto.randomBytes(16).toString('hex')}.webp`;
      await fs.promises.writeFile(path.join(UPLOAD_DIR, name), out);
      res.status(201).json({ imageUrl: `/media/${name}` });
    }));

  // ============================================================
  // CUSTOMERS (phone masked in lists; the full number is audit-logged when opened)
  // ============================================================
  app.get('/admin/customers', requireAuth(...CRM), wrap(async (req, res) => {
    const q = z.object({ q: z.string().trim().max(40).optional() }).parse(req.query);
    const { limit, offset } = paging(req.query);
    const params = [];
    let filter = '';
    if (q.q && /^[6-9]\d{9}$/.test(q.q)) { params.push(blindIndex(q.q)); filter = 'AND u.phone_hash = $1'; }
    else if (q.q) { params.push(`%${q.q.replace(/[%_\\]/g, '\\$&')}%`); filter = 'AND u.name ILIKE $1'; }
    const { rows } = await db.query(
      `SELECT u.id, u.name, u.phone_enc, u.created_at, u.is_blocked,
              count(o.id) FILTER (WHERE o.status <> 'pending_payment') AS orders,
              COALESCE(sum(o.total_paise) FILTER (WHERE o.status = 'delivered'), 0) AS spent
       FROM users u LEFT JOIN orders o ON o.user_id = u.id WHERE u.role = 'customer' ${filter}
       GROUP BY u.id ORDER BY u.created_at DESC LIMIT ${limit} OFFSET ${offset}`, params);
    res.json(rows.map((u) => ({ id: u.id, name: u.name, phone: mask(decrypt(u.phone_enc)), joinedAt: u.created_at,
      blocked: u.is_blocked, orders: Number(u.orders), spentPaise: Number(u.spent) })));
  }));

  app.get('/admin/customers/:id', requireAuth(...CRM), wrap(async (req, res) => {
    const id = uuid(req.params.id);
    const { rows: [u] } = await db.query("SELECT * FROM users WHERE id = $1 AND role = 'customer'", [id]);
    if (!u) throw new HttpError(404, 'Not found');
    const { rows: orders } = await db.query('SELECT * FROM orders WHERE user_id = $1 ORDER BY created_at DESC LIMIT 20', [id]);
    await audit(req, req.user.id, 'viewed_customer', { customerId: id });
    res.json({ id, name: u.name, phone: decrypt(u.phone_enc), blocked: u.is_blocked, joinedAt: u.created_at, orders: orders.map(publicOrder) });
  }));

  app.patch('/admin/users/:id/block', requireAuth(...CRM), wrap(async (req, res) => {
    const id = uuid(req.params.id);
    const { blocked } = z.object({ blocked: z.boolean() }).parse(req.body);
    if (id === req.user.id) throw new HttpError(400, 'You cannot block yourself');
    const { rows: [t] } = await db.query('SELECT role FROM users WHERE id = $1', [id]);
    if (!t) throw new HttpError(404, 'Not found');
    if (req.user.role !== 'super_admin' && t.role !== 'customer') throw new HttpError(403, 'Forbidden');
    await db.query('UPDATE users SET is_blocked = $2 WHERE id = $1', [id, blocked]);
    if (blocked) await db.query('UPDATE refresh_tokens SET revoked = true WHERE user_id = $1', [id]);
    await audit(req, req.user.id, blocked ? 'user_blocked' : 'user_unblocked', { userId: id });
    res.json({ blocked });
  }));

  // ============================================================
  // RIDERS
  // ============================================================
  app.get('/admin/riders', requireAuth(...ORDER_STAFF), wrap(async (_req, res) => {
    const { rows } = await db.query(
      `SELECT u.id, u.name, u.phone_enc, u.is_blocked,
              COALESCE(u.is_online AND u.last_seen_at > now() - interval '2 minutes', false) AS online,
              count(o.id) FILTER (WHERE o.status = 'out_for_delivery') AS active,
              count(o.id) FILTER (WHERE o.status = 'delivered') AS delivered
       FROM users u LEFT JOIN orders o ON o.rider_id = u.id WHERE u.role = 'rider'
       GROUP BY u.id ORDER BY online DESC, u.name`);
    res.json(rows.map((r) => ({ id: r.id, name: r.name, phone: decrypt(r.phone_enc), online: r.online, blocked: r.is_blocked,
      active: Number(r.active), delivered: Number(r.delivered) })));
  }));

  // ============================================================
  // REVIEWS
  // ============================================================
  app.get('/admin/reviews', requireAuth(...ORDER_VIEW), wrap(async (_req, res) => {
    const { rows } = await db.query('SELECT r.*, u.name AS customer_name FROM reviews r JOIN users u ON u.id = r.user_id ORDER BY r.created_at DESC LIMIT 100');
    const { rows: [s] } = await db.query('SELECT count(*)::int AS count, COALESCE(round(avg(rating)::numeric, 2), 0)::float AS avg FROM reviews WHERE NOT hidden');
    res.json({ summary: s, reviews: rows.map((r) => ({ id: r.id, orderId: r.order_id, customerName: r.customer_name, rating: r.rating,
      comment: r.comment, reply: r.reply, hidden: r.hidden, createdAt: r.created_at })) });
  }));
  app.patch('/admin/reviews/:id', requireAuth(...ORDER_VIEW), wrap(async (req, res) => {
    const id = uuid(req.params.id);
    const b = z.object({ hidden: z.boolean().optional(), reply: z.string().trim().min(1).max(300).optional() })
      .refine((v) => v.hidden !== undefined || v.reply, { message: 'Nothing to change' }).parse(req.body);
    const r = await db.query('UPDATE reviews SET hidden = COALESCE($2, hidden), reply = COALESCE($3, reply) WHERE id = $1', [id, b.hidden ?? null, b.reply ?? null]);
    if (!r.rowCount) throw new HttpError(404, 'Not found');
    await audit(req, req.user.id, 'review_updated', { reviewId: id, hidden: b.hidden });
    res.sendStatus(204);
  }));

  // ============================================================
  // MARKETING: push notifications to the customer app
  // ============================================================
  app.get('/admin/notifications', requireAuth(...MARKETING), wrap(async (_req, res) => {
    const { rows } = await db.query('SELECT id, audience, title, body, sent_count AS "sentCount", created_at AS "createdAt" FROM notifications ORDER BY created_at DESC LIMIT 50');
    res.json(rows);
  }));
  app.post('/admin/notifications', requireAuth(...MARKETING), wrap(async (req, res) => {
    const b = z.object({ title: z.string().trim().min(2).max(60), body: z.string().trim().min(2).max(200),
      audience: z.enum(['all', 'one']), phone: PHONE.optional() })
      .refine((v) => v.audience === 'all' || v.phone, { message: 'Customer phone is required' }).parse(req.body);
    let target = 'all_customers';
    let userId = null;
    if (b.audience === 'one') {
      const { rows: [u] } = await db.query("SELECT id FROM users WHERE phone_hash = $1 AND role = 'customer'", [blindIndex(b.phone)]);
      if (!u) throw new HttpError(404, 'No customer with that number');
      userId = u.id; target = [u.id];
    } else if ((await db.query("SELECT 1 FROM notifications WHERE audience = 'all' AND created_at > now() - interval '10 minutes'")).rowCount) {
      throw new HttpError(429, 'A broadcast was already sent in the last 10 minutes');
    }
    const { rows: [n] } = await db.query('INSERT INTO notifications (sent_by, audience, user_id, title, body) VALUES ($1,$2,$3,$4,$5) RETURNING id',
      [req.user.id, b.audience, userId, b.title, b.body]);
    const sent = await pushToUsers(target, { title: b.title, body: b.body, data: { type: 'promo' } });
    await db.query('UPDATE notifications SET sent_count = $2 WHERE id = $1', [n.id, sent]);
    await audit(req, req.user.id, 'notification_sent', { audience: b.audience, sent });
    res.status(201).json({ sent });
  }));

  // ============================================================
  // PAYMENTS: reconcile with the gateway, refund cancelled orders
  // ============================================================
  async function gateway(method, p, body, headers = {}) {
    const r = await fetch(`https://api.razorpay.com/v1${p}`, {
      method, signal: AbortSignal.timeout(10000), body: body ? JSON.stringify(body) : undefined,
      headers: { Authorization: 'Basic ' + Buffer.from(`${RAZORPAY_KEY_ID}:${RAZORPAY_KEY_SECRET}`).toString('base64'), 'Content-Type': 'application/json', ...headers },
    });
    const j = await r.json().catch(() => ({}));
    if (!r.ok) throw new HttpError(502, j?.error?.description || 'Payment gateway error');
    return j;
  }
  const PID = z.string().regex(/^[A-Za-z0-9_]{6,40}$/);

  app.get('/admin/payments', requireAuth(...OWNER), wrap(async (req, res) => {
    const { limit, offset } = paging(req.query);
    const { rows } = await db.query(
      `SELECT p.provider_payment_id AS id, p.order_id AS "orderId", p.amount_paise AS "amountPaise", p.created_at AS "createdAt",
              p.refunded_at AS "refundedAt", o.status AS "orderStatus", o.total_paise AS "orderTotalPaise",
              (o.status = 'cancelled' AND p.refunded_at IS NULL) AS "refundDue", (p.amount_paise <> o.total_paise) AS mismatch
       FROM payments p JOIN orders o ON o.id = p.order_id ORDER BY p.created_at DESC LIMIT ${limit} OFFSET ${offset}`);
    res.json(rows);
  }));

  // Asks the gateway itself, so the panel never relies only on what our own database says.
  app.post('/admin/payments/:pid/verify', requireAuth(...OWNER), wrap(async (req, res) => {
    const pid = PID.parse(req.params.pid);
    const { rows: [p] } = await db.query('SELECT amount_paise FROM payments WHERE provider_payment_id = $1', [pid]);
    if (!p) throw new HttpError(404, 'Not found');
    const g = await gateway('GET', `/payments/${pid}`);
    res.json({ gatewayStatus: g.status, gatewayAmountPaise: g.amount, refundedPaise: g.amount_refunded,
      matches: g.amount === p.amount_paise && ['captured', 'refunded'].includes(g.status) });
  }));

  app.post('/admin/payments/:pid/refund', requireAuth(...OWNER), wrap(async (req, res) => {
    const pid = PID.parse(req.params.pid);
    await withTx(async (tx) => {
      const { rows: [p] } = await tx.query(
        `SELECT p.*, o.status AS order_status FROM payments p JOIN orders o ON o.id = p.order_id
         WHERE p.provider_payment_id = $1 FOR UPDATE OF p`, [pid]);
      if (!p) throw new HttpError(404, 'Not found');
      if (p.refunded_at) throw new HttpError(409, 'Already refunded');
      if (p.order_status !== 'cancelled') throw new HttpError(409, 'Only cancelled orders can be refunded');
      const g = await gateway('POST', `/payments/${pid}/refund`, { amount: p.amount_paise }, { 'X-Refund-Idempotency': pid });
      await tx.query('UPDATE payments SET refund_id = $2, refunded_at = now() WHERE provider_payment_id = $1', [pid, g.id]);
      await audit(req, req.user.id, 'payment_refunded', { paymentId: pid, refundId: g.id });
    });
    res.json({ ok: true });
  }));

  // ============================================================
  // STAFF + RIDER ACCOUNTS (super admin only)
  // ============================================================
  app.get('/admin/staff', requireAuth(...OWNER), wrap(async (_req, res) => {
    const { rows } = await db.query("SELECT id, name, role, phone_enc, is_blocked, created_at FROM users WHERE role <> 'customer' ORDER BY role, name");
    res.json(rows.map((u) => ({ id: u.id, name: u.name, role: u.role, phone: decrypt(u.phone_enc), blocked: u.is_blocked, createdAt: u.created_at })));
  }));
  app.post('/admin/staff', requireAuth(...OWNER), wrap(async (req, res) => {
    const b = z.object({ name: z.string().trim().min(2).max(60), phone: PHONE, password: z.string().min(10).max(72),
      role: z.enum([...STAFF, 'rider']) }).parse(req.body);
    try {
      const { rows: [u] } = await db.query('INSERT INTO users (name, phone_enc, phone_hash, password_hash, role) VALUES ($1,$2,$3,$4,$5) RETURNING id',
        [b.name, encrypt(b.phone), blindIndex(b.phone), await bcrypt.hash(b.password, 12), b.role]);
      await audit(req, req.user.id, 'staff_created', { userId: u.id, role: b.role });
      res.status(201).json({ id: u.id });
    } catch (e) {
      if (e.code === '23505') throw new HttpError(409, 'That phone number is already registered');
      throw e;
    }
  }));

  // ============================================================
  // WEB PUSH for staff browsers (alerts even when the panel tab is closed)
  // ============================================================
  const PUSH_HOSTS = /^https:\/\/([a-z0-9-]+\.)*(googleapis\.com|mozilla\.com|push\.apple\.com|windows\.com)\//;   // blocks SSRF
  app.get('/admin/push/key', requireAuth(...ORDER_STAFF), (_req, res) => res.json({ key: process.env.VAPID_PUBLIC_KEY }));
  app.post('/admin/push/subscribe', requireAuth(...ORDER_STAFF), wrap(async (req, res) => {
    const b = z.object({ endpoint: z.string().url().max(1000).regex(PUSH_HOSTS),
      keys: z.object({ p256dh: z.string().max(200), auth: z.string().max(100) }) }).parse(req.body);
    await db.query(
      `INSERT INTO push_subscriptions (endpoint, user_id, p256dh, auth) VALUES ($1,$2,$3,$4)
       ON CONFLICT (endpoint) DO UPDATE SET user_id = $2, p256dh = $3, auth = $4`, [b.endpoint, req.user.id, b.keys.p256dh, b.keys.auth]);
    res.sendStatus(204);
  }));
};
