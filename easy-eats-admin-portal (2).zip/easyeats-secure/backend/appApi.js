'use strict';
// Endpoints used by the CUSTOMER app and the RIDER app.
module.exports = ({ app, db, wrap, HttpError, z, requireAuth, decrypt }) => {
  const uuid = (v) => z.string().uuid().parse(v);

  // ---- Customer app: menu + search (only items that are available) ----
  app.get('/menu', wrap(async (req, res) => {
    const q = z.object({ q: z.string().trim().max(60).optional(), veg: z.enum(['true', 'false']).optional() }).parse(req.query);
    const params = [];
    const where = ['is_available'];
    if (q.veg) { params.push(q.veg === 'true'); where.push(`is_veg = $${params.length}`); }
    if (q.q) {
      params.push(`%${q.q.replace(/[%_\\]/g, '\\$&')}%`);
      const p = `$${params.length}`;
      where.push(`(name ILIKE ${p} OR description ILIKE ${p} OR array_to_string(keywords, ' ') ILIKE ${p})`);
    }
    const { rows } = await db.query(
      `SELECT id, name, description, price_paise AS "pricePaise", image_url AS "imageUrl", is_veg AS "isVeg", category
       FROM menu_items WHERE ${where.join(' AND ')} ORDER BY category, name LIMIT 200`, params);
    res.json(rows);   // imageUrl is relative: the app prefixes it with the API base URL
  }));

  // ---- Customer + rider apps: register / remove the phone's FCM token ----
  app.post('/devices', requireAuth('customer', 'rider'), wrap(async (req, res) => {
    const b = z.object({ token: z.string().min(20).max(4096), platform: z.enum(['android', 'ios']) }).parse(req.body);
    await db.query(
      `INSERT INTO device_tokens (token, user_id, platform) VALUES ($1,$2,$3)
       ON CONFLICT (token) DO UPDATE SET user_id = $2, platform = $3, updated_at = now()`,
      [b.token, req.user.id, b.platform]);
    res.sendStatus(204);
  }));
  app.delete('/devices', requireAuth('customer', 'rider'), wrap(async (req, res) => {
    const { token } = z.object({ token: z.string().min(20).max(4096) }).parse(req.body);
    await db.query('DELETE FROM device_tokens WHERE token = $1 AND user_id = $2', [token, req.user.id]);
    res.sendStatus(204);
  }));

  // ---- Customer app: review a delivered order (once) ----
  app.post('/orders/:id/review', requireAuth('customer'), wrap(async (req, res) => {
    const id = uuid(req.params.id);
    const b = z.object({ rating: z.number().int().min(1).max(5), comment: z.string().trim().max(500).default('') }).parse(req.body);
    const r = await db.query(
      `INSERT INTO reviews (order_id, user_id, rating, comment)
       SELECT id, user_id, $3, $4 FROM orders WHERE id = $1 AND user_id = $2 AND status = 'delivered'
       ON CONFLICT (order_id) DO NOTHING RETURNING id`, [id, req.user.id, b.rating, b.comment]);
    if (!r.rowCount) throw new HttpError(409, 'You can review a delivered order once');
    res.status(201).json({ id: r.rows[0].id });
  }));

  // ---- Rider app: go online/offline + heartbeat (send every ~60 s while online) ----
  app.post('/rider/heartbeat', requireAuth('rider'), wrap(async (req, res) => {
    const { online } = z.object({ online: z.boolean() }).parse(req.body);
    await db.query('UPDATE users SET is_online = $2, last_seen_at = now() WHERE id = $1', [req.user.id, online]);
    res.sendStatus(204);
  }));

  // ---- Rider app: orders ready to pick up + my active delivery ----
  // Claim an order with PATCH /orders/:id/status {to:'out_for_delivery'}; finish with POST /orders/:id/deliver {otp}
  app.get('/rider/orders', requireAuth('rider'), wrap(async (req, res) => {
    const { rows } = await db.query(
      `SELECT id, status, payment_method, total_paise, address_enc, rider_id FROM orders
       WHERE (status = 'preparing' AND rider_id IS NULL) OR (status = 'out_for_delivery' AND rider_id = $1)
       ORDER BY created_at LIMIT 30`, [req.user.id]);
    res.json(rows.map((o) => ({
      id: o.id, status: o.status,
      collectCashPaise: o.payment_method === 'cod' ? o.total_paise : 0,
      address: o.rider_id === req.user.id ? decrypt(o.address_enc) : undefined,   // address only after claiming
    })));
  }));
};
