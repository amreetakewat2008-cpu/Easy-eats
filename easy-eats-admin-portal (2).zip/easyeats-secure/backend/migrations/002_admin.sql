-- Run AFTER schema.sql:  psql "$DATABASE_URL" -f migrations/002_admin.sql

-- Real staff roles (replaces the old single 'admin' role)
ALTER TABLE users DROP CONSTRAINT IF EXISTS users_role_check;
UPDATE users SET role = 'super_admin' WHERE role = 'admin';
ALTER TABLE users ADD CONSTRAINT users_role_check CHECK (role IN
  ('customer','rider','super_admin','restaurant_manager','marketing_lead','customer_support'));
ALTER TABLE users
  ADD COLUMN IF NOT EXISTS is_online    boolean NOT NULL DEFAULT false,
  ADD COLUMN IF NOT EXISTS last_seen_at timestamptz;

-- Catalogue
ALTER TABLE menu_items
  ADD COLUMN IF NOT EXISTS description  text    NOT NULL DEFAULT '',
  ADD COLUMN IF NOT EXISTS image_url    text,
  ADD COLUMN IF NOT EXISTS is_veg       boolean NOT NULL DEFAULT true,
  ADD COLUMN IF NOT EXISTS category     text    NOT NULL DEFAULT 'Other',
  ADD COLUMN IF NOT EXISTS keywords     text[]  NOT NULL DEFAULT '{}',
  ADD COLUMN IF NOT EXISTS updated_at   timestamptz NOT NULL DEFAULT now();
CREATE INDEX IF NOT EXISTS menu_keywords_gin ON menu_items USING gin (keywords);

-- Orders: when the restaurant was asked to accept, and why it was rejected
ALTER TABLE orders
  ADD COLUMN IF NOT EXISTS placed_at     timestamptz,
  ADD COLUMN IF NOT EXISTS reject_reason text;
CREATE OR REPLACE FUNCTION set_placed_at() RETURNS trigger AS $$
BEGIN
  IF NEW.status = 'placed' AND (TG_OP = 'INSERT' OR OLD.status IS DISTINCT FROM 'placed') THEN
    NEW.placed_at := now();
  END IF;
  RETURN NEW;
END $$ LANGUAGE plpgsql;
DROP TRIGGER IF EXISTS orders_placed_at ON orders;
CREATE TRIGGER orders_placed_at BEFORE INSERT OR UPDATE ON orders
  FOR EACH ROW EXECUTE FUNCTION set_placed_at();

-- Refund tracking
ALTER TABLE payments
  ADD COLUMN IF NOT EXISTS refund_id   text,
  ADD COLUMN IF NOT EXISTS refunded_at timestamptz;

CREATE TABLE IF NOT EXISTS reviews (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id    uuid NOT NULL UNIQUE REFERENCES orders(id),   -- one review per order
  user_id     uuid NOT NULL REFERENCES users(id),
  rating      int  NOT NULL CHECK (rating BETWEEN 1 AND 5),
  comment     text NOT NULL DEFAULT '',
  hidden      boolean NOT NULL DEFAULT false,
  reply       text,
  created_at  timestamptz NOT NULL DEFAULT now()
);

-- Push: FCM tokens of customer/rider phones, Web Push subscriptions of staff browsers
CREATE TABLE IF NOT EXISTS device_tokens (
  token       text PRIMARY KEY,
  user_id     uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  platform    text NOT NULL,
  updated_at  timestamptz NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS push_subscriptions (
  endpoint  text PRIMARY KEY,
  user_id   uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  p256dh    text NOT NULL,
  auth      text NOT NULL
);
CREATE TABLE IF NOT EXISTS notifications (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  sent_by     uuid REFERENCES users(id),
  audience    text NOT NULL CHECK (audience IN ('all','one')),
  user_id     uuid REFERENCES users(id),
  title       text NOT NULL,
  body        text NOT NULL,
  sent_count  int  NOT NULL DEFAULT 0,
  created_at  timestamptz NOT NULL DEFAULT now()
);
