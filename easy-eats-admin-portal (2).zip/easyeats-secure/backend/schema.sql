-- Run once:  psql "$DATABASE_URL" -f schema.sql
-- Money is ALWAYS stored as integer paise (Rs 1 = 100 paise). Never floats.
CREATE EXTENSION IF NOT EXISTS pgcrypto;

CREATE TABLE users (
  id             uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name           text NOT NULL,
  phone_enc      text NOT NULL,          -- AES-256-GCM encrypted
  phone_hash     text NOT NULL UNIQUE,   -- HMAC "blind index" so we can look up by phone
  password_hash  text NOT NULL,          -- bcrypt, never the password itself
  role           text NOT NULL DEFAULT 'customer' CHECK (role IN ('customer','rider','admin')),
  failed_logins  int  NOT NULL DEFAULT 0,
  locked_until   timestamptz,
  is_blocked     boolean NOT NULL DEFAULT false,
  created_at     timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE refresh_tokens (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id     uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  token_hash  text NOT NULL UNIQUE,      -- only the hash is stored
  revoked     boolean NOT NULL DEFAULT false,
  expires_at  timestamptz NOT NULL,
  created_at  timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE menu_items (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name          text NOT NULL,
  price_paise   int  NOT NULL CHECK (price_paise > 0),
  is_available  boolean NOT NULL DEFAULT true
);

CREATE TABLE coupons (
  code                text PRIMARY KEY,
  percent_off         int  NOT NULL CHECK (percent_off BETWEEN 1 AND 50),
  max_discount_paise  int  NOT NULL CHECK (max_discount_paise > 0),
  min_order_paise     int  NOT NULL DEFAULT 0,
  max_redemptions     int  NOT NULL CHECK (max_redemptions > 0),
  redeemed_count      int  NOT NULL DEFAULT 0 CHECK (redeemed_count >= 0),
  expires_at          timestamptz NOT NULL
);

CREATE TABLE coupon_redemptions (
  code     text NOT NULL REFERENCES coupons(code),
  user_id  uuid NOT NULL REFERENCES users(id),
  PRIMARY KEY (code, user_id)            -- one use per customer, enforced by the database
);

CREATE TABLE orders (
  id               uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id          uuid NOT NULL REFERENCES users(id),
  rider_id         uuid REFERENCES users(id),
  idempotency_key  text NOT NULL,
  status           text NOT NULL CHECK (status IN
                     ('pending_payment','under_review','placed','accepted','preparing',
                      'out_for_delivery','delivered','cancelled','failed')),
  payment_method   text NOT NULL CHECK (payment_method IN ('online','cod')),
  paid             boolean NOT NULL DEFAULT false,
  subtotal_paise   int NOT NULL CHECK (subtotal_paise > 0),
  discount_paise   int NOT NULL DEFAULT 0 CHECK (discount_paise >= 0),
  delivery_paise   int NOT NULL DEFAULT 0 CHECK (delivery_paise >= 0),
  total_paise      int NOT NULL CHECK (total_paise > 0),
  coupon_code      text,
  address_enc      text NOT NULL,        -- encrypted
  address_hash     text NOT NULL,        -- used to spot one address used by many accounts
  otp_enc          text NOT NULL,        -- delivery code, encrypted
  otp_attempts     int  NOT NULL DEFAULT 0,
  risk_score       int  NOT NULL DEFAULT 0,
  risk_flags       text[] NOT NULL DEFAULT '{}',
  created_at       timestamptz NOT NULL DEFAULT now(),
  UNIQUE (user_id, idempotency_key)      -- double-tap / retry can never create two orders
);
CREATE INDEX orders_user_created ON orders (user_id, created_at DESC);
CREATE INDEX orders_address_hash ON orders (address_hash, created_at);

CREATE TABLE order_items (
  order_id          uuid NOT NULL REFERENCES orders(id),
  menu_item_id      uuid NOT NULL REFERENCES menu_items(id),
  name              text NOT NULL,
  unit_price_paise  int  NOT NULL,       -- price frozen at order time
  qty               int  NOT NULL CHECK (qty BETWEEN 1 AND 10),
  PRIMARY KEY (order_id, menu_item_id)
);

CREATE TABLE payments (
  provider_payment_id  text PRIMARY KEY, -- a replayed webhook can't credit an order twice
  order_id             uuid NOT NULL REFERENCES orders(id),
  amount_paise         int  NOT NULL,
  created_at           timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE audit_log (
  id          bigserial PRIMARY KEY,
  user_id     uuid,
  action      text NOT NULL,
  detail      jsonb NOT NULL DEFAULT '{}',
  ip          text,
  created_at  timestamptz NOT NULL DEFAULT now()
);

-- Run the app with a database user that has only SELECT/INSERT/UPDATE
-- (no DROP, no superuser), and never UPDATE/DELETE on audit_log.
