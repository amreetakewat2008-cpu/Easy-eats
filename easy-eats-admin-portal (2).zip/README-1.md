# Easy Eats: admin panel + customer/rider API

One Node.js server (`backend/`) does everything: the customer app API, the rider app API, and the admin API. It also serves the admin panel (`admin-web/`) at `/panel/`. No demo data, no simulator: real sign-in, a real PostgreSQL database, real payment checks.

```
Customer app ─┐                    ┌─ PostgreSQL (orders, menu, users, reviews…)
Rider app   ──┼─> backend/ (API) ──┼─ Razorpay (payments, refunds)
Admin panel ──┘   one server       └─ Firebase FCM (push to phones) + Web Push (staff browsers)
```

## 1. Set up (about 20 minutes)

```bash
# Backend
cd backend
npm install
cp .env.example .env            # fill in every value (see comments in the file)
psql "$DATABASE_URL" -f schema.sql
psql "$DATABASE_URL" -f migrations/002_admin.sql
read -rs ADMIN_PASSWORD && export ADMIN_PASSWORD     # type a strong password (hidden)
ADMIN_NAME="Your Name" ADMIN_PHONE=9XXXXXXXXX npm run create-admin
cd ..

# Admin panel (builds into admin-web/dist, which the backend serves)
cd admin-web && npm install && npm run build && cd ..

cd backend && npm start         # open https://YOUR-DOMAIN/panel/
```

Needed first: a Razorpay account (keys + webhook secret), a Firebase project (service-account JSON for push), and VAPID keys (`npx web-push generate-vapid-keys`). Staff alerts and the sign-in cookie need **HTTPS**; `localhost` is fine for testing.

## 2. Who can do what (enforced by the server, not just hidden in the menu)

| Role | Access |
|---|---|
| Super Admin | everything, plus Payments (verify, refund) and Staff accounts |
| Restaurant Manager | incoming orders (accept/reject), Orders, Catalogue, Riders, Reviews |
| Marketing Lead | Dashboard, Marketing (push notifications) |
| Customer Support | Customers (block/unblock), Orders (view only), Reviews |

## 3. How orders flow

1. Customer places an order (`POST /orders`). Cash-on-delivery orders, and online orders once the Razorpay webhook confirms payment, become **placed**.
2. The panel gets the order instantly and shows a full-screen ringing "incoming order" with **Accept / Reject**. If the tab is closed, a Web Push alert shows instead. Nobody answers within 5 minutes → auto-cancelled, customer told.
3. Accept → customer gets a push. Manager marks **preparing** → online riders get a push.
4. A rider claims it (`out_for_delivery`), then completes it with the customer's 4-digit code.
5. Every status change pushes to the customer. After delivery the customer can leave one review.

## 4. What the customer and rider apps must call

| App | Call | Purpose |
|---|---|---|
| Both | `POST /auth/register`, `POST /auth/login`, `POST /auth/refresh` | sign in (staff cannot sign in here) |
| Both | `POST /devices {token, platform}` | register the FCM push token after login; `DELETE /devices` on logout |
| Customer | `GET /menu?q=&veg=true\|false` | items, with search over title, description and keywords. `imageUrl` is relative: prefix your API URL |
| Customer | `POST /orders` (header `Idempotency-Key`) | place order; see `flutter/api_client.dart` |
| Customer | `GET /orders`, `GET /orders/:id` | history; the delivery code shows only while out for delivery |
| Customer | `POST /orders/:id/cancel` | cancel before it is accepted |
| Customer | `POST /orders/:id/review {rating 1-5, comment}` | one review per delivered order |
| Rider | `POST /rider/heartbeat {online}` | every ~60 s while online (drives "Riders online") |
| Rider | `GET /rider/orders` | ready-to-pick-up orders + my active delivery (address shown after claiming) |
| Rider | `PATCH /orders/:id/status {to:"out_for_delivery"}` | claim an order |
| Rider | `POST /orders/:id/deliver {otp}` | finish delivery with the customer's code |

Push payloads carry `data.type`: `order_status`, `promo` (customer app) and `rider_new_order` (rider app), plus `orderId` where relevant. Use them to open the right screen.

## 4b. Panel screens

Dashboard (orders, revenue, average order, cancellation rate, riders online, queue, daily revenue, top items, change vs the previous period, all calculated from real orders), Orders (history with filters + actions), Catalogue (photo upload, title, description, price, veg/non-veg, category, search keywords, hide/show), Riders, Customers (masked phone in lists, block/unblock), Marketing (push to all or one customer), Reviews (reply, hide), Payments (gateway verify, refunds), Staff (create accounts).

## 5. Security built in

- Passwords hashed (bcrypt), lockout after 5 wrong tries, rate limits, every input validated.
- Admin login keeps the refresh token in an `httpOnly`, `SameSite=Strict` cookie; the access token only lives in memory. Tokens rotate; reusing an old one signs the user out everywhere.
- Roles are checked on the server on every request, read fresh from the database.
- Phone numbers and addresses are encrypted in the database. Customer phone numbers are masked in lists; opening a full number is written to the audit log.
- Photos are re-encoded server-side (proves it is a real image, removes hidden data).
- Prices always come from the database. Payment webhooks are signature-checked and amounts must match. The Payments page can ask Razorpay directly to confirm a payment, and refunds are idempotent.
- Menu items are hidden, never deleted, so order history and money records stay intact.

## 6. Before real customers

- [ ] HTTPS on the domain; set `NODE_ENV=production`
- [ ] Run on **one** server instance first (live events use in-process memory; for several servers, move them to Redis or Postgres LISTEN/NOTIFY)
- [ ] Store photos on a persistent disk (`UPLOAD_DIR`) or move them to S3/R2; back them up
- [ ] Back up the database daily and test a restore; back up `DATA_KEY_HEX` separately
- [ ] Add SMS OTP at sign-up (still the best fake-account blocker)
- [ ] Test on staging with Razorpay test keys: place, pay, accept, deliver, cancel, refund
- [ ] Watch `audit_log` for `login_failed`, `refresh_token_reuse`, `order_blocked`, `payment_amount_mismatch`
- [ ] `npm audit` monthly; a paid security review before launch is worth it
