# Production Data Cleanup & Real-Only Mode for Easy Admin

Remove every demo account, seeded record, placeholder image, prefilled credential, hardcoded delivery address, and simulated payment fallback from the Easy Admin portal so the application boots cleanly with zero fake data and operates strictly against real persisted records and real external integrations.

## User Review & Critical Decisions

> [!IMPORTANT]
> The decisions below were confirmed during clarification and govern this implementation. All attached reference architecture materials will remain completely untouched.

- **Confirmed Decision 1 — First-Launch Super Admin Bootstrap**: When no Super Admin account exists in the database, the portal opens a dedicated one-time **Initial Super Admin Setup** screen to register the owner's real name, 10-digit mobile number, and strong password. Once created, the setup endpoint and screen permanently lock.
- **Confirmed Decision 2 — Clean Database Wipe**: The existing seeded SQLite database will be wiped and re-initialized empty with zero demo staff, customers, riders, menu items, orders, payments, reviews, coupons, notifications, or fake restaurant defaults.
- **Confirmed Decision 3 — Strict Real-Only Payments & Popup Campaigns**: Razorpay verification and refund endpoints will strictly require real `RAZORPAY_KEY_ID` and `RAZORPAY_KEY_SECRET` credentials (returning clear server configuration errors instead of simulated reconciliations or fake refund IDs). In-app 4:5 popup campaigns will persist in SQLite using real uploaded server images (`/media/*`) with empty initial form fields and no stock placeholder URLs.

---

## 1. Overview & Core Concept

- **What It Does**: Converts Easy Admin from a pre-populated preview build into a clean, production-ready restaurant operations portal. Every module—Authentication, Dashboard, Orders, Catalogue, Riders, Customers, Reviews, Payments, Marketing & Popups, Notifications, Staff, and Settings—operates exclusively on real database entries, real uploaded media, and configured external APIs.
- **Target Audience / Persona**: Restaurant owners (Super Admins), outlet managers, kitchen staff, and support agents launching Easy Eats in a live environment without risking accidental exposure of test credentials, dummy orders, or fake financial actions.
- **Key Value**: Eliminates default-credential vulnerabilities, prevents confusion between real and mock metrics or refunds, and provides a clear guided starting experience from a genuinely empty database.

---

## 2. User Experience & Visual Design

### Key User Flows

1. **First-Time Launch (Zero Accounts)**:
   - On startup, the client checks setup status from the backend.
   - If zero Super Admins exist, the portal displays a focused **Create Super Admin Account** onboarding card (Full Name, 10-Digit Mobile Number, Password with strength requirement, and Confirm Password).
   - Submitting creates the Super Admin atomically, records an audit event, issues the `httpOnly` refresh cookie and in-memory access token, and lands the owner directly inside the clean Dashboard.
2. **Subsequent Sign-Ins**:
   - The setup screen is permanently inaccessible once a Super Admin exists.
   - The standard **Sign In** screen opens with completely blank Mobile Number and Password fields—no quick-fill staff role buttons, no prefilled phone numbers, and no hardcoded demo passwords.
3. **Zero-State Portal Navigation**:
   - **Dashboard**: Displays `₹0.00` KPI cards in crisp tabular figures (`tabular-nums`), empty revenue chart/top-item panels with helpful prompts, and zero fake activity.
   - **Orders**: Shows an empty orders table and `₹0.00` period summary; creating a manual/phone order requires choosing an existing customer and available menu item and entering a real delivery address (no hardcoded Bengaluru fallback). If no customers or menu items exist yet, the modal clearly guides the admin to add them first.
   - **Catalogue**: Starts empty with a primary `"Add First Item"` action. Item images accept only validated server uploads (`/media/*`) or remain blank with a clean styled placeholder icon—no external stock URLs.
   - **Marketing & 4:5 Popup Campaigns**: Starts with blank fields and an upload dropzone for real 4:5 artwork. Saving persists the campaign in SQLite, lists active/inactive campaigns, and lets admins preview, toggle live status, or delete campaigns.
   - **Payments**: Displays real payment records only. When Razorpay keys are not yet configured in the server environment, a clear non-intrusive notice explains that live verification and refunds require `RAZORPAY_KEY_ID` and `RAZORPAY_KEY_SECRET`, and action attempts surface an explicit configuration error rather than faking success.
   - **Settings**: Loads blank outlet fields (Name, Support Phone, Address) and closed outlet status until the owner saves their real store profile.
   - **Riders, Customers, Reviews, Notifications, Staff**: All render clean, purposeful empty states (with Staff showing only the newly created Super Admin) and neutral field placeholders without fake names, phone numbers, or sample promo codes.

### Visual Identity & Theme

- **Aesthetic Direction**: Preserves the established Easy Admin high-clarity operational dashboard design—clean, utilitarian, mobile-ready, and focused on quick scanning of INR (`₹`) metrics and live kitchen workflows.
- **Color Palette & Mood**: High-contrast light canvas (`#F8FAFC` / `#FFFFFF` 60% neutral base), crisp `1px` hairline structural borders (`#E2E8F0` 30% surfaces), and Easy Admin crimson (`#E11D48` / `#BE123C` 10% accent) reserved for primary actions and active navigation. Semantic status indicators (green for active/paid, amber for pending/unconfigured warnings, crimson for alerts/errors) always pair color with explicit text labels.
- **Typography & Hierarchy**: Clean geometric sans-serif headings and body copy (`Plus Jakarta Sans`) paired with tabular numerals (`tabular-nums` / monospace) on every currency figure (`₹`), order number, timestamp, and payment ID to guarantee vertical alignment.
- **Component Styling & Layout**: Single-elevation flat cards with `1px` borders (no nested card sandwiches, no thick left accent borders, no decorative pulsing dots). Metadata rendered as clean inline text rather than cluttered pill stacks.
- **Interactive Feedback & Motion**: Fast (`<= 200ms`) compositor-only transitions for modal reveals, form validation feedback, loading skeletons matching table/card geometry, and actionable inline error banners when real external credentials are missing.

---

## 3. Key Product Decisions & Trade-Offs

- **Decision 1 — Atomic One-Time Super Admin Bootstrap vs. CLI Seeding**
  - *Chosen Approach*: Expose an unauthenticated setup-status check and a single-use bootstrap endpoint that commits the first `super_admin` inside a database transaction only if `COUNT(*) = 0`, immediately returning `403 Forbidden` on any subsequent call.
  - *Why*: Lets the owner onboard straight from the browser on first launch with zero default passwords while preventing unauthorized account takeover afterward.
  - *Alternatives Considered*: Requiring terminal commands or environment variables to create the first admin was passed over because it adds deployment friction for non-technical outlet owners.

- **Decision 2 — Persistent Database-Backed Popup Campaigns with Real Media Uploads**
  - *Chosen Approach*: Add a dedicated `popup_campaigns` SQLite table and authenticated image upload endpoint enforcing magic-byte validation (`JPEG/PNG/WebP/GIF`, 4 MB cap) so every 4:5 popup uses real hosted media (`/media/*`) and survives reloads.
  - *Why*: Replaces the prior local-only preview and `picsum.photos` stub with a genuine end-to-end campaign manager ready for the customer app to consume via `/popups/active`.
  - *Alternatives Considered*: Keeping local client state or base64 strings was rejected because data would vanish on refresh and bloat payloads.

- **Decision 3 — Strict Fail-Closed Payment Gateway Enforcement**
  - *Chosen Approach*: Return HTTP `503 Service Unavailable` with a clear configuration message if Razorpay keys are absent during `/verify` or `/refund`, and expose a boolean gateway-status flag on the Payments endpoint so the UI transparently informs the admin.
  - *Why*: Financial reconciliation and refunds must never silently fabricate success or fake `rfnd_*` IDs in production.
  - *Alternatives Considered*: Adding a sandbox/test toggle was ruled out per your strict real-only preference.

- **Decision 4 — Strict Media URL Validation on Catalogue & Popups**
  - *Chosen Approach*: Restrict stored `imageUrl` values strictly to server-generated `/media/<32-hex>.<ext>` paths (or `null`), rejecting arbitrary external domains.
  - *Why*: Eliminates broken third-party placeholder URLs and protects the admin panel from SSRF/tracking-pixel abuse.

---

## 4. Technical Architecture & Data Strategy *(Technical Reference)*

### Architecture & Component Diagram

```text
┌─────────────────────────────────────────────────────────────────────────┐
│                        Easy Admin Web Client                            │
├─────────────────────────────────────────────────────────────────────────┤
│  App Shell & Auth Gate                                                  │
│   ├─► Setup Check ──► [needsSetup: true]  ──► First-Time Super Admin UI │
│   │               ──► [needsSetup: false] ──► Clean Blank Login Screen  │
│   └─► Authenticated RBAC Workspace (Sidebar + Header + Route Views)     │
│        ├─ Dashboard (₹0.00 empty metrics & charts)                      │
│        ├─ Orders (real customer/item manual entry, CSV & date ranges)   │
│        ├─ Catalogue (validated /media/* uploads, zero stock URLs)       │
│        ├─ Marketing (Coupons + Persistent 4:5 Popup Campaign Manager)   │
│        ├─ Payments (strict Razorpay config banner & live actions)       │
│        └─ Riders · Customers · Reviews · Notifications · Staff · Config │
└───────────────────────────────┬─────────────────────────────────────────┘
                                │ HTTPS / JSON + httpOnly Refresh Cookie
                                ▼
┌─────────────────────────────────────────────────────────────────────────┐
│                     Express Security & API Server                       │
├─────────────────────────────────────────────────────────────────────────┤
│  Auth & Bootstrap Layer                                                 │
│   ├─ GET  /admin/auth/setup-status   (checks super_admin count === 0)   │
│   ├─ POST /admin/auth/setup          (atomic one-time owner creation)   │
│   └─ POST /admin/auth/login|refresh  (scrypt + signed JWT + cookies)    │
│                                                                         │
│  Domain & Media Routes (RBAC + CSRF + Rate Limits + Zod Validation)     │
│   ├─ /admin/catalogue & /admin/catalogue/image  (strict /media/* only)  │
│   ├─ /admin/popups    & /admin/popups/image     (CRUD + /popups/active) │
│   ├─ /admin/orders/manual                       (explicit real inputs)  │
│   ├─ /admin/settings                            (blank clean defaults)  │
│   └─ /admin/payments/:pid/verify|refund         (strict Razorpay API)   │
└──────────────┬───────────────────────────────────────┬──────────────────┘
               │                                       │
               ▼                                       ▼
┌──────────────────────────────┐        ┌─────────────────────────────────┐
│  Clean SQLite Database       │        │  External Services & Storage    │
│  (Zero Seeded Demo Data)     │        │   ├─ Local /uploads -> /media/* │
│   ├─ users · sessions        │        │   ├─ Razorpay REST API (strict) │
│   ├─ menu_items · orders     │        │   └─ FCM Push API (optional)    │
│   ├─ payments · reviews      │        └─────────────────────────────────┘
│   ├─ coupons · notifications │
│   ├─ popup_campaigns (NEW)   │
│   └─ settings · audit_log    │
└──────────────────────────────┘
```

### Data Model & State

- **Clean Initial Schema**: All existing operational tables (`users`, `sessions`, `menu_items`, `orders`, `payments`, `reviews`, `coupons`, `notifications`, `device_tokens`, `settings`, `audit_log`) are created empty with zero seed records.
- **New `popup_campaigns` Entity**: Stores `id`, `tag`, `title`, `description`, `button_text`, `image_url` (validated `/media/*` path), `active` flag, `created_by`, and `created_at` timestamp so 4:5 promotional popups are fully persisted and manageable.
- **Settings State**: Stored as key-value pairs in `settings` with empty strings for unconfigured restaurant metadata (`restaurantName`, `supportPhone`, `address`), `restaurantOpen = false`, `autoAcceptOrders = false`, and `orderSoundEnabled = true`.

### Interactive Component & State Mapping

- **Auth Gate & First-Time Setup Form**:
  - Fetches `GET /admin/auth/setup-status` on boot.
  - Validates full name, 10-digit Indian mobile number, matching strong password (`>= 10` characters), disables submit during request, displays server validation errors inline, and transitions cleanly into the authenticated workspace upon `201 Created`.
- **Blank Login Screen**:
  - Initializes `phone = ""` and `password = ""`. Removes all quick-fill buttons and hardcoded credentials. Handles lockout/rate-limit errors cleanly.
- **Manual Order Modal**:
  - Loads real customers and available menu items. Disables creation with a clear inline prompt if either list is empty. Requires explicit customer selection, at least one item, and a non-empty manually typed delivery address.
- **Popup Campaign Builder & Manager**:
  - Initializes all fields empty (no prefilled copy or stock photo). Uploading a 4:5 image posts to `/admin/popups/image`, receives a verified `/media/*` URL, updates the live 4:5 preview card (with corner close icon), and persists via `POST /admin/popups`. Campaign list supports live preview, active/inactive toggle (`PATCH`), and deletion (`DELETE`).
- **Payments Verification & Refund Actions**:
  - Reads `gatewayConfigured` from `GET /admin/payments`. Displays an informational warning banner when Razorpay keys are unset, and ensures verify/refund actions surface real HTTP `503` / gateway API errors clearly without mutating payment status falsely.
- **Input Placeholders & Empty States Sweep**:
  - Replaces example names, fake phone numbers, fake addresses, and sample promo codes across all forms with neutral descriptive labels, while ensuring every list/table/chart renders a crisp empty state on zero rows.

### Key Sequences & Integrations

1. **Database Reset Sequence**: Stop seeding at server startup, delete existing seeded SQLite files cleanly, and recreate the empty schema on boot.
2. **One-Time Setup Lockout**: `POST /admin/auth/setup` runs inside a SQLite immediate transaction checking `SELECT COUNT(*) FROM users WHERE role = 'super_admin'`. If `> 0`, it aborts with `403`, guaranteeing no second admin can ever be bootstrapped through the setup route.
3. **Strict Razorpay Verification/Refund**: Calls Razorpay's live REST API using Basic Auth (`RAZORPAY_KEY_ID:RAZORPAY_KEY_SECRET`). Missing env vars immediately fail closed with HTTP `503`; live API errors propagate cleanly to the UI and audit trail.
