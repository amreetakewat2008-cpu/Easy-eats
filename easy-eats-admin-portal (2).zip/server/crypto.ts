import crypto from "crypto";
import fs from "fs";
import path from "path";

// Persist dev fallback keys locally if env vars are not set so encrypted SQLite records remain readable across restarts.
function loadOrCreateDevSecrets(): { jwtSecret: string; dataKeyHex: string; webhookSecret: string } {
  const envJwt = process.env.JWT_SECRET && process.env.JWT_SECRET.length >= 32 ? process.env.JWT_SECRET : "";
  const envData = process.env.DATA_KEY_HEX && Buffer.from(process.env.DATA_KEY_HEX, "hex").length === 32 ? process.env.DATA_KEY_HEX : "";
  const envWebhook = process.env.PAYMENT_WEBHOOK_SECRET || "";

  if (envJwt && envData && envWebhook) {
    return { jwtSecret: envJwt, dataKeyHex: envData, webhookSecret: envWebhook };
  }

  const secretFile = path.resolve(process.cwd(), ".easyeats-dev-secrets.json");
  let persisted: Partial<{ jwtSecret: string; dataKeyHex: string; webhookSecret: string }> = {};
  try {
    if (fs.existsSync(secretFile)) {
      persisted = JSON.parse(fs.readFileSync(secretFile, "utf8"));
    }
  } catch {
    persisted = {};
  }

  const resolved = {
    jwtSecret: envJwt || persisted.jwtSecret || crypto.randomBytes(48).toString("base64url"),
    dataKeyHex: envData || persisted.dataKeyHex || crypto.randomBytes(32).toString("hex"),
    webhookSecret: envWebhook || persisted.webhookSecret || crypto.randomBytes(32).toString("hex"),
  };

  try {
    if (!fs.existsSync(secretFile)) {
      fs.writeFileSync(secretFile, JSON.stringify(resolved, null, 2), { mode: 0o600 });
    }
  } catch {
    // Non-fatal in read-only environments
  }

  return resolved;
}

const SECRETS = loadOrCreateDevSecrets();
export const JWT_SECRET = SECRETS.jwtSecret;
export const PAYMENT_WEBHOOK_SECRET = SECRETS.webhookSecret;

const DATA_KEY = Buffer.from(SECRETS.dataKeyHex, "hex");
const INDEX_KEY = Buffer.from(crypto.hkdfSync("sha256", DATA_KEY, Buffer.alloc(0), "blind-index", 32));

export function sha256(value: string): string {
  return crypto.createHash("sha256").update(value).digest("hex");
}

export function blindIndex(value: string): string {
  return crypto.createHmac("sha256", INDEX_KEY).update(value).digest("hex");
}

// AES-256-GCM: encrypts AND authenticates. Output = base64(iv | tag | ciphertext)
export function encrypt(plain: string): string {
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv("aes-256-gcm", DATA_KEY, iv);
  const enc = Buffer.concat([cipher.update(plain, "utf8"), cipher.final()]);
  return Buffer.concat([iv, cipher.getAuthTag(), enc]).toString("base64");
}

export function decrypt(b64: string): string {
  const buf = Buffer.from(b64, "base64");
  const decipher = crypto.createDecipheriv("aes-256-gcm", DATA_KEY, buf.subarray(0, 12));
  decipher.setAuthTag(buf.subarray(12, 28));
  return Buffer.concat([decipher.update(buf.subarray(28)), decipher.final()]).toString("utf8");
}

export function safeEqual(a: string, b: string): boolean {
  const x = Buffer.from(String(a));
  const y = Buffer.from(String(b));
  return x.length === y.length && crypto.timingSafeEqual(x, y);
}

// Password hashing using Node's native scrypt (constant-time comparison)
export function hashPassword(password: string): Promise<string> {
  return new Promise((resolve, reject) => {
    const salt = crypto.randomBytes(16).toString("hex");
    crypto.scrypt(password, salt, 64, (err, derivedKey) => {
      if (err) reject(err);
      else resolve(`scrypt:${salt}:${derivedKey.toString("hex")}`);
    });
  });
}

export function hashPasswordSync(password: string): string {
  const salt = crypto.randomBytes(16).toString("hex");
  const derivedKey = crypto.scryptSync(password, salt, 64);
  return `scrypt:${salt}:${derivedKey.toString("hex")}`;
}

export function verifyPassword(password: string, stored: string): Promise<boolean> {
  return new Promise((resolve) => {
    const parts = stored.split(":");
    if (parts.length !== 3 || parts[0] !== "scrypt") {
      resolve(false);
      return;
    }
    const [, salt, hashHex] = parts;
    crypto.scrypt(password, salt, 64, (err, derivedKey) => {
      if (err) {
        resolve(false);
        return;
      }
      const expected = Buffer.from(hashHex, "hex");
      resolve(expected.length === derivedKey.length && crypto.timingSafeEqual(expected, derivedKey));
    });
  });
}

// Minimal HS256 JWT implementation using Node crypto
function b64urlEncode(input: string | Buffer): string {
  return Buffer.from(input).toString("base64url");
}

export function signJwt(payload: Record<string, unknown>, expiresInSec = 900): string {
  const now = Math.floor(Date.now() / 1000);
  const header = b64urlEncode(JSON.stringify({ alg: "HS256", typ: "JWT" }));
  const body = b64urlEncode(JSON.stringify({ ...payload, iat: now, exp: now + expiresInSec }));
  const signature = crypto
    .createHmac("sha256", JWT_SECRET)
    .update(`${header}.${body}`)
    .digest("base64url");
  return `${header}.${body}.${signature}`;
}

export function verifyJwt(token: string): { sub: string; iat: number; exp: number } {
  const parts = token.split(".");
  if (parts.length !== 3) throw new Error("Malformed token");
  const [header, body, sig] = parts;
  const headerJson = JSON.parse(Buffer.from(header, "base64url").toString("utf8"));
  if (headerJson.alg !== "HS256") throw new Error("Unsupported alg");
  const expected = crypto
    .createHmac("sha256", JWT_SECRET)
    .update(`${header}.${body}`)
    .digest("base64url");
  if (!safeEqual(sig, expected)) throw new Error("Invalid signature");
  const claims = JSON.parse(Buffer.from(body, "base64url").toString("utf8"));
  if (!claims.exp || claims.exp < Math.floor(Date.now() / 1000)) {
    throw new Error("Token expired");
  }
  if (typeof claims.sub !== "string") throw new Error("Missing sub");
  return claims;
}
