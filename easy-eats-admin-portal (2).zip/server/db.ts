import Database from "better-sqlite3";

export const db = new Database("easyeats_secure.db");
db.pragma("journal_mode = WAL");
db.pragma("foreign_keys = ON");

db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id            TEXT PRIMARY KEY,
    name          TEXT NOT NULL,
    username      TEXT,
    phone_enc     TEXT NOT NULL,
    phone_hash    TEXT NOT NULL UNIQUE,
    password_hash TEXT NOT NULL,
    role          TEXT NOT NULL DEFAULT 'customer'
                  CHECK (role IN ('customer','rider','super_admin','restaurant_manager','marketing_lead','customer_support')),
    failed_logins INTEGER NOT NULL DEFAULT 0,
    locked_until  TEXT,
    is_blocked    INTEGER NOT NULL DEFAULT 0,
    is_online     INTEGER NOT NULL DEFAULT 0,
    last_seen_at  TEXT,
    created_at    TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
  );

  CREATE TABLE IF NOT EXISTS refresh_tokens (
    id         TEXT PRIMARY KEY,
    user_id    TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    token_hash TEXT NOT NULL UNIQUE,
    revoked    INTEGER NOT NULL DEFAULT 0,
    expires_at TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
  );

  CREATE TABLE IF NOT EXISTS menu_items (
    id                  TEXT PRIMARY KEY,
    name                TEXT NOT NULL,
    description         TEXT NOT NULL DEFAULT '',
    price_paise         INTEGER NOT NULL CHECK (price_paise > 0),
    selling_price_paise INTEGER NOT NULL CHECK (selling_price_paise > 0),
    is_available        INTEGER NOT NULL DEFAULT 1,
    image_url           TEXT,
    is_veg              INTEGER NOT NULL DEFAULT 1,
    category            TEXT NOT NULL DEFAULT 'Other',
    keywords            TEXT NOT NULL DEFAULT '[]',
    stock               INTEGER NOT NULL DEFAULT 50,
    updated_at          TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
  );

  CREATE TABLE IF NOT EXISTS coupons (
    code               TEXT PRIMARY KEY,
    discount_type      TEXT NOT NULL DEFAULT 'percentage' CHECK (discount_type IN ('percentage','fixed')),
    percent_off        INTEGER NOT NULL DEFAULT 10,
    max_discount_paise INTEGER NOT NULL DEFAULT 15000,
    min_order_paise    INTEGER NOT NULL DEFAULT 0,
    max_redemptions    INTEGER NOT NULL DEFAULT 100,
    redeemed_count     INTEGER NOT NULL DEFAULT 0,
    expires_at         TEXT NOT NULL,
    active             INTEGER NOT NULL DEFAULT 1
  );

  CREATE TABLE IF NOT EXISTS coupon_redemptions (
    code    TEXT NOT NULL REFERENCES coupons(code),
    user_id TEXT NOT NULL REFERENCES users(id),
    PRIMARY KEY (code, user_id)
  );

  CREATE TABLE IF NOT EXISTS orders (
    id              TEXT PRIMARY KEY,
    user_id         TEXT NOT NULL REFERENCES users(id),
    rider_id        TEXT REFERENCES users(id),
    idempotency_key TEXT NOT NULL,
    status          TEXT NOT NULL CHECK (status IN
                    ('pending_payment','under_review','placed','accepted','preparing',
                     'out_for_delivery','delivered','cancelled','failed')),
    payment_method  TEXT NOT NULL CHECK (payment_method IN ('online','cod')),
    paid            INTEGER NOT NULL DEFAULT 0,
    subtotal_paise  INTEGER NOT NULL CHECK (subtotal_paise > 0),
    discount_paise  INTEGER NOT NULL DEFAULT 0,
    delivery_paise  INTEGER NOT NULL DEFAULT 0,
    total_paise     INTEGER NOT NULL CHECK (total_paise > 0),
    coupon_code     TEXT,
    address_enc     TEXT NOT NULL,
    address_hash    TEXT NOT NULL,
    otp_enc         TEXT NOT NULL,
    otp_attempts    INTEGER NOT NULL DEFAULT 0,
    risk_score      INTEGER NOT NULL DEFAULT 0,
    risk_flags      TEXT NOT NULL DEFAULT '[]',
    placed_at       TEXT,
    reject_reason   TEXT,
    created_at      TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now')),
    UNIQUE (user_id, idempotency_key)
  );

  CREATE INDEX IF NOT EXISTS orders_user_created ON orders (user_id, created_at DESC);
  CREATE INDEX IF NOT EXISTS orders_address_hash ON orders (address_hash, created_at);

  CREATE TABLE IF NOT EXISTS order_items (
    order_id         TEXT NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
    menu_item_id     TEXT NOT NULL REFERENCES menu_items(id),
    name             TEXT NOT NULL,
    unit_price_paise INTEGER NOT NULL,
    qty              INTEGER NOT NULL CHECK (qty BETWEEN 1 AND 10),
    PRIMARY KEY (order_id, menu_item_id)
  );

  CREATE TABLE IF NOT EXISTS payments (
    provider_payment_id TEXT PRIMARY KEY,
    order_id            TEXT NOT NULL REFERENCES orders(id),
    amount_paise        INTEGER NOT NULL,
    refund_id           TEXT,
    refunded_at         TEXT,
    created_at          TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
  );

  CREATE TABLE IF NOT EXISTS reviews (
    id         TEXT PRIMARY KEY,
    order_id   TEXT NOT NULL UNIQUE REFERENCES orders(id),
    user_id    TEXT NOT NULL REFERENCES users(id),
    rating     INTEGER NOT NULL CHECK (rating BETWEEN 1 AND 5),
    comment    TEXT NOT NULL DEFAULT '',
    hidden     INTEGER NOT NULL DEFAULT 0,
    reply      TEXT,
    created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
  );

  CREATE TABLE IF NOT EXISTS device_tokens (
    token      TEXT PRIMARY KEY,
    user_id    TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    platform   TEXT NOT NULL,
    updated_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
  );

  CREATE TABLE IF NOT EXISTS push_subscriptions (
    endpoint TEXT PRIMARY KEY,
    user_id  TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    p256dh   TEXT NOT NULL,
    auth     TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS notifications (
    id         TEXT PRIMARY KEY,
    sent_by    TEXT REFERENCES users(id),
    audience   TEXT NOT NULL CHECK (audience IN ('all','one')),
    user_id    TEXT REFERENCES users(id),
    title      TEXT NOT NULL,
    body       TEXT NOT NULL,
    sent_count INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
  );

  CREATE TABLE IF NOT EXISTS popup_campaigns (
    id          TEXT PRIMARY KEY,
    tag         TEXT NOT NULL DEFAULT '',
    title       TEXT NOT NULL,
    description TEXT NOT NULL DEFAULT '',
    button_text TEXT NOT NULL DEFAULT '',
    image_url   TEXT NOT NULL,
    active      INTEGER NOT NULL DEFAULT 1,
    created_by  TEXT REFERENCES users(id),
    created_at  TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
  );

  CREATE TABLE IF NOT EXISTS audit_log (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id    TEXT,
    action     TEXT NOT NULL,
    detail     TEXT NOT NULL DEFAULT '{}',
    ip         TEXT,
    created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ', 'now'))
  );

  CREATE TABLE IF NOT EXISTS settings (
    key   TEXT PRIMARY KEY,
    value TEXT NOT NULL
  );
`);

const userCols = db.prepare("PRAGMA table_info(users)").all() as Array<{ name: string }>;
if (!userCols.some((c) => c.name === "username")) {
  db.exec("ALTER TABLE users ADD COLUMN username TEXT");
}
db.exec("CREATE UNIQUE INDEX IF NOT EXISTS users_username_nocase ON users (LOWER(username)) WHERE username IS NOT NULL");

