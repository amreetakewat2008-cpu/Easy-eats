import type { AuthUser } from "./types";

// Access token lives in memory only; refresh token stays in an httpOnly cookie.
let accessToken: string | null = null;
let onExpired: () => void = () => {};

export const onSessionExpired = (fn: () => void) => {
  onExpired = fn;
};

let refreshing: Promise<AuthUser | null> | null = null;

function refresh(): Promise<AuthUser | null> {
  if (!refreshing) {
    refreshing = fetch("/admin/auth/refresh", { method: "POST", credentials: "include" })
      .then(async (r) => {
        if (!r.ok) return null;
        const j = await r.json();
        accessToken = j.accessToken;
        return j.user as AuthUser;
      })
      .catch(() => null)
      .finally(() => {
        refreshing = null;
      });
  }
  return refreshing;
}

export const restoreSession = refresh;

export async function getSetupStatus(): Promise<{ needsSetup: boolean }> {
  const r = await fetch("/admin/auth/setup-status", { credentials: "include" });
  const j = await r.json().catch(() => ({ needsSetup: false }));
  if (!r.ok) return { needsSetup: false };
  return { needsSetup: Boolean(j.needsSetup) };
}

export async function setupSuperAdmin(name: string, phone: string, password: string): Promise<AuthUser> {
  const r = await fetch("/admin/auth/setup", {
    method: "POST",
    credentials: "include",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ name, phone, password }),
  });
  const j = await r.json().catch(() => ({}));
  if (!r.ok) {
    const msg = j?.fields?.length ? `${j.error}: ${j.fields.join(", ")}` : j.error || "Could not complete setup";
    throw new Error(msg);
  }
  accessToken = j.accessToken;
  return j.user as AuthUser;
}

export async function login(identifier: string, password: string): Promise<AuthUser> {
  const r = await fetch("/admin/auth/login", {
    method: "POST",
    credentials: "include",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ identifier, password }),
  });
  const j = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(j.error || "Could not sign in");
  accessToken = j.accessToken;
  return j.user as AuthUser;
}

export async function logout(): Promise<void> {
  await fetch("/admin/auth/logout", { method: "POST", credentials: "include" }).catch(() => {});
  accessToken = null;
}

export async function api<T = any>(
  path: string,
  opts: { method?: string; body?: unknown; form?: FormData } = {},
  retried = false
): Promise<T> {
  const { method = "GET", body, form } = opts;
  const headers: Record<string, string> = {};
  if (accessToken) headers.Authorization = `Bearer ${accessToken}`;
  if (body) headers["Content-Type"] = "application/json";

  const r = await fetch(path, {
    method,
    credentials: "include",
    headers,
    body: form ?? (body ? JSON.stringify(body) : undefined),
  });

  if (r.status === 401 && !retried) {
    if (await refresh()) return api<T>(path, opts, true);
    onExpired();
  }

  const data = r.status === 204 ? null : await r.json().catch(() => ({}));
  if (!r.ok) {
    const msg = data?.fields?.length ? `${data.error}: ${data.fields.join(", ")}` : data?.error || "Request failed";
    throw new Error(msg);
  }
  return data as T;
}

// Live Server-Sent Events stream (new_order, order_status). Auto-reconnects on recycle/drop.
export function openStream(onEvent: (event: string, data: any) => void): () => void {
  const ctrl = new AbortController();
  (async () => {
    let wait = 1000;
    while (!ctrl.signal.aborted) {
      try {
        const r = await fetch("/admin/stream", {
          credentials: "include",
          headers: accessToken ? { Authorization: `Bearer ${accessToken}` } : {},
          signal: ctrl.signal,
        });
        if (r.status === 401) {
          await refresh();
        } else if (r.ok && r.body) {
          wait = 1000;
          const reader = r.body.pipeThrough(new TextDecoderStream()).getReader();
          let buf = "";
          for (;;) {
            const { value, done } = await reader.read();
            if (done) break;
            buf += value;
            let idx: number;
            while ((idx = buf.indexOf("\n\n")) >= 0) {
              const chunk = buf.slice(0, idx);
              buf = buf.slice(idx + 2);
              const ev = /^event: (.*)$/m.exec(chunk)?.[1];
              const rawData = /^data: (.*)$/m.exec(chunk)?.[1];
              if (ev && rawData) {
                try {
                  onEvent(ev, JSON.parse(rawData));
                } catch {
                  // Ignore malformed event payload
                }
              }
            }
          }
        }
      } catch {
        if (ctrl.signal.aborted) return;
      }
      await new Promise((res) => setTimeout(res, wait));
      wait = Math.min(wait * 2, 15_000);
    }
  })();
  return () => ctrl.abort();
}
