import React, { useEffect, useState } from "react";
import { AlertTriangle, CheckCircle2, CreditCard, RefreshCw, RotateCcw } from "lucide-react";
import { api } from "../api";
import type { AdminPayment, PaymentsResponse } from "../types";
import { money, statusLabel, when } from "../utils";

export default function PaymentsPage() {
  const [payments, setPayments] = useState<AdminPayment[]>([]);
  const [gatewayConfigured, setGatewayConfigured] = useState<boolean>(true);
  const [loading, setLoading] = useState(true);
  const [err, setErr] = useState("");
  const [notes, setNotes] = useState<Record<string, { ok: boolean; text: string }>>({});
  const [busyId, setBusyId] = useState<string | null>(null);

  const load = () => {
    setLoading(true);
    api<PaymentsResponse>("/admin/payments")
      .then((res) => {
        setGatewayConfigured(res.gatewayConfigured);
        setPayments(res.payments);
        setLoading(false);
      })
      .catch((e: any) => {
        setErr(e?.message || "Failed to load payments");
        setLoading(false);
      });
  };

  useEffect(() => {
    load();
  }, []);

  const verify = async (id: string) => {
    setBusyId(id);
    setErr("");
    try {
      const r = await api<{ gatewayStatus: string; gatewayAmountPaise: number; matches: boolean }>(`/admin/payments/${id}/verify`, {
        method: "POST",
      });
      setNotes((prev) => ({
        ...prev,
        [id]: {
          ok: r.matches,
          text: r.matches
            ? `Verified: ${r.gatewayStatus}, ${money(r.gatewayAmountPaise)}`
            : `MISMATCH: gateway reports ${r.gatewayStatus}, ${money(r.gatewayAmountPaise)}`,
        },
      }));
    } catch (e: any) {
      setErr(e?.message || "Verification failed");
    } finally {
      setBusyId(null);
    }
  };

  const refund = async (p: AdminPayment) => {
    setBusyId(p.id);
    setErr("");
    try {
      const res = await api<{ refundId?: string }>(`/admin/payments/${p.id}/refund`, { method: "POST" });
      setNotes((prev) => ({
        ...prev,
        [p.id]: { ok: true, text: `Refund issued (${res.refundId || "completed"})` },
      }));
      load();
    } catch (e: any) {
      setErr(e?.message || "Refund failed");
    } finally {
      setBusyId(null);
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-xl font-bold text-zinc-900">Payments & Refunds</h3>
        <p className="text-xs text-zinc-500 mt-0.5">Super Admin only · Reconcile captured Razorpay payments and issue live idempotent refunds</p>
      </div>

      {!loading && !gatewayConfigured && (
        <div className="p-4 rounded-2xl bg-amber-50 border border-amber-200 text-amber-900 text-xs flex items-start gap-3">
          <AlertTriangle size={16} className="text-amber-600 flex-shrink-0 mt-0.5" />
          <div className="space-y-0.5">
            <p className="font-bold">Razorpay API keys not configured</p>
            <p className="text-amber-800">
              Set <code className="font-mono font-semibold">RAZORPAY_KEY_ID</code> and{" "}
              <code className="font-mono font-semibold">RAZORPAY_KEY_SECRET</code> in the server environment to enable live payment verification and refunds.
            </p>
          </div>
        </div>
      )}

      {err && <div className="p-4 rounded-2xl bg-rose-50 text-rose-700 text-xs font-semibold">{err}</div>}

      <div className="space-y-4">
        {loading ? (
          <div className="bg-white rounded-3xl p-10 text-center text-sm text-zinc-400">Loading payments...</div>
        ) : payments.length === 0 ? (
          <div className="bg-white rounded-3xl border border-black/5 p-12 text-center text-zinc-500">
            <CreditCard size={30} className="mx-auto text-zinc-300 mb-2" />
            <p className="text-sm font-medium text-zinc-700">No online payments recorded yet.</p>
            <p className="text-xs text-zinc-400 mt-1">Captured Razorpay webhook payments will appear here automatically.</p>
          </div>
        ) : (
          payments.map((p) => (
            <div key={p.id} className="bg-white p-5 rounded-3xl border border-black/5 shadow-sm space-y-3">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div className="flex items-center gap-3">
                  <span className="text-xl font-black text-zinc-900 tabular-nums">{money(p.amountPaise)}</span>
                  <div className="flex flex-wrap gap-1.5">
                    {p.refundedAt ? (
                      <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-zinc-100 text-zinc-600">Refunded</span>
                    ) : p.refundDue ? (
                      <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-rose-100 text-rose-700">Refund Due</span>
                    ) : (
                      <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-emerald-50 text-emerald-700">Captured</span>
                    )}
                    {p.mismatch && (
                      <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-rose-600 text-white">Amount Mismatch</span>
                    )}
                  </div>
                </div>
                <span className="text-xs text-zinc-400">{when(p.createdAt)}</span>
              </div>

              <p className="text-xs text-zinc-500 font-mono">
                {p.id} · Order #{p.orderId.slice(0, 8)} ({statusLabel(p.orderStatus)})
                {p.refundId && ` · Refund ${p.refundId}`}
              </p>

              {notes[p.id] && (
                <div
                  className={`flex items-center gap-2 px-3 py-2 rounded-xl text-xs font-semibold ${
                    notes[p.id].ok ? "bg-emerald-50 text-emerald-700" : "bg-rose-50 text-rose-700"
                  }`}
                >
                  <CheckCircle2 size={14} />
                  <span>{notes[p.id].text}</span>
                </div>
              )}

              <div className="flex flex-wrap gap-2 pt-1">
                <button
                  type="button"
                  disabled={busyId === p.id}
                  onClick={() => verify(p.id)}
                  className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-zinc-100 text-zinc-800 text-xs font-bold hover:bg-zinc-200 transition-all disabled:opacity-50"
                >
                  <RefreshCw size={13} />
                  Verify with Razorpay
                </button>
                {p.refundDue && (
                  <button
                    type="button"
                    disabled={busyId === p.id}
                    onClick={() => refund(p)}
                    className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-rose-600 text-white text-xs font-bold hover:bg-rose-700 transition-all disabled:opacity-50"
                  >
                    <RotateCcw size={13} />
                    Issue Refund ({money(p.amountPaise)})
                  </button>
                )}
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}
