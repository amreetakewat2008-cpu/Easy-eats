import React, { useEffect, useState } from "react";
import { Eye, EyeOff, MessageSquare, Star } from "lucide-react";
import { api } from "../api";
import type { AdminReview, ReviewsResponse } from "../types";
import { cn, when } from "../utils";

function ReviewCard({ review, onUpdated }: { review: AdminReview; onUpdated: () => void; key?: React.Key }) {
  const [reply, setReply] = useState("");
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");

  const patch = async (body: { hidden?: boolean; reply?: string }) => {
    setBusy(true);
    setErr("");
    try {
      await api(`/admin/reviews/${review.id}`, { method: "PATCH", body });
      if (body.reply) setReply("");
      onUpdated();
    } catch (e: any) {
      setErr(e?.message || "Update failed");
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className={cn("bg-white p-6 rounded-3xl border border-black/5 shadow-sm space-y-3", review.hidden && "opacity-70")}>
      <div className="flex items-start justify-between gap-3">
        <div>
          <div className="flex items-center gap-2">
            <h4 className="font-bold text-sm text-zinc-900">{review.customerName}</h4>
            {review.hidden && (
              <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-rose-100 text-rose-700">Hidden</span>
            )}
          </div>
          <p className="text-xs text-zinc-400 mt-0.5">
            {when(review.createdAt)} · Order #{review.orderId.slice(0, 8)}
          </p>
        </div>
        <span className="px-2.5 py-1 rounded-full bg-amber-50 text-amber-600 text-xs font-bold flex items-center gap-1">
          <Star size={12} fill="currentColor" /> {review.rating}.0
        </span>
      </div>

      {review.comment && <p className="text-sm text-zinc-700 leading-relaxed">"{review.comment}"</p>}

      {review.reply && (
        <div className="bg-zinc-50 rounded-2xl px-4 py-3 text-xs text-zinc-600">
          <span className="font-bold text-zinc-800 block mb-0.5">Restaurant reply</span>
          {review.reply}
        </div>
      )}

      <div className="flex flex-col sm:flex-row gap-2 pt-2 border-t border-black/5">
        <input
          type="text"
          maxLength={300}
          placeholder="Write a reply to this customer..."
          value={reply}
          onChange={(e) => setReply(e.target.value)}
          className="flex-1 bg-zinc-50 border border-black/5 rounded-xl px-3.5 py-2 text-xs outline-none focus:ring-2 focus:ring-red-500"
        />
        <div className="flex gap-2">
          <button
            disabled={busy || !reply.trim()}
            onClick={() => patch({ reply: reply.trim() })}
            className="px-4 py-2 rounded-xl bg-zinc-900 text-white text-xs font-bold hover:bg-black disabled:opacity-40"
          >
            Reply
          </button>
          <button
            disabled={busy}
            onClick={() => patch({ hidden: !review.hidden })}
            className="inline-flex items-center gap-1 px-3.5 py-2 rounded-xl bg-zinc-100 text-zinc-700 text-xs font-bold hover:bg-zinc-200"
          >
            {review.hidden ? <Eye size={13} /> : <EyeOff size={13} />}
            {review.hidden ? "Show" : "Hide"}
          </button>
        </div>
      </div>

      {err && <p className="text-xs font-semibold text-rose-600">{err}</p>}
    </div>
  );
}

export default function ReviewsPage() {
  const [data, setData] = useState<ReviewsResponse | null>(null);
  const [error, setError] = useState("");
  const [nonce, setNonce] = useState(0);

  useEffect(() => {
    api<ReviewsResponse>("/admin/reviews")
      .then(setData)
      .catch((e: any) => setError(e?.message || "Failed to load reviews"));
  }, [nonce]);

  return (
    <div className="space-y-6">
      <div className="bg-white p-6 rounded-3xl border border-black/5 shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <div className="w-14 h-14 rounded-2xl bg-amber-50 text-amber-500 flex items-center justify-center">
            <Star size={28} fill="currentColor" />
          </div>
          <div>
            <p className="text-3xl font-black text-zinc-900">{data ? data.summary.avg.toFixed(2) : "—"} ★</p>
            <p className="text-xs text-zinc-500">{data ? `${data.summary.count} visible customer reviews` : "Loading summary..."}</p>
          </div>
        </div>
        <p className="text-xs text-zinc-500 max-w-sm">
          Verified reviews from delivered orders. Replies appear to customers; hidden reviews are excluded from the public average.
        </p>
      </div>

      {error && <div className="p-4 rounded-2xl bg-rose-50 text-rose-700 text-xs font-semibold">{error}</div>}

      {data && data.reviews.length === 0 ? (
        <div className="bg-white rounded-3xl border border-black/5 p-12 text-center text-zinc-500">
          <MessageSquare size={30} className="mx-auto text-zinc-300 mb-2" />
          <p className="text-sm">No customer reviews yet.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
          {data?.reviews.map((r) => (
            <ReviewCard key={r.id} review={r} onUpdated={() => setNonce((n) => n + 1)} />
          ))}
        </div>
      )}
    </div>
  );
}
