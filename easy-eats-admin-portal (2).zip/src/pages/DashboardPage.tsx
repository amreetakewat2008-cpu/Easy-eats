import React, { useEffect, useState } from "react";
import {
  AlertCircle,
  Bike,
  Clock,
  CreditCard,
  ShoppingBag,
  TrendingDown,
  TrendingUp,
} from "lucide-react";
import {
  Bar,
  BarChart,
  CartesianGrid,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { api } from "../api";
import type { DashboardData } from "../types";
import { cn, money } from "../utils";

function pctChange(cur: number, prev: number): number | null {
  if (!prev) return null;
  return Math.round(((cur - prev) / prev) * 100);
}

export default function DashboardPage({ tick }: { tick: number }) {
  const [days, setDays] = useState(7);
  const [data, setData] = useState<DashboardData | null>(null);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let active = true;
    setLoading(true);
    setError("");
    api<DashboardData>(`/admin/dashboard?days=${days}`)
      .then((res) => {
        if (active) {
          setData(res);
          setLoading(false);
        }
      })
      .catch((e: any) => {
        if (active) {
          setError(e?.message || "Failed to load dashboard");
          setLoading(false);
        }
      });
    return () => {
      active = false;
    };
  }, [days, tick]);

  if (error) {
    return (
      <div className="bg-rose-50 border border-rose-200 text-rose-700 rounded-3xl p-6 text-sm font-medium">
        {error}
      </div>
    );
  }

  if (loading && !data) {
    return (
      <div className="py-16 flex items-center justify-center gap-3 text-zinc-500">
        <div className="w-6 h-6 border-2 border-red-200 border-t-red-600 rounded-full animate-spin" />
        <span className="text-sm font-medium">Loading analytics...</span>
      </div>
    );
  }

  if (!data) return null;

  const { current: c, previous: p, queue: q } = data;
  const orderDelta = pctChange(c.orders, p.orders);
  const revDelta = pctChange(c.revenue, p.revenue);
  const avgOrderPaise = c.delivered ? Math.round(c.revenue / c.delivered) : 0;
  const cancelRate = c.orders ? Math.round((c.cancelled / c.orders) * 100) : 0;

  const chartData = data.series.map((s) => ({
    day: s.day.slice(days > 14 ? 5 : 8),
    fullDay: s.day,
    revenueRs: Number((s.revenue / 100).toFixed(2)),
    orders: s.orders,
  }));

  return (
    <div className="space-y-6">
      {/* Header & Period Switcher */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h3 className="text-xl font-bold text-zinc-900">Performance Overview</h3>
          <p className="text-xs text-zinc-500 mt-0.5">Live metrics calculated from verified orders and payments</p>
        </div>
        <div className="flex items-center gap-2 bg-white p-1.5 rounded-2xl border border-black/5 shadow-sm w-fit">
          {[7, 30, 90].map((n) => (
            <button
              key={n}
              type="button"
              onClick={() => setDays(n)}
              className={cn(
                "px-3.5 py-1.5 rounded-xl text-xs font-semibold transition-all",
                days === n ? "bg-red-600 text-white shadow-sm" : "text-zinc-600 hover:bg-zinc-100"
              )}
            >
              Last {n} days
            </button>
          ))}
        </div>
      </div>

      {/* Primary KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-5 gap-4">
        <div className="bg-white p-5 rounded-3xl border border-black/5 shadow-sm">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-semibold text-zinc-500">Total Orders</span>
            <div className="w-8 h-8 rounded-xl bg-red-50 text-red-600 flex items-center justify-center">
              <ShoppingBag size={16} />
            </div>
          </div>
          <p className="text-2xl font-black text-zinc-900 tabular-nums">{c.orders}</p>
          {orderDelta !== null ? (
            <p className={cn("text-xs font-semibold mt-1.5 flex items-center gap-1 tabular-nums", orderDelta >= 0 ? "text-emerald-600" : "text-rose-600")}>
              {orderDelta >= 0 ? <TrendingUp size={13} /> : <TrendingDown size={13} />}
              {orderDelta >= 0 ? "+" : ""}
              {orderDelta}% vs prev period
            </p>
          ) : (
            <p className="text-xs text-zinc-400 mt-1.5">Last {days} days</p>
          )}
        </div>

        <div className="bg-white p-5 rounded-3xl border border-black/5 shadow-sm">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-semibold text-zinc-500">Delivered Revenue</span>
            <div className="w-8 h-8 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center">
              <TrendingUp size={16} />
            </div>
          </div>
          <p className="text-2xl font-black text-zinc-900 tabular-nums">{money(c.revenue)}</p>
          {revDelta !== null ? (
            <p className={cn("text-xs font-semibold mt-1.5 flex items-center gap-1 tabular-nums", revDelta >= 0 ? "text-emerald-600" : "text-rose-600")}>
              {revDelta >= 0 ? <TrendingUp size={13} /> : <TrendingDown size={13} />}
              {revDelta >= 0 ? "+" : ""}
              {revDelta}% vs prev period
            </p>
          ) : (
            <p className="text-xs text-zinc-400 mt-1.5 tabular-nums">{c.delivered} delivered</p>
          )}
        </div>

        <div className="bg-white p-5 rounded-3xl border border-black/5 shadow-sm">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-semibold text-zinc-500">Average Order</span>
            <div className="w-8 h-8 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center">
              <CreditCard size={16} />
            </div>
          </div>
          <p className="text-2xl font-black text-zinc-900 tabular-nums">{money(avgOrderPaise)}</p>
          <p className="text-xs text-zinc-400 mt-1.5">Across delivered orders</p>
        </div>

        <div className="bg-white p-5 rounded-3xl border border-black/5 shadow-sm">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-semibold text-zinc-500">Cancellation Rate</span>
            <div className="w-8 h-8 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center">
              <AlertCircle size={16} />
            </div>
          </div>
          <p className="text-2xl font-black text-zinc-900 tabular-nums">{cancelRate}%</p>
          <p className="text-xs text-zinc-400 mt-1.5 tabular-nums">{c.cancelled} cancelled</p>
        </div>

        <div className="bg-white p-5 rounded-3xl border border-black/5 shadow-sm">
          <div className="flex items-center justify-between mb-3">
            <span className="text-xs font-semibold text-zinc-500">Riders Online</span>
            <div className="w-8 h-8 rounded-xl bg-purple-50 text-purple-600 flex items-center justify-center">
              <Bike size={16} />
            </div>
          </div>
          <p className="text-2xl font-black text-zinc-900 tabular-nums">
            {data.riders.online} <span className="text-base font-semibold text-zinc-400">/ {data.riders.total}</span>
          </p>
          <p className="text-xs text-zinc-400 mt-1.5">Active fleet availability</p>
        </div>
      </div>

      {/* Live Operations Queue */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className={cn("p-4 rounded-2xl border flex items-center justify-between", q.awaiting > 0 ? "bg-amber-50 border-amber-200" : "bg-white border-black/5")}>
          <div>
            <p className="text-xs font-semibold text-zinc-500">Waiting to Accept</p>
            <p className="text-2xl font-black text-zinc-900 mt-0.5">{q.awaiting}</p>
          </div>
          <Clock size={20} className={q.awaiting > 0 ? "text-amber-600" : "text-zinc-300"} />
        </div>
        <div className={cn("p-4 rounded-2xl border flex items-center justify-between", q.review > 0 ? "bg-orange-50 border-orange-200" : "bg-white border-black/5")}>
          <div>
            <p className="text-xs font-semibold text-zinc-500">Needs Fraud Review</p>
            <p className="text-2xl font-black text-zinc-900 mt-0.5">{q.review}</p>
          </div>
          <AlertCircle size={20} className={q.review > 0 ? "text-orange-600" : "text-zinc-300"} />
        </div>
        <div className="bg-white p-4 rounded-2xl border border-black/5 flex items-center justify-between">
          <div>
            <p className="text-xs font-semibold text-zinc-500">In Progress</p>
            <p className="text-2xl font-black text-zinc-900 mt-0.5">{q.active}</p>
          </div>
          <ShoppingBag size={20} className="text-blue-500" />
        </div>
        <div className={cn("p-4 rounded-2xl border flex items-center justify-between", q.refundsDue > 0 ? "bg-rose-50 border-rose-200" : "bg-white border-black/5")}>
          <div>
            <p className="text-xs font-semibold text-zinc-500">Refunds Due</p>
            <p className="text-2xl font-black text-zinc-900 mt-0.5">{q.refundsDue}</p>
          </div>
          <CreditCard size={20} className={q.refundsDue > 0 ? "text-rose-600" : "text-zinc-300"} />
        </div>
      </div>

      {/* Revenue Chart + Top Selling Items */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 bg-white p-6 rounded-3xl border border-black/5 shadow-sm">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h4 className="font-bold text-zinc-900">Daily Revenue (₹)</h4>
              <p className="text-xs text-zinc-500">Delivered orders across the last {days} days</p>
            </div>
          </div>
          <div className="h-64 w-full">
            {c.orders === 0 && c.revenue === 0 ? (
              <div className="h-full flex flex-col items-center justify-center text-center text-zinc-400 bg-zinc-50/70 rounded-2xl border border-dashed border-zinc-200 px-4">
                <ShoppingBag size={28} className="text-zinc-300 mb-2" />
                <p className="text-sm font-semibold text-zinc-700">No revenue data yet</p>
                <p className="text-xs text-zinc-400 mt-0.5">Daily revenue bars will appear here as orders are delivered.</p>
              </div>
            ) : (
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={chartData}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f4f4f5" />
                  <XAxis dataKey="day" axisLine={false} tickLine={false} tick={{ fontSize: 11, fill: "#71717a" }} />
                  <YAxis axisLine={false} tickLine={false} tick={{ fontSize: 11, fill: "#71717a" }} tickFormatter={(v) => `₹${v}`} />
                  <Tooltip
                    cursor={{ fill: "#fafafa" }}
                    formatter={(value: any) => [`₹${Number(value).toLocaleString("en-IN")}`, "Revenue"]}
                    labelFormatter={(_, payload) => payload?.[0]?.payload?.fullDay || ""}
                    contentStyle={{ borderRadius: "14px", border: "1px solid #e4e4e7", fontSize: "12px" }}
                  />
                  <Bar dataKey="revenueRs" fill="#dc2626" radius={[8, 8, 0, 0]} maxBarSize={36} />
                </BarChart>
              </ResponsiveContainer>
            )}
          </div>
        </div>

        <div className="bg-white p-6 rounded-3xl border border-black/5 shadow-sm">
          <h4 className="font-bold text-zinc-900 mb-1">Top Selling Items</h4>
          <p className="text-xs text-zinc-500 mb-5">By quantity delivered in last {days} days</p>
          {data.top.length === 0 ? (
            <p className="text-sm text-zinc-400 py-8 text-center">No delivered orders in this period.</p>
          ) : (
            <div className="space-y-4">
              {data.top.map((item, idx) => (
                <div key={item.name} className="flex items-center justify-between gap-3">
                  <div className="flex items-center gap-3 min-w-0">
                    <span className="w-7 h-7 rounded-xl bg-red-50 text-red-600 font-bold text-xs flex items-center justify-center flex-shrink-0">
                      {idx + 1}
                    </span>
                    <div className="min-w-0">
                      <p className="text-sm font-semibold text-zinc-900 truncate">{item.name}</p>
                      <p className="text-xs text-zinc-500">{item.qty} sold</p>
                    </div>
                  </div>
                  <span className="text-sm font-bold text-zinc-900 flex-shrink-0">{money(item.revenue)}</span>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
