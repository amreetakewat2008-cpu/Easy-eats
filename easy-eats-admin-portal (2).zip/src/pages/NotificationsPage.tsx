import React, { useEffect, useState } from "react";
import { Bell, CheckCheck } from "lucide-react";
import { api } from "../api";
import type { NotificationItem } from "../types";
import { when } from "../utils";

export default function NotificationsPage() {
  const [items, setItems] = useState<NotificationItem[]>([]);
  const [readIds, setReadIds] = useState<Set<string>>(new Set());

  useEffect(() => {
    api<NotificationItem[]>("/admin/notifications").then(setItems).catch(() => {});
  }, []);

  const markAllRead = () => {
    setReadIds(new Set(items.map((i) => i.id)));
  };

  return (
    <div className="max-w-3xl mx-auto space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-xl font-bold text-zinc-900">Notifications & Broadcasts</h3>
          <p className="text-xs text-zinc-500 mt-0.5">Recent customer push broadcasts and operational alerts</p>
        </div>
        {items.length > 0 && (
          <button
            onClick={markAllRead}
            className="inline-flex items-center gap-1.5 text-xs font-bold text-red-600 hover:text-red-700"
          >
            <CheckCheck size={15} />
            Mark all read
          </button>
        )}
      </div>

      <div className="space-y-3">
        {items.length === 0 ? (
          <div className="bg-white rounded-3xl border border-black/5 p-12 text-center text-zinc-500">
            <Bell size={28} className="mx-auto text-zinc-300 mb-2" />
            <p className="text-sm">No notifications recorded yet.</p>
          </div>
        ) : (
          items.map((n) => {
            const isRead = readIds.has(n.id);
            return (
              <div
                key={n.id}
                onClick={() => setReadIds((prev) => new Set(prev).add(n.id))}
                className={`p-5 rounded-3xl border transition-all cursor-pointer ${
                  isRead ? "bg-zinc-50 border-transparent" : "bg-white border-red-100 shadow-sm"
                }`}
              >
                <div className="flex items-start gap-4">
                  <div
                    className={`w-10 h-10 rounded-full flex items-center justify-center flex-shrink-0 ${
                      isRead ? "bg-zinc-200 text-zinc-500" : "bg-red-50 text-red-600"
                    }`}
                  >
                    <Bell size={18} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between gap-2">
                      <h4 className="font-bold text-sm text-zinc-900">{n.title}</h4>
                      <span className="text-[11px] text-zinc-400 whitespace-nowrap">{when(n.createdAt)}</span>
                    </div>
                    <p className="text-sm text-zinc-600 mt-1">{n.body}</p>
                    <p className="text-[11px] text-zinc-400 mt-2">
                      Audience: {n.audience === "all" ? "All customers" : "Single customer"} · {n.sentCount} device(s)
                    </p>
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
}
