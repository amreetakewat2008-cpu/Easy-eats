import React, { useEffect, useState } from "react";
import { Bike, Phone } from "lucide-react";
import { api } from "../api";
import type { AdminRider } from "../types";
import { cn } from "../utils";

export default function RidersPage({ tick }: { tick: number }) {
  const [riders, setRiders] = useState<AdminRider[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    let active = true;
    api<AdminRider[]>("/admin/riders")
      .then((res) => {
        if (active) {
          setRiders(res);
          setLoading(false);
        }
      })
      .catch((e: any) => {
        if (active) {
          setError(e?.message || "Failed to load riders");
          setLoading(false);
        }
      });
    return () => {
      active = false;
    };
  }, [tick]);

  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-xl font-bold text-zinc-900">Delivery Fleet</h3>
        <p className="text-xs text-zinc-500 mt-0.5">Live rider availability from heartbeat signals · Add new riders in Staff</p>
      </div>

      {error && <div className="p-4 rounded-2xl bg-rose-50 text-rose-700 text-xs font-semibold">{error}</div>}

      {loading ? (
        <div className="py-12 text-center text-sm text-zinc-400">Loading riders...</div>
      ) : riders.length === 0 ? (
        <div className="bg-white rounded-3xl border border-black/5 p-12 text-center text-zinc-500">
          <Bike size={34} className="mx-auto text-zinc-300 mb-2" />
          <p className="text-sm">No riders yet. Add rider accounts from the Staff page.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
          {riders.map((r) => (
            <div key={r.id} className="bg-white p-6 rounded-3xl border border-black/5 shadow-sm space-y-4">
              <div className="flex items-start justify-between gap-3">
                <div className="flex items-center gap-3">
                  <div
                    className={cn(
                      "w-11 h-11 rounded-2xl flex items-center justify-center",
                      r.blocked ? "bg-rose-50 text-rose-600" : r.online ? "bg-emerald-50 text-emerald-600" : "bg-zinc-100 text-zinc-500"
                    )}
                  >
                    <Bike size={20} />
                  </div>
                  <div>
                    <h4 className="font-bold text-zinc-900">{r.name}</h4>
                    <p className="text-xs text-zinc-500 flex items-center gap-1 mt-0.5">
                      <Phone size={11} /> {r.phone}
                    </p>
                  </div>
                </div>
                <span
                  className={cn(
                    "px-2.5 py-1 rounded-full text-[11px] font-bold",
                    r.blocked
                      ? "bg-rose-50 text-rose-600"
                      : r.online
                        ? "bg-emerald-50 text-emerald-600"
                        : "bg-zinc-100 text-zinc-500"
                  )}
                >
                  {r.blocked ? "Blocked" : r.online ? "Online" : "Offline"}
                </span>
              </div>

              <div className="grid grid-cols-2 gap-3 pt-2 border-t border-black/5">
                <div className="bg-zinc-50 rounded-2xl p-3">
                  <p className="text-[11px] text-zinc-500 font-medium">Active Deliveries</p>
                  <p className="text-xl font-black text-zinc-900 mt-0.5">{r.active}</p>
                </div>
                <div className="bg-zinc-50 rounded-2xl p-3">
                  <p className="text-[11px] text-zinc-500 font-medium">Total Delivered</p>
                  <p className="text-xl font-black text-zinc-900 mt-0.5">{r.delivered}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
