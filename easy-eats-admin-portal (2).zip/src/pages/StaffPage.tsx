import React, { useEffect, useState } from "react";
import { ShieldCheck, UserPlus } from "lucide-react";
import { api } from "../api";
import type { AuditLogEntry, AuthUser, StaffMember, UserRole } from "../types";
import { ALL_ROLE_LABEL, cn, when } from "../utils";

const CREATABLE_ROLES: [UserRole, string][] = [
  ["restaurant_manager", "Restaurant Manager"],
  ["marketing_lead", "Marketing Lead"],
  ["customer_support", "Customer Support"],
  ["super_admin", "Super Admin"],
  ["rider", "Rider"],
];

export default function StaffPage({ me }: { me: AuthUser }) {
  const [staff, setStaff] = useState<StaffMember[]>([]);
  const [auditLogs, setAuditLogs] = useState<AuditLogEntry[]>([]);
  const [form, setForm] = useState({ name: "", phone: "", password: "", role: "restaurant_manager" as UserRole });
  const [err, setErr] = useState("");
  const [okMsg, setOkMsg] = useState("");
  const [busy, setBusy] = useState(false);

  const load = () => {
    api<StaffMember[]>("/admin/staff").then(setStaff).catch((e: any) => setErr(e?.message || "Failed to load staff"));
    api<AuditLogEntry[]>("/admin/audit").then(setAuditLogs).catch(() => {});
  };

  useEffect(() => {
    load();
  }, []);

  const addAccount = async (e: React.FormEvent) => {
    e.preventDefault();
    setBusy(true);
    setErr("");
    setOkMsg("");
    try {
      await api("/admin/staff", { method: "POST", body: form });
      setOkMsg(`Account created for ${form.name}.`);
      setForm({ name: "", phone: "", password: "", role: form.role });
      load();
    } catch (x: any) {
      setErr(x?.message || "Could not create account");
    } finally {
      setBusy(false);
    }
  };

  const toggleBlock = async (u: StaffMember) => {
    setErr("");
    try {
      await api(`/admin/users/${u.id}/block`, { method: "PATCH", body: { blocked: !u.blocked } });
      load();
    } catch (x: any) {
      setErr(x?.message || "Failed to update account");
    }
  };

  return (
    <div className="space-y-8">
      <div>
        <h3 className="text-xl font-bold text-zinc-900">Staff, Riders & Security Audit</h3>
        <p className="text-xs text-zinc-500 mt-0.5">Super Admin only · Roles are verified fresh from the database on every API request</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Create Account Form */}
        <div className="bg-white p-6 rounded-3xl border border-black/5 shadow-sm h-fit">
          <div className="flex items-center gap-2 mb-4">
            <UserPlus size={18} className="text-red-600" />
            <h4 className="font-bold text-zinc-900">Create Staff / Rider Account</h4>
          </div>
          <form onSubmit={addAccount} className="space-y-3">
            <div>
              <label className="text-xs font-bold uppercase text-zinc-500 block mb-1">Full Name</label>
              <input
                required
                minLength={2}
                placeholder="Enter full name"
                value={form.name}
                onChange={(e) => setForm({ ...form, name: e.target.value })}
                className="w-full bg-zinc-50 border border-black/5 rounded-xl px-3.5 py-2.5 text-sm outline-none focus:ring-2 focus:ring-red-500"
              />
            </div>
            <div>
              <label className="text-xs font-bold uppercase text-zinc-500 block mb-1">10-Digit Mobile</label>
              <input
                required
                inputMode="numeric"
                maxLength={10}
                placeholder="10-digit mobile number"
                value={form.phone}
                onChange={(e) => setForm({ ...form, phone: e.target.value.replace(/\D/g, "") })}
                className="w-full bg-zinc-50 border border-black/5 rounded-xl px-3.5 py-2.5 text-sm outline-none focus:ring-2 focus:ring-red-500 tabular-nums"
              />
            </div>
            <div>
              <label className="text-xs font-bold uppercase text-zinc-500 block mb-1">Temporary Password (10+ chars)</label>
              <input
                required
                type="password"
                minLength={10}
                autoComplete="new-password"
                placeholder="Minimum 10 characters"
                value={form.password}
                onChange={(e) => setForm({ ...form, password: e.target.value })}
                className="w-full bg-zinc-50 border border-black/5 rounded-xl px-3.5 py-2.5 text-sm outline-none focus:ring-2 focus:ring-red-500"
              />
            </div>
            <div>
              <label className="text-xs font-bold uppercase text-zinc-500 block mb-1">Role</label>
              <select
                value={form.role}
                onChange={(e) => setForm({ ...form, role: e.target.value as UserRole })}
                className="w-full bg-zinc-50 border border-black/5 rounded-xl px-3.5 py-2.5 text-sm outline-none focus:ring-2 focus:ring-red-500"
              >
                {CREATABLE_ROLES.map(([val, lbl]) => (
                  <option key={val} value={val}>
                    {lbl}
                  </option>
                ))}
              </select>
            </div>
            {err && <p className="text-xs font-semibold text-rose-600">{err}</p>}
            {okMsg && <p className="text-xs font-semibold text-emerald-600">{okMsg}</p>}
            <button
              type="submit"
              disabled={busy}
              className="w-full py-3 rounded-xl bg-red-600 text-white font-bold text-sm hover:bg-red-700 disabled:opacity-50"
            >
              {busy ? "Creating..." : "Create Account"}
            </button>
          </form>
        </div>

        {/* Staff Directory */}
        <div className="lg:col-span-2 bg-white rounded-3xl border border-black/5 shadow-sm overflow-hidden">
          <div className="p-5 border-b border-black/5 flex items-center justify-between">
            <h4 className="font-bold text-zinc-900">Active Accounts ({staff.length})</h4>
          </div>
          <div className="divide-y divide-black/5">
            {staff.map((u) => (
              <div key={u.id} className="px-5 py-4 flex items-center justify-between gap-4">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-sm text-zinc-900">{u.name}</span>
                    {u.id === me.id && (
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-red-50 text-red-600">You</span>
                    )}
                    {u.blocked && (
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-rose-100 text-rose-700">Blocked</span>
                    )}
                  </div>
                  <p className="text-xs text-zinc-500 mt-0.5">
                    {u.phone} · <span className="font-semibold text-zinc-700">{ALL_ROLE_LABEL[u.role] || u.role}</span>
                  </p>
                </div>
                {u.id !== me.id && (
                  <button
                    onClick={() => toggleBlock(u)}
                    className={cn(
                      "px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all",
                      u.blocked
                        ? "bg-emerald-50 text-emerald-700 hover:bg-emerald-100"
                        : "bg-zinc-100 text-zinc-700 hover:bg-rose-50 hover:text-rose-600"
                    )}
                  >
                    {u.blocked ? "Unblock" : "Block"}
                  </button>
                )}
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Audit Log */}
      <div className="bg-white rounded-3xl border border-black/5 shadow-sm overflow-hidden">
        <div className="p-5 border-b border-black/5 flex items-center gap-2">
          <ShieldCheck size={18} className="text-red-600" />
          <h4 className="font-bold text-zinc-900">Recent Security Audit Trail</h4>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left min-w-[640px]">
            <thead>
              <tr className="bg-zinc-50/70 text-zinc-500 text-xs uppercase">
                <th className="px-5 py-3 font-semibold">Event</th>
                <th className="px-5 py-3 font-semibold">Actor</th>
                <th className="px-5 py-3 font-semibold">Details</th>
                <th className="px-5 py-3 font-semibold">Timestamp</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-black/5 text-xs">
              {auditLogs.length === 0 ? (
                <tr>
                  <td colSpan={4} className="px-5 py-8 text-center text-zinc-400">
                    No audit events recorded yet.
                  </td>
                </tr>
              ) : (
                auditLogs.map((log) => (
                  <tr key={log.id} className="hover:bg-zinc-50/50">
                    <td className="px-5 py-3 font-mono font-bold text-zinc-800">{log.action}</td>
                    <td className="px-5 py-3 text-zinc-600">
                      {log.actorName ? `${log.actorName} (${log.actorRole})` : "System"}
                    </td>
                    <td className="px-5 py-3 font-mono text-zinc-500 max-w-xs truncate">
                      {Object.keys(log.detail || {}).length > 0 ? JSON.stringify(log.detail) : "—"}
                    </td>
                    <td className="px-5 py-3 text-zinc-400 tabular-nums">{when(log.createdAt)}</td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
