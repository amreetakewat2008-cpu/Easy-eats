import React, { useEffect, useState } from "react";
import { ShieldAlert, Search, Users, X } from "lucide-react";
import { api } from "../api";
import type { AdminCustomer, CustomerDetail, OrderStatus } from "../types";
import { STATUS_BADGE, cn, money, statusLabel, when } from "../utils";

function CustomerDetailModal({
  id,
  onClose,
  onChanged,
}: {
  id: string;
  onClose: () => void;
  onChanged: () => void;
}) {
  const [customer, setCustomer] = useState<CustomerDetail | null>(null);
  const [err, setErr] = useState("");
  const [busy, setBusy] = useState(false);

  const load = () => {
    api<CustomerDetail>(`/admin/customers/${id}`)
      .then(setCustomer)
      .catch((e: any) => setErr(e?.message || "Failed to load customer"));
  };

  useEffect(() => {
    load();
  }, [id]);

  const toggleBlock = async () => {
    if (!customer) return;
    setBusy(true);
    setErr("");
    try {
      await api(`/admin/users/${id}/block`, { method: "PATCH", body: { blocked: !customer.blocked } });
      load();
      onChanged();
    } catch (e: any) {
      setErr(e?.message || "Could not update user status");
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm" onClick={onClose}>
      <div
        className="bg-white rounded-3xl w-full max-w-lg max-h-[90vh] overflow-y-auto shadow-2xl p-6 space-y-5"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between">
          <h3 className="text-lg font-bold text-zinc-900">Customer Profile</h3>
          <button onClick={onClose} className="p-2 rounded-xl text-zinc-400 hover:bg-zinc-100">
            <X size={18} />
          </button>
        </div>

        {err && <div className="p-3 rounded-xl bg-rose-50 text-rose-700 text-xs font-semibold">{err}</div>}

        {!customer ? (
          <div className="py-10 text-center text-sm text-zinc-400">Loading customer details...</div>
        ) : (
          <div className="space-y-4">
            <div className="flex items-start justify-between gap-4 bg-zinc-50 rounded-2xl p-4">
              <div>
                <div className="flex items-center gap-2">
                  <h4 className="font-bold text-zinc-900">{customer.name}</h4>
                  {customer.blocked && (
                    <span className="px-2 py-0.5 rounded-full text-[11px] font-bold bg-rose-100 text-rose-700">Blocked</span>
                  )}
                </div>
                <p className="text-sm font-semibold text-zinc-700 mt-1">{customer.phone}</p>
                <p className="text-xs text-zinc-400 mt-0.5">Joined {when(customer.joinedAt)}</p>
              </div>
              <button
                disabled={busy}
                onClick={toggleBlock}
                className={cn(
                  "px-4 py-2 rounded-xl text-xs font-bold transition-all",
                  customer.blocked
                    ? "bg-emerald-600 text-white hover:bg-emerald-700"
                    : "bg-rose-600 text-white hover:bg-rose-700"
                )}
              >
                {customer.blocked ? "Unblock" : "Block Customer"}
              </button>
            </div>

            <div>
              <h5 className="text-xs font-bold uppercase tracking-wider text-zinc-400 mb-2">Recent Orders</h5>
              {customer.orders.length === 0 ? (
                <p className="text-xs text-zinc-400 py-4 text-center">No orders yet.</p>
              ) : (
                <div className="divide-y divide-black/5 border border-black/5 rounded-2xl overflow-hidden">
                  {customer.orders.map((o) => (
                    <div key={o.id} className="flex items-center justify-between px-4 py-3 text-xs bg-white">
                      <div>
                        <span className="font-bold text-zinc-800">#{o.id.slice(0, 8)}</span>
                        <span className="text-zinc-400 ml-2">{when(o.createdAt)}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-zinc-900">{money(o.totalPaise)}</span>
                        <span className={cn("px-2 py-0.5 rounded-full font-semibold capitalize", STATUS_BADGE[o.status as OrderStatus])}>
                          {statusLabel(o.status)}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            <div className="flex items-center gap-2 text-[11px] text-zinc-500 bg-zinc-50 px-3.5 py-2.5 rounded-xl">
              <ShieldAlert size={14} className="text-zinc-400 flex-shrink-0" />
              <span>Opening this screen decrypts the mobile number and is recorded in the audit log.</span>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

export default function CustomersPage() {
  const [customers, setCustomers] = useState<AdminCustomer[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [text, setText] = useState("");
  const [q, setQ] = useState("");
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [nonce, setNonce] = useState(0);

  useEffect(() => {
    let active = true;
    setLoading(true);
    api<AdminCustomer[]>(`/admin/customers?q=${encodeURIComponent(q)}`)
      .then((res) => {
        if (active) {
          setCustomers(res);
          setLoading(false);
        }
      })
      .catch((e: any) => {
        if (active) {
          setError(e?.message || "Failed to load customers");
          setLoading(false);
        }
      });
    return () => {
      active = false;
    };
  }, [q, nonce]);

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h3 className="text-xl font-bold text-zinc-900">Customers</h3>
          <p className="text-xs text-zinc-500 mt-0.5">Phone numbers are masked in lists · Full view is audit-logged</p>
        </div>
        <form
          onSubmit={(e) => {
            e.preventDefault();
            setQ(text.trim());
          }}
          className="flex gap-2 w-full sm:w-auto"
        >
          <div className="relative flex-1 sm:w-64">
            <Search size={15} className="absolute left-3.5 top-1/2 -translate-y-1/2 text-zinc-400" />
            <input
              type="text"
              placeholder="Name or 10-digit mobile..."
              value={text}
              onChange={(e) => setText(e.target.value)}
              className="w-full pl-10 pr-3 py-2 bg-white border border-black/5 rounded-2xl text-sm shadow-sm outline-none focus:ring-2 focus:ring-red-500"
            />
          </div>
          <button type="submit" className="px-4 py-2 rounded-2xl bg-zinc-900 text-white text-xs font-bold hover:bg-black">
            Search
          </button>
        </form>
      </div>

      {error && <div className="p-4 rounded-2xl bg-rose-50 text-rose-700 text-xs font-semibold">{error}</div>}

      <div className="bg-white rounded-3xl border border-black/5 shadow-sm overflow-hidden">
        <div className="divide-y divide-black/5">
          {loading ? (
            <div className="p-10 text-center text-sm text-zinc-400">Loading customers...</div>
          ) : customers.length === 0 ? (
            <div className="p-12 text-center text-zinc-500">
              <Users size={30} className="mx-auto text-zinc-300 mb-2" />
              <p className="text-sm">No customers found.</p>
            </div>
          ) : (
            customers.map((c) => (
              <button
                key={c.id}
                onClick={() => setSelectedId(c.id)}
                className="w-full px-6 py-4 flex items-center justify-between gap-4 hover:bg-zinc-50 transition-all text-left"
              >
                <div className="flex items-center gap-3.5 min-w-0">
                  <div className="w-10 h-10 rounded-full bg-red-50 text-red-600 font-bold text-sm flex items-center justify-center flex-shrink-0">
                    {c.name[0]}
                  </div>
                  <div className="min-w-0">
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-sm text-zinc-900 truncate">{c.name}</span>
                      {c.blocked && (
                        <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-rose-100 text-rose-700">Blocked</span>
                      )}
                    </div>
                    <p className="text-xs text-zinc-500 font-mono mt-0.5">{c.phone}</p>
                  </div>
                </div>
                <div className="text-right flex-shrink-0">
                  <p className="text-sm font-bold text-zinc-900">{money(c.spentPaise)}</p>
                  <p className="text-xs text-zinc-400">{c.orders} orders</p>
                </div>
              </button>
            ))
          )}
        </div>
      </div>

      {selectedId && (
        <CustomerDetailModal
          id={selectedId}
          onClose={() => setSelectedId(null)}
          onChanged={() => setNonce((n) => n + 1)}
        />
      )}
    </div>
  );
}
