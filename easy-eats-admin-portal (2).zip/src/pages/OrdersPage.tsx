import React, { useEffect, useState } from "react";
import {
  AlertTriangle,
  Calendar,
  ChevronDown,
  ChevronRight,
  Download,
  PhoneCall,
  Plus,
  Search,
  ShoppingBag,
  X,
} from "lucide-react";
import { AnimatePresence, motion } from "motion/react";
import { api } from "../api";
import type { AdminOrder, CatalogueItem, OrderDetail, OrderStatus } from "../types";
import { STATUS_BADGE, cn, money, statusLabel, when } from "../utils";

type DateRangePreset = "all" | "today" | "last_7_days" | "this_month" | "last_month" | "custom";

const STATUS_TABS: [string, string][] = [
  ["", "All"],
  ["placed", "New"],
  ["under_review", "Review"],
  ["accepted", "Accepted"],
  ["preparing", "Preparing"],
  ["out_for_delivery", "On the way"],
  ["delivered", "Delivered"],
  ["cancelled", "Cancelled"],
];

const PRESETS: { id: DateRangePreset; label: string }[] = [
  { id: "all", label: "All Time" },
  { id: "today", label: "Today" },
  { id: "last_7_days", label: "Last 7 Days" },
  { id: "this_month", label: "This Month" },
  { id: "last_month", label: "Last Month" },
  { id: "custom", label: "Custom Range" },
];

function toLocalDateInput(date: Date): string {
  const y = date.getFullYear();
  const m = String(date.getMonth() + 1).padStart(2, "0");
  const d = String(date.getDate()).padStart(2, "0");
  return `${y}-${m}-${d}`;
}

function formatShortDate(dateStr: string): string {
  const [y, m, d] = dateStr.split("-").map(Number);
  if (!y || !m || !d) return dateStr;
  return new Date(y, m - 1, d).toLocaleDateString("en-IN", { day: "numeric", month: "short", year: "numeric" });
}

function getDateRangeBounds(preset: DateRangePreset, customStart: string, customEnd: string) {
  const now = new Date();
  const endOfToday = new Date(now.getFullYear(), now.getMonth(), now.getDate(), 23, 59, 59, 999);

  if (preset === "all") return { startISO: undefined, endISO: undefined, label: "All Time" };
  if (preset === "today") {
    const start = new Date(now.getFullYear(), now.getMonth(), now.getDate(), 0, 0, 0, 0);
    return { startISO: start.toISOString(), endISO: endOfToday.toISOString(), label: "Today" };
  }
  if (preset === "last_7_days") {
    const start = new Date(now.getFullYear(), now.getMonth(), now.getDate() - 6, 0, 0, 0, 0);
    return { startISO: start.toISOString(), endISO: endOfToday.toISOString(), label: "Last 7 Days" };
  }
  if (preset === "this_month") {
    const start = new Date(now.getFullYear(), now.getMonth(), 1, 0, 0, 0, 0);
    return { startISO: start.toISOString(), endISO: endOfToday.toISOString(), label: "This Month" };
  }
  if (preset === "last_month") {
    const start = new Date(now.getFullYear(), now.getMonth() - 1, 1, 0, 0, 0, 0);
    const end = new Date(now.getFullYear(), now.getMonth(), 0, 23, 59, 59, 999);
    return { startISO: start.toISOString(), endISO: end.toISOString(), label: "Last Month" };
  }

  let s = customStart;
  let e = customEnd;
  if (s && e && s > e) [s, e] = [e, s];

  let startISO: string | undefined;
  let endISO: string | undefined;
  if (s) {
    const [sy, sm, sd] = s.split("-").map(Number);
    startISO = new Date(sy, sm - 1, sd, 0, 0, 0, 0).toISOString();
  }
  if (e) {
    const [ey, em, ed] = e.split("-").map(Number);
    endISO = new Date(ey, em - 1, ed, 23, 59, 59, 999).toISOString();
  }
  const label =
    s && e ? `${formatShortDate(s)} – ${formatShortDate(e)}` : s ? `From ${formatShortDate(s)}` : e ? `Until ${formatShortDate(e)}` : "Custom Range";
  return { startISO, endISO, label };
}

function OrderDetailModal({
  id,
  canAct,
  onClose,
  onChanged,
}: {
  id: string;
  canAct: boolean;
  onClose: () => void;
  onChanged: () => void;
}) {
  const [order, setOrder] = useState<OrderDetail | null>(null);
  const [err, setErr] = useState("");
  const [busy, setBusy] = useState(false);
  const [reason, setReason] = useState("");
  const [otp, setOtp] = useState("");

  const load = () => {
    api<OrderDetail>(`/admin/orders/${id}`)
      .then(setOrder)
      .catch((e: any) => setErr(e?.message || "Failed to load order"));
  };

  useEffect(() => {
    load();
  }, [id]);

  const run = async (fn: () => Promise<unknown>) => {
    setBusy(true);
    setErr("");
    try {
      await fn();
      load();
      onChanged();
    } catch (e: any) {
      setErr(e?.message || "Action failed");
    } finally {
      setBusy(false);
    }
  };

  const canReject = order && ["placed", "under_review", "accepted"].includes(order.status);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm" onClick={onClose}>
      <div
        className="bg-white rounded-3xl w-full max-w-lg max-h-[90vh] overflow-y-auto shadow-2xl p-6 space-y-5"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center justify-between">
          <h3 className="text-lg font-bold text-zinc-900">Order #{id.slice(0, 8)}</h3>
          <button onClick={onClose} className="p-2 rounded-xl text-zinc-400 hover:bg-zinc-100 hover:text-zinc-900">
            <X size={18} />
          </button>
        </div>

        {err && <div className="p-3 rounded-xl bg-rose-50 text-rose-700 text-xs font-semibold">{err}</div>}

        {!order ? (
          <div className="py-10 text-center text-sm text-zinc-400">Loading order details...</div>
        ) : (
          <div className="space-y-4">
            <div className="flex flex-wrap items-center gap-2">
              <span className={cn("px-3 py-1 rounded-full text-xs font-bold capitalize", STATUS_BADGE[order.status])}>
                {statusLabel(order.status)}
              </span>
              <span className="text-xs font-medium text-zinc-500">
                {order.paymentMethod === "cod" ? "Cash on delivery" : order.paid ? "Paid online" : "Awaiting payment"}
              </span>
              <span className="text-xs text-zinc-400">· {when(order.createdAt)}</span>
            </div>

            <div className="bg-zinc-50 rounded-2xl p-4 space-y-1">
              <p className="font-bold text-sm text-zinc-900">{order.customerName}</p>
              <p className="text-xs text-zinc-600">{order.address}</p>
              {order.riderName && <p className="text-xs text-zinc-500 pt-1">Rider: <span className="font-semibold text-zinc-800">{order.riderName}</span></p>}
            </div>

            <div className="space-y-2">
              <p className="text-xs font-bold uppercase tracking-wider text-zinc-400">Items</p>
              <div className="divide-y divide-black/5 border border-black/5 rounded-2xl overflow-hidden">
                {order.items.map((item, idx) => (
                  <div key={`${item.name}-${idx}`} className="flex items-center justify-between px-4 py-3 text-sm bg-white">
                    <span className="font-medium text-zinc-800">
                      {item.qty} × {item.name}
                    </span>
                    <span className="font-semibold text-zinc-900">{money(item.unitPricePaise * item.qty)}</span>
                  </div>
                ))}
              </div>
              <div className="text-xs text-zinc-500 flex flex-wrap gap-x-4 gap-y-1 pt-1">
                <span>Subtotal {money(order.subtotalPaise)}</span>
                <span>Discount -{money(order.discountPaise)}</span>
                <span>Delivery {money(order.deliveryPaise)}</span>
              </div>
              <p className="text-2xl font-black text-zinc-900">{money(order.totalPaise)}</p>
            </div>

            {order.riskFlags.length > 0 && (
              <div className="p-3.5 rounded-2xl bg-amber-50 border border-amber-200 text-amber-800 text-xs font-semibold flex items-start gap-2">
                <AlertTriangle size={16} className="flex-shrink-0 mt-0.5" />
                <div>
                  Risk flags: {order.riskFlags.join(", ")} (score {order.riskScore})
                </div>
              </div>
            )}

            {order.rejectReason && (
              <p className="text-xs text-rose-600 bg-rose-50 px-3 py-2 rounded-xl font-medium">
                Rejection reason: {order.rejectReason}
              </p>
            )}

            {canAct && (
              <div className="space-y-3 pt-2 border-t border-black/5">
                {order.status === "placed" && (
                  <button
                    disabled={busy}
                    onClick={() => run(() => api(`/orders/${id}/status`, { method: "PATCH", body: { to: "accepted" } }))}
                    className="w-full py-3 rounded-xl bg-emerald-600 text-white font-bold text-sm hover:bg-emerald-700 transition-all"
                  >
                    Accept Order
                  </button>
                )}
                {order.status === "under_review" && (
                  <button
                    disabled={busy}
                    onClick={() => run(() => api(`/admin/orders/${id}/review`, { method: "POST", body: { approve: true } }))}
                    className="w-full py-3 rounded-xl bg-emerald-600 text-white font-bold text-sm hover:bg-emerald-700 transition-all"
                  >
                    Approve Risky Order
                  </button>
                )}
                {order.status === "accepted" && (
                  <button
                    disabled={busy}
                    onClick={() => run(() => api(`/orders/${id}/status`, { method: "PATCH", body: { to: "preparing" } }))}
                    className="w-full py-3 rounded-xl bg-blue-600 text-white font-bold text-sm hover:bg-blue-700 transition-all"
                  >
                    Start Preparing (Notifies Online Riders)
                  </button>
                )}
                {order.status === "preparing" && (
                  <button
                    disabled={busy}
                    onClick={() => run(() => api(`/orders/${id}/status`, { method: "PATCH", body: { to: "out_for_delivery" } }))}
                    className="w-full py-3 rounded-xl bg-purple-600 text-white font-bold text-sm hover:bg-purple-700 transition-all"
                  >
                    Dispatch Out for Delivery
                  </button>
                )}
                {order.status === "out_for_delivery" && (
                  <div className="flex gap-2">
                    <input
                      type="text"
                      inputMode="numeric"
                      maxLength={4}
                      placeholder="4-digit customer OTP"
                      value={otp}
                      onChange={(e) => setOtp(e.target.value.replace(/\D/g, ""))}
                      className="flex-1 bg-zinc-50 border border-black/10 rounded-xl px-3.5 py-2.5 text-sm outline-none focus:ring-2 focus:ring-red-500"
                    />
                    <button
                      disabled={busy || otp.length !== 4}
                      onClick={() => run(() => api(`/orders/${id}/deliver`, { method: "POST", body: { otp } }))}
                      className="px-4 py-2.5 rounded-xl bg-emerald-600 text-white font-bold text-sm hover:bg-emerald-700 disabled:opacity-50"
                    >
                      Verify & Deliver
                    </button>
                  </div>
                )}
                {canReject && (
                  <div className="flex gap-2">
                    <input
                      type="text"
                      placeholder="Reason for rejecting (min 3 chars)"
                      value={reason}
                      onChange={(e) => setReason(e.target.value)}
                      className="flex-1 bg-zinc-50 border border-black/10 rounded-xl px-3.5 py-2.5 text-sm outline-none focus:ring-2 focus:ring-red-500"
                    />
                    <button
                      disabled={busy || reason.trim().length < 3}
                      onClick={() => run(() => api(`/admin/orders/${id}/reject`, { method: "POST", body: { reason } }))}
                      className="px-4 py-2.5 rounded-xl bg-rose-600 text-white font-bold text-sm hover:bg-rose-700 disabled:opacity-50"
                    >
                      Reject
                    </button>
                  </div>
                )}
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}

function PhoneOrderModal({ onClose, onCreated }: { onClose: () => void; onCreated: () => void }) {
  const [customers, setCustomers] = useState<{ id: string; name: string }[]>([]);
  const [items, setItems] = useState<CatalogueItem[]>([]);
  const [customerId, setCustomerId] = useState("");
  const [menuItemId, setMenuItemId] = useState("");
  const [qty, setQty] = useState(1);
  const [address, setAddress] = useState("");
  const [loadingData, setLoadingData] = useState(true);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");

  useEffect(() => {
    Promise.all([
      api<{ id: string; name: string }[]>("/admin/orders/customers"),
      api<CatalogueItem[]>("/admin/catalogue"),
    ])
      .then(([custList, itemList]) => {
        const available = itemList.filter((i) => i.isAvailable);
        setCustomers(custList);
        setItems(available);
        if (custList[0]) setCustomerId(custList[0].id);
        if (available[0]) setMenuItemId(available[0].id);
      })
      .catch((e: any) => setErr(e?.message || "Failed to load customers or menu items"))
      .finally(() => setLoadingData(false));
  }, []);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setBusy(true);
    setErr("");
    try {
      await api("/admin/orders/manual", {
        method: "POST",
        body: { customerId, menuItemId, qty, address },
      });
      onCreated();
      onClose();
    } catch (x: any) {
      setErr(x?.message || "Could not place order");
    } finally {
      setBusy(false);
    }
  };

  const missingPrereqs = !loadingData && (customers.length === 0 || items.length === 0);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm" onClick={onClose}>
      <form
        onSubmit={submit}
        onClick={(e) => e.stopPropagation()}
        className="bg-white rounded-3xl w-full max-w-md shadow-2xl p-6 space-y-4"
      >
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <PhoneCall size={18} className="text-red-600" />
            <h3 className="text-lg font-bold">New Phone Order (COD)</h3>
          </div>
          <button type="button" onClick={onClose} className="p-1.5 rounded-xl text-zinc-400 hover:bg-zinc-100">
            <X size={18} />
          </button>
        </div>
        <p className="text-xs text-zinc-500">
          Places a Cash on Delivery order into the kitchen queue for a registered customer.
        </p>

        {loadingData ? (
          <div className="py-8 text-center text-xs text-zinc-400">Loading customers and menu items...</div>
        ) : missingPrereqs ? (
          <div className="p-4 rounded-2xl bg-amber-50 border border-amber-200 text-amber-900 text-xs space-y-1.5">
            <p className="font-bold">Required data missing</p>
            {customers.length === 0 && <p>No registered customers exist yet. Customers appear once they sign up.</p>}
            {items.length === 0 && <p>No available menu items exist yet. Add items in the Catalogue section first.</p>}
          </div>
        ) : (
          <div className="space-y-3">
            <div>
              <label className="text-xs font-bold uppercase text-zinc-500 block mb-1">Customer</label>
              <select
                value={customerId}
                onChange={(e) => setCustomerId(e.target.value)}
                className="w-full bg-zinc-50 border border-black/10 rounded-xl px-3.5 py-2.5 text-sm outline-none focus:ring-2 focus:ring-red-500"
                required
              >
                {customers.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.name}
                  </option>
                ))}
              </select>
            </div>
            <div className="grid grid-cols-3 gap-3">
              <div className="col-span-2">
                <label className="text-xs font-bold uppercase text-zinc-500 block mb-1">Menu Item</label>
                <select
                  value={menuItemId}
                  onChange={(e) => setMenuItemId(e.target.value)}
                  className="w-full bg-zinc-50 border border-black/10 rounded-xl px-3.5 py-2.5 text-sm outline-none focus:ring-2 focus:ring-red-500"
                  required
                >
                  {items.map((item) => (
                    <option key={item.id} value={item.id}>
                      {item.name} ({money(item.sellingPricePaise)})
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="text-xs font-bold uppercase text-zinc-500 block mb-1">Quantity</label>
                <input
                  type="number"
                  min={1}
                  max={10}
                  value={qty}
                  onChange={(e) => setQty(Number(e.target.value))}
                  className="w-full bg-zinc-50 border border-black/10 rounded-xl px-3.5 py-2.5 text-sm outline-none focus:ring-2 focus:ring-red-500 tabular-nums"
                />
              </div>
            </div>
            <div>
              <label className="text-xs font-bold uppercase text-zinc-500 block mb-1">Delivery Address</label>
              <textarea
                rows={2}
                placeholder="Enter full delivery address (min 10 characters)"
                value={address}
                onChange={(e) => setAddress(e.target.value)}
                minLength={10}
                required
                className="w-full bg-zinc-50 border border-black/10 rounded-xl px-3.5 py-2.5 text-sm outline-none focus:ring-2 focus:ring-red-500 resize-none"
              />
            </div>
          </div>
        )}

        {err && <p className="text-xs font-semibold text-rose-600">{err}</p>}
        <button
          type="submit"
          disabled={busy || loadingData || missingPrereqs || !customerId || !menuItemId}
          className="w-full py-3 rounded-xl bg-red-600 text-white font-bold text-sm hover:bg-red-700 disabled:opacity-50"
        >
          {busy ? "Placing Order..." : "Place COD Order"}
        </button>
      </form>
    </div>
  );
}

export default function OrdersPage({ tick, canAct }: { tick: number; canAct: boolean }) {
  const [orders, setOrders] = useState<AdminOrder[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [status, setStatus] = useState<string>("");
  const [searchInput, setSearchInput] = useState("");
  const [search, setSearch] = useState("");
  const [datePreset, setDatePreset] = useState<DateRangePreset>("all");
  const [customStart, setCustomStart] = useState(() => {
    const d = new Date();
    d.setDate(d.getDate() - 6);
    return toLocalDateInput(d);
  });
  const [customEnd, setCustomEnd] = useState(() => toLocalDateInput(new Date()));
  const [showDatePicker, setShowDatePicker] = useState(false);
  const [selectedOrderId, setSelectedOrderId] = useState<string | null>(null);
  const [showPhoneModal, setShowPhoneModal] = useState(false);
  const [reloadNonce, setReloadNonce] = useState(0);

  const rangeBounds = getDateRangeBounds(datePreset, customStart, customEnd);

  useEffect(() => {
    let active = true;
    setLoading(true);
    setError("");
    const params = new URLSearchParams();
    if (status) params.set("status", status);
    if (search) params.set("q", search);
    if (rangeBounds.startISO) params.set("startDate", rangeBounds.startISO);
    if (rangeBounds.endISO) params.set("endDate", rangeBounds.endISO);

    api<AdminOrder[]>(`/admin/orders?${params.toString()}`)
      .then((list) => {
        if (active) {
          setOrders(list);
          setLoading(false);
        }
      })
      .catch((e: any) => {
        if (active) {
          setError(e?.message || "Failed to load orders");
          setLoading(false);
        }
      });

    return () => {
      active = false;
    };
  }, [status, search, datePreset, customStart, customEnd, tick, reloadNonce]);

  const deliveredOrders = orders.filter((o) => o.status === "delivered");
  const activeOrders = orders.filter((o) => o.status !== "cancelled" && o.status !== "failed");
  const periodRevenuePaise = deliveredOrders.reduce((s, o) => s + o.totalPaise, 0);
  const avgOrderPaise = activeOrders.length
    ? Math.round(activeOrders.reduce((s, o) => s + o.totalPaise, 0) / activeOrders.length)
    : 0;
  const completionRate = orders.length ? Math.round((deliveredOrders.length / orders.length) * 100) : 0;

  const handleExportCsv = () => {
    const esc = (v: string | number) => `"${String(v).replace(/"/g, '""')}"`;
    const csv = [
      ["Order ID", "Customer", "Rider", "Payment", "Total (INR)", "Status", "Date & Time"],
      ...orders.map((o) => [
        o.id.slice(0, 8),
        o.customerName,
        o.riderName || "Unassigned",
        o.paymentMethod.toUpperCase(),
        (o.totalPaise / 100).toFixed(2),
        statusLabel(o.status),
        when(o.createdAt),
      ]),
    ]
      .map((r) => r.map(esc).join(","))
      .join("\n");
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    const slug = datePreset === "custom" ? `${customStart}-to-${customEnd}` : datePreset;
    a.download = `orders-${slug}-${toLocalDateInput(new Date())}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-6">
      {/* Period Report Summary Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white p-5 rounded-3xl border border-black/5 shadow-sm">
          <p className="text-xs font-semibold text-zinc-500">Orders ({rangeBounds.label})</p>
          <p className="text-2xl font-black mt-1 text-zinc-900 tabular-nums">{orders.length}</p>
          <p className="text-xs text-zinc-400 mt-1 tabular-nums">{activeOrders.length} active · {orders.length - activeOrders.length} cancelled</p>
        </div>
        <div className="bg-white p-5 rounded-3xl border border-black/5 shadow-sm">
          <p className="text-xs font-semibold text-zinc-500">Delivered Revenue</p>
          <p className="text-2xl font-black mt-1 text-red-600 tabular-nums">{money(periodRevenuePaise)}</p>
          <p className="text-xs text-zinc-400 mt-1 tabular-nums">{deliveredOrders.length} delivered orders</p>
        </div>
        <div className="bg-white p-5 rounded-3xl border border-black/5 shadow-sm">
          <p className="text-xs font-semibold text-zinc-500">Avg. Order Value</p>
          <p className="text-2xl font-black mt-1 text-zinc-900 tabular-nums">{money(avgOrderPaise)}</p>
          <p className="text-xs text-zinc-400 mt-1">Excludes cancelled</p>
        </div>
        <div className="bg-white p-5 rounded-3xl border border-black/5 shadow-sm">
          <p className="text-xs font-semibold text-zinc-500">Completion Rate</p>
          <p className="text-2xl font-black mt-1 text-zinc-900 tabular-nums">{completionRate}%</p>
          <p className="text-xs text-zinc-400 mt-1 tabular-nums">{deliveredOrders.length} of {orders.length} fulfilled</p>
        </div>
      </div>

      {/* Main Orders Card */}
      <div className="bg-white rounded-3xl border border-black/5 shadow-sm">
        <div className="p-4 md:p-6 border-b border-black/5 space-y-4">
          <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
            <div>
              <h3 className="text-lg font-bold text-zinc-900">Orders & Live Queue</h3>
              <p className="text-xs text-zinc-500 mt-0.5">
                Showing {orders.length} orders for <span className="font-semibold text-zinc-700">{rangeBounds.label}</span>
              </p>
            </div>
            <div className="flex flex-wrap items-center gap-2">
              {canAct && (
                <button
                  type="button"
                  onClick={() => setShowPhoneModal(true)}
                  className="flex items-center gap-1.5 px-4 py-2 text-xs font-bold bg-red-600 text-white rounded-full hover:bg-red-700 transition-all shadow-sm"
                >
                  <Plus size={14} />
                  Phone Order
                </button>
              )}

              {/* Date Range Dropdown */}
              <div className="relative">
                {showDatePicker && <div className="fixed inset-0 z-20" onClick={() => setShowDatePicker(false)} />}
                <button
                  type="button"
                  onClick={() => setShowDatePicker(!showDatePicker)}
                  className={cn(
                    "relative z-20 flex items-center gap-2 px-4 py-2 text-xs font-semibold rounded-full transition-all border",
                    datePreset !== "all"
                      ? "bg-red-50 text-red-600 border-red-200 hover:bg-red-100"
                      : "bg-zinc-100 text-zinc-700 border-transparent hover:bg-zinc-200"
                  )}
                >
                  <Calendar size={14} />
                  <span>{rangeBounds.label}</span>
                  <ChevronDown size={13} className={cn("transition-transform", showDatePicker && "rotate-180")} />
                </button>

                <AnimatePresence>
                  {showDatePicker && (
                    <motion.div
                      initial={{ opacity: 0, y: 8 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: 8 }}
                      className="absolute left-0 sm:left-auto sm:right-0 top-full mt-2 w-72 sm:w-80 bg-white rounded-2xl shadow-xl border border-black/10 p-4 z-30 space-y-4"
                    >
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-bold uppercase tracking-wider text-zinc-400">Select Period</span>
                        {datePreset !== "all" && (
                          <button
                            type="button"
                            onClick={() => {
                              setDatePreset("all");
                              setShowDatePicker(false);
                            }}
                            className="text-xs font-semibold text-red-600 hover:text-red-700"
                          >
                            Reset
                          </button>
                        )}
                      </div>
                      <div className="grid grid-cols-2 gap-2">
                        {PRESETS.map((p) => (
                          <button
                            key={p.id}
                            type="button"
                            onClick={() => {
                              setDatePreset(p.id);
                              if (p.id !== "custom") setShowDatePicker(false);
                            }}
                            className={cn(
                              "px-3 py-2 rounded-xl text-xs font-semibold text-left transition-all",
                              datePreset === p.id ? "bg-red-600 text-white" : "bg-zinc-50 text-zinc-700 hover:bg-zinc-100"
                            )}
                          >
                            {p.label}
                          </button>
                        ))}
                      </div>
                      <div className="pt-3 border-t border-black/5 space-y-3">
                        <span className="text-xs font-bold uppercase tracking-wider text-zinc-400 block">Custom Range</span>
                        <div className="grid grid-cols-2 gap-2">
                          <div>
                            <label className="text-[11px] font-medium text-zinc-500">From</label>
                            <input
                              type="date"
                              value={customStart}
                              max={customEnd || undefined}
                              onChange={(e) => {
                                setCustomStart(e.target.value);
                                setDatePreset("custom");
                              }}
                              className="w-full bg-zinc-50 border border-black/5 rounded-xl px-2.5 py-2 text-xs outline-none focus:ring-2 focus:ring-red-500"
                            />
                          </div>
                          <div>
                            <label className="text-[11px] font-medium text-zinc-500">To</label>
                            <input
                              type="date"
                              value={customEnd}
                              min={customStart || undefined}
                              onChange={(e) => {
                                setCustomEnd(e.target.value);
                                setDatePreset("custom");
                              }}
                              className="w-full bg-zinc-50 border border-black/5 rounded-xl px-2.5 py-2 text-xs outline-none focus:ring-2 focus:ring-red-500"
                            />
                          </div>
                        </div>
                        <button
                          type="button"
                          onClick={() => {
                            setDatePreset("custom");
                            setShowDatePicker(false);
                          }}
                          className="w-full bg-zinc-900 text-white py-2 rounded-xl text-xs font-bold hover:bg-black"
                        >
                          Apply Range
                        </button>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>

              <button
                type="button"
                onClick={handleExportCsv}
                className="flex items-center gap-1.5 px-4 py-2 text-xs font-semibold bg-zinc-100 text-zinc-700 rounded-full hover:bg-zinc-200 transition-all"
              >
                <Download size={14} />
                Export CSV
              </button>
            </div>
          </div>

          {/* Quick-Access Date Presets + Search */}
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
            <div className="flex flex-wrap items-center gap-1.5">
              {PRESETS.map((p) => (
                <button
                  key={p.id}
                  type="button"
                  onClick={() => setDatePreset(p.id)}
                  className={cn(
                    "px-3 py-1.5 rounded-xl text-xs font-semibold transition-all",
                    datePreset === p.id ? "bg-zinc-900 text-white" : "bg-zinc-100 text-zinc-600 hover:bg-zinc-200"
                  )}
                >
                  {p.label}
                </button>
              ))}
              {datePreset === "custom" && (
                <div className="flex items-center gap-1.5 ml-1">
                  <input
                    type="date"
                    value={customStart}
                    max={customEnd || undefined}
                    onChange={(e) => setCustomStart(e.target.value)}
                    className="bg-zinc-50 border border-black/10 rounded-xl px-2.5 py-1 text-xs outline-none focus:ring-2 focus:ring-red-500"
                  />
                  <span className="text-xs text-zinc-400">to</span>
                  <input
                    type="date"
                    value={customEnd}
                    min={customStart || undefined}
                    onChange={(e) => setCustomEnd(e.target.value)}
                    className="bg-zinc-50 border border-black/10 rounded-xl px-2.5 py-1 text-xs outline-none focus:ring-2 focus:ring-red-500"
                  />
                </div>
              )}
            </div>

            <form
              onSubmit={(e) => {
                e.preventDefault();
                setSearch(searchInput.trim());
              }}
              className="flex items-center gap-2"
            >
              <div className="relative flex-1 md:w-56">
                <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-zinc-400" />
                <input
                  type="text"
                  placeholder="Customer or order ID..."
                  value={searchInput}
                  onChange={(e) => setSearchInput(e.target.value)}
                  className="w-full pl-9 pr-3 py-1.5 bg-zinc-100 rounded-xl text-xs outline-none focus:ring-2 focus:ring-red-500"
                />
              </div>
              <button
                type="submit"
                className="px-3.5 py-1.5 rounded-xl bg-zinc-900 text-white text-xs font-semibold hover:bg-black"
              >
                Search
              </button>
            </form>
          </div>

          {/* Status Tabs */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-hide">
            {STATUS_TABS.map(([val, lbl]) => (
              <button
                key={val}
                type="button"
                onClick={() => setStatus(val)}
                className={cn(
                  "px-3.5 py-1.5 rounded-full text-xs font-semibold whitespace-nowrap transition-all",
                  status === val ? "bg-red-600 text-white shadow-sm" : "bg-zinc-50 text-zinc-600 hover:bg-zinc-100"
                )}
              >
                {lbl}
              </button>
            ))}
          </div>
        </div>

        {error && <div className="p-4 text-xs font-semibold text-rose-600 bg-rose-50">{error}</div>}

        <div className="overflow-x-auto">
          <table className="w-full text-left min-w-[760px]">
            <thead>
              <tr className="bg-zinc-50/70 text-zinc-500 text-xs uppercase tracking-wider">
                <th className="px-6 py-3.5 font-semibold">Order</th>
                <th className="px-6 py-3.5 font-semibold">Customer</th>
                <th className="px-6 py-3.5 font-semibold">Payment</th>
                <th className="px-6 py-3.5 font-semibold">Total</th>
                <th className="px-6 py-3.5 font-semibold">Status</th>
                <th className="px-6 py-3.5 font-semibold">Date & Time</th>
                <th className="px-6 py-3.5 font-semibold text-right">Details</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-black/5">
              {loading && (
                <tr>
                  <td colSpan={7} className="px-6 py-12 text-center text-sm text-zinc-400">
                    Loading orders...
                  </td>
                </tr>
              )}
              {!loading && orders.length === 0 && (
                <tr>
                  <td colSpan={7} className="px-6 py-12 text-center text-zinc-500">
                    <ShoppingBag size={30} className="mx-auto text-zinc-300 mb-2" />
                    <p className="text-sm font-medium text-zinc-700">No orders found for {rangeBounds.label}.</p>
                    {(datePreset !== "all" || status || search) && (
                      <button
                        type="button"
                        onClick={() => {
                          setDatePreset("all");
                          setStatus("");
                          setSearch("");
                          setSearchInput("");
                        }}
                        className="mt-2 text-xs font-semibold text-red-600 hover:text-red-700"
                      >
                        Reset all filters
                      </button>
                    )}
                  </td>
                </tr>
              )}
              {!loading &&
                orders.map((o) => (
                  <tr
                    key={o.id}
                    onClick={() => setSelectedOrderId(o.id)}
                    className="hover:bg-zinc-50/80 transition-all cursor-pointer group"
                  >
                    <td className="px-6 py-4">
                      <div className="text-sm font-bold text-zinc-900">#{o.id.slice(0, 8)}</div>
                      {o.riskFlags.length > 0 && (
                        <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-amber-700 mt-0.5">
                          <AlertTriangle size={11} /> {o.riskFlags.join(", ")}
                        </span>
                      )}
                    </td>
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-2.5">
                        <div className="w-8 h-8 rounded-full bg-zinc-100 text-zinc-700 text-xs font-bold flex items-center justify-center">
                          {o.customerName?.[0] || "C"}
                        </div>
                        <div>
                          <p className="text-sm font-semibold text-zinc-900">{o.customerName}</p>
                          {o.riderName && <p className="text-[11px] text-zinc-400">Rider: {o.riderName}</p>}
                        </div>
                      </div>
                    </td>
                    <td className="px-6 py-4 text-xs font-medium text-zinc-600">
                      {o.paymentMethod === "cod" ? "COD" : o.paid ? "Online · Paid" : "Online · Unpaid"}
                    </td>
                    <td className="px-6 py-4 text-sm font-bold text-zinc-900">{money(o.totalPaise)}</td>
                    <td className="px-6 py-4">
                      <span className={cn("inline-block px-3 py-1 rounded-full text-xs font-semibold capitalize", STATUS_BADGE[o.status as OrderStatus])}>
                        {statusLabel(o.status)}
                      </span>
                    </td>
                    <td className="px-6 py-4 text-xs text-zinc-500">{when(o.createdAt)}</td>
                    <td className="px-6 py-4 text-right">
                      <span className="inline-flex p-1.5 rounded-lg text-zinc-400 group-hover:text-red-600 group-hover:bg-red-50 transition-all">
                        <ChevronRight size={16} />
                      </span>
                    </td>
                  </tr>
                ))}
            </tbody>
          </table>
        </div>
      </div>

      {selectedOrderId && (
        <OrderDetailModal
          id={selectedOrderId}
          canAct={canAct}
          onClose={() => setSelectedOrderId(null)}
          onChanged={() => setReloadNonce((n) => n + 1)}
        />
      )}

      {showPhoneModal && (
        <PhoneOrderModal
          onClose={() => setShowPhoneModal(false)}
          onCreated={() => setReloadNonce((n) => n + 1)}
        />
      )}
    </div>
  );
}
