import React, { useEffect, useState } from "react";
import { Eye, EyeOff, Image as ImageIcon, Megaphone, Plus, Send, Tag, Trash2, Upload, X } from "lucide-react";
import { AnimatePresence, motion } from "motion/react";
import { api } from "../api";
import type { AdminCoupon, NotificationItem, PopupCampaign } from "../types";
import { cn, money, when } from "../utils";

interface PopupDraft {
  tag: string;
  title: string;
  description: string;
  buttonText: string;
  imageUrl: string | null;
}

const EMPTY_POPUP: PopupDraft = {
  tag: "",
  title: "",
  description: "",
  buttonText: "",
  imageUrl: null,
};

export default function MarketingPage() {
  const [history, setHistory] = useState<NotificationItem[]>([]);
  const [coupons, setCoupons] = useState<AdminCoupon[]>([]);
  const [popups, setPopups] = useState<PopupCampaign[]>([]);
  const [showCouponForm, setShowCouponForm] = useState(false);

  // Push Notification state
  const [pushForm, setPushForm] = useState({ title: "", body: "", audience: "all" as "all" | "one", phone: "" });
  const [pushMsg, setPushMsg] = useState("");
  const [pushErr, setPushErr] = useState("");
  const [pushBusy, setPushBusy] = useState(false);

  // Coupon state
  const [couponForm, setCouponForm] = useState({
    code: "",
    discountType: "percentage" as "percentage" | "fixed",
    discountValue: "",
    maxDiscountRs: "",
    minOrderRs: "",
    maxRedemptions: "",
    expiresAt: "",
  });
  const [couponErr, setCouponErr] = useState("");

  // 4:5 In-App Popup Campaign Builder (strict real uploads + SQLite persistence)
  const [previewPopup, setPreviewPopup] = useState<PopupDraft | null>(null);
  const [popupData, setPopupData] = useState<PopupDraft>(EMPTY_POPUP);
  const [popupUploading, setPopupUploading] = useState(false);
  const [popupBusy, setPopupBusy] = useState(false);
  const [popupErr, setPopupErr] = useState("");
  const [popupNotice, setPopupNotice] = useState("");

  const loadAll = () => {
    api<NotificationItem[]>("/admin/notifications").then(setHistory).catch(() => {});
    api<AdminCoupon[]>("/admin/coupons").then(setCoupons).catch(() => {});
    api<PopupCampaign[]>("/admin/popups").then(setPopups).catch(() => {});
  };

  useEffect(() => {
    loadAll();
  }, []);

  const sendPush = async (e: React.FormEvent) => {
    e.preventDefault();
    setPushBusy(true);
    setPushErr("");
    setPushMsg("");
    try {
      const body = {
        title: pushForm.title,
        body: pushForm.body,
        audience: pushForm.audience,
        ...(pushForm.audience === "one" ? { phone: pushForm.phone } : {}),
      };
      const res = await api<{ sent: number }>("/admin/notifications", { method: "POST", body });
      setPushMsg(`Delivered to ${res.sent} registered device(s).`);
      setPushForm({ ...pushForm, title: "", body: "" });
      loadAll();
    } catch (x: any) {
      setPushErr(x?.message || "Failed to send notification");
    } finally {
      setPushBusy(false);
    }
  };

  const createCoupon = async (e: React.FormEvent) => {
    e.preventDefault();
    setCouponErr("");
    try {
      const discountVal = Number(couponForm.discountValue);
      const maxDisc = couponForm.maxDiscountRs ? Math.round(Number(couponForm.maxDiscountRs) * 100) : 15000;
      const minOrd = couponForm.minOrderRs ? Math.round(Number(couponForm.minOrderRs) * 100) : 0;
      const maxRed = couponForm.maxRedemptions ? Number(couponForm.maxRedemptions) : 100;
      await api("/admin/coupons", {
        method: "POST",
        body: {
          code: couponForm.code,
          discountType: couponForm.discountType,
          discountValue: discountVal,
          maxDiscountPaise: maxDisc,
          minOrderPaise: minOrd,
          maxRedemptions: maxRed,
          expiresAt: new Date(couponForm.expiresAt + "T23:59:59Z").toISOString(),
        },
      });
      setShowCouponForm(false);
      setCouponForm({
        code: "",
        discountType: "percentage",
        discountValue: "",
        maxDiscountRs: "",
        minOrderRs: "",
        maxRedemptions: "",
        expiresAt: "",
      });
      loadAll();
    } catch (x: any) {
      setCouponErr(x?.message || "Could not create coupon");
    }
  };

  const deactivateCoupon = async (code: string) => {
    await api(`/admin/coupons/${encodeURIComponent(code)}/deactivate`, { method: "PUT" }).catch(() => {});
    loadAll();
  };

  const handlePopupImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const form = new FormData();
    form.append("image", file);
    setPopupUploading(true);
    setPopupErr("");
    setPopupNotice("");
    try {
      const res = await api<{ imageUrl: string }>("/admin/popups/image", { method: "POST", form });
      setPopupData((prev) => ({ ...prev, imageUrl: res.imageUrl }));
    } catch (x: any) {
      setPopupErr(x?.message || "Image upload failed");
    } finally {
      setPopupUploading(false);
    }
  };

  const publishPopup = async (e: React.FormEvent) => {
    e.preventDefault();
    setPopupErr("");
    setPopupNotice("");
    if (!popupData.imageUrl) {
      setPopupErr("Upload a 4:5 campaign image before publishing.");
      return;
    }
    setPopupBusy(true);
    try {
      await api<PopupCampaign>("/admin/popups", {
        method: "POST",
        body: {
          tag: popupData.tag,
          title: popupData.title,
          description: popupData.description,
          buttonText: popupData.buttonText,
          imageUrl: popupData.imageUrl,
        },
      });
      setPopupData(EMPTY_POPUP);
      setPopupNotice("Popup campaign published and saved.");
      loadAll();
    } catch (x: any) {
      setPopupErr(x?.message || "Could not publish popup campaign");
    } finally {
      setPopupBusy(false);
    }
  };

  const togglePopup = async (p: PopupCampaign) => {
    try {
      await api(`/admin/popups/${p.id}`, { method: "PATCH", body: { active: !p.active } });
      loadAll();
    } catch (x: any) {
      setPopupErr(x?.message || "Could not update popup campaign");
    }
  };

  const deletePopup = async (id: string) => {
    try {
      await api(`/admin/popups/${id}`, { method: "DELETE" });
      loadAll();
    } catch (x: any) {
      setPopupErr(x?.message || "Could not delete popup campaign");
    }
  };

  return (
    <div className="space-y-8">
      {/* 4:5 Popup Preview Modal */}
      <AnimatePresence>
        {previewPopup && (
          <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="absolute inset-0 bg-black/60 backdrop-blur-sm"
              onClick={() => setPreviewPopup(null)}
            />
            <motion.div
              initial={{ opacity: 0, scale: 0.94, y: 16 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.94, y: 16 }}
              className="relative w-full max-w-[400px] aspect-[4/5] bg-zinc-900 rounded-3xl overflow-hidden shadow-2xl z-10 flex flex-col"
            >
              <button
                type="button"
                aria-label="Close popup preview"
                onClick={() => setPreviewPopup(null)}
                className="absolute top-3.5 right-3.5 z-20 w-8 h-8 bg-black/55 hover:bg-black/75 backdrop-blur text-white rounded-full flex items-center justify-center transition-all"
              >
                <X size={16} strokeWidth={2.5} />
              </button>
              <div className="flex-1 relative">
                {previewPopup.imageUrl ? (
                  <img
                    src={previewPopup.imageUrl}
                    alt={previewPopup.title || "Popup preview"}
                    className="absolute inset-0 w-full h-full object-cover"
                    referrerPolicy="no-referrer"
                  />
                ) : (
                  <div className="absolute inset-0 flex items-center justify-center text-zinc-600">
                    <ImageIcon size={40} />
                  </div>
                )}
                <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/30 to-transparent flex flex-col justify-end p-7 text-white">
                  {previewPopup.tag && (
                    <span className="bg-red-600 text-white text-xs font-bold uppercase tracking-wider px-3 py-1 rounded-full w-fit mb-3">
                      {previewPopup.tag}
                    </span>
                  )}
                  <h3 className="text-2xl font-black mb-2 leading-tight">{previewPopup.title}</h3>
                  {previewPopup.description && <p className="text-white/85 text-sm mb-5">{previewPopup.description}</p>}
                  {previewPopup.buttonText && (
                    <button
                      type="button"
                      onClick={() => setPreviewPopup(null)}
                      className="w-full bg-white text-black font-bold py-3 rounded-xl hover:bg-zinc-100 transition-all"
                    >
                      {previewPopup.buttonText}
                    </button>
                  )}
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>

      {/* Coupons Section */}
      <div className="space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h3 className="text-xl font-bold text-zinc-900">Offers & Coupons</h3>
            <p className="text-xs text-zinc-500">One use per customer enforced atomically on the server</p>
          </div>
          <button
            type="button"
            onClick={() => setShowCouponForm(!showCouponForm)}
            className="inline-flex items-center justify-center gap-2 bg-red-600 text-white px-5 py-2.5 rounded-2xl text-xs font-bold hover:bg-red-700 transition-all"
          >
            <Plus size={15} />
            Create Coupon
          </button>
        </div>

        {showCouponForm && (
          <form onSubmit={createCoupon} className="bg-white p-6 rounded-3xl border border-black/5 shadow-sm grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div>
              <label className="text-xs font-bold uppercase text-zinc-500 block mb-1">Coupon Code</label>
              <input
                required
                minLength={3}
                maxLength={20}
                placeholder="Enter code"
                value={couponForm.code}
                onChange={(e) => setCouponForm({ ...couponForm, code: e.target.value.toUpperCase() })}
                className="w-full bg-zinc-50 rounded-xl px-3.5 py-2.5 text-sm outline-none focus:ring-2 focus:ring-red-500"
              />
            </div>
            <div>
              <label className="text-xs font-bold uppercase text-zinc-500 block mb-1">Type</label>
              <select
                value={couponForm.discountType}
                onChange={(e) => setCouponForm({ ...couponForm, discountType: e.target.value as "percentage" | "fixed" })}
                className="w-full bg-zinc-50 rounded-xl px-3.5 py-2.5 text-sm outline-none focus:ring-2 focus:ring-red-500"
              >
                <option value="percentage">Percentage (%)</option>
                <option value="fixed">Fixed Amount (₹)</option>
              </select>
            </div>
            <div>
              <label className="text-xs font-bold uppercase text-zinc-500 block mb-1">
                {couponForm.discountType === "percentage" ? "Discount (%)" : "Discount (₹)"}
              </label>
              <input
                type="number"
                min={1}
                max={couponForm.discountType === "percentage" ? 50 : 2000}
                required
                placeholder="Enter value"
                value={couponForm.discountValue}
                onChange={(e) => setCouponForm({ ...couponForm, discountValue: e.target.value })}
                className="w-full bg-zinc-50 rounded-xl px-3.5 py-2.5 text-sm outline-none focus:ring-2 focus:ring-red-500 tabular-nums"
              />
            </div>
            <div>
              <label className="text-xs font-bold uppercase text-zinc-500 block mb-1">Min Order (₹)</label>
              <input
                type="number"
                min={0}
                placeholder="0"
                value={couponForm.minOrderRs}
                onChange={(e) => setCouponForm({ ...couponForm, minOrderRs: e.target.value })}
                className="w-full bg-zinc-50 rounded-xl px-3.5 py-2.5 text-sm outline-none focus:ring-2 focus:ring-red-500 tabular-nums"
              />
            </div>
            <div>
              <label className="text-xs font-bold uppercase text-zinc-500 block mb-1">Max Discount (₹)</label>
              <input
                type="number"
                min={1}
                placeholder="150"
                value={couponForm.maxDiscountRs}
                onChange={(e) => setCouponForm({ ...couponForm, maxDiscountRs: e.target.value })}
                className="w-full bg-zinc-50 rounded-xl px-3.5 py-2.5 text-sm outline-none focus:ring-2 focus:ring-red-500 tabular-nums"
              />
            </div>
            <div>
              <label className="text-xs font-bold uppercase text-zinc-500 block mb-1">Max Redemptions</label>
              <input
                type="number"
                min={1}
                placeholder="100"
                value={couponForm.maxRedemptions}
                onChange={(e) => setCouponForm({ ...couponForm, maxRedemptions: e.target.value })}
                className="w-full bg-zinc-50 rounded-xl px-3.5 py-2.5 text-sm outline-none focus:ring-2 focus:ring-red-500 tabular-nums"
              />
            </div>
            <div className="sm:col-span-2">
              <label className="text-xs font-bold uppercase text-zinc-500 block mb-1">Expiry Date</label>
              <div className="flex gap-2">
                <input
                  type="date"
                  required
                  value={couponForm.expiresAt}
                  onChange={(e) => setCouponForm({ ...couponForm, expiresAt: e.target.value })}
                  className="flex-1 bg-zinc-50 rounded-xl px-3 py-2.5 text-sm outline-none focus:ring-2 focus:ring-red-500"
                />
                <button type="submit" className="px-5 rounded-xl bg-zinc-900 text-white text-xs font-bold hover:bg-black">
                  Save Coupon
                </button>
              </div>
            </div>
            {couponErr && <p className="col-span-full text-xs font-semibold text-rose-600">{couponErr}</p>}
          </form>
        )}

        {coupons.length === 0 ? (
          <div className="bg-white rounded-3xl border border-black/5 p-10 text-center text-zinc-500">
            <Tag size={28} className="mx-auto text-zinc-300 mb-2" />
            <p className="text-sm font-medium text-zinc-700">No coupons created yet.</p>
            <p className="text-xs text-zinc-400 mt-1">Create your first discount code to run customer promotions.</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
            {coupons.map((c) => (
              <div
                key={c.code}
                className={cn(
                  "bg-white p-5 rounded-3xl border-2 border-dashed transition-all",
                  c.active ? "border-red-200" : "border-zinc-200 opacity-60"
                )}
              >
                <div className="flex items-center justify-between mb-3">
                  <span className={cn("inline-flex items-center gap-1.5 font-bold text-sm", c.active ? "text-red-600" : "text-zinc-500")}>
                    <Tag size={15} /> {c.code}
                  </span>
                  <span className="text-[11px] font-semibold text-zinc-400 tabular-nums">
                    {c.redeemedCount}/{c.maxRedemptions} used
                  </span>
                </div>
                <p className="text-2xl font-black text-zinc-900 tabular-nums">
                  {c.discountType === "percentage" ? `${c.discountValue}%` : `₹${c.discountValue}`} OFF
                </p>
                <p className="text-xs text-zinc-500 mt-1 tabular-nums">
                  Min order {money(c.minOrderPaise)} · Expires {new Date(c.expiresAt).toLocaleDateString("en-IN")}
                </p>
                <div className="flex items-center justify-between pt-3 mt-4 border-t border-black/5">
                  <span className={cn("text-[11px] font-bold uppercase", c.active ? "text-emerald-600" : "text-zinc-400")}>
                    {c.active ? "Active" : "Inactive"}
                  </span>
                  {c.active && (
                    <button type="button" onClick={() => deactivateCoupon(c.code)} className="text-xs font-bold text-zinc-400 hover:text-rose-600">
                      Deactivate
                    </button>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Push Notifications + 4:5 Popup Campaign */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white p-6 rounded-3xl border border-black/5 shadow-sm space-y-5">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-red-50 text-red-600 flex items-center justify-center">
              <Megaphone size={18} />
            </div>
            <div>
              <h4 className="font-bold text-zinc-900">Push Notification</h4>
              <p className="text-xs text-zinc-500">Send directly to customer app devices (10-min broadcast guard)</p>
            </div>
          </div>

          <form onSubmit={sendPush} className="space-y-3">
            <div className="grid grid-cols-2 gap-3">
              <select
                value={pushForm.audience}
                onChange={(e) => setPushForm({ ...pushForm, audience: e.target.value as "all" | "one" })}
                className="bg-zinc-50 border border-black/5 rounded-xl px-3.5 py-2.5 text-sm outline-none focus:ring-2 focus:ring-red-500"
              >
                <option value="all">All Customers</option>
                <option value="one">One Customer</option>
              </select>
              {pushForm.audience === "one" && (
                <input
                  inputMode="numeric"
                  maxLength={10}
                  placeholder="10-digit mobile number"
                  value={pushForm.phone}
                  onChange={(e) => setPushForm({ ...pushForm, phone: e.target.value.replace(/\D/g, "") })}
                  required
                  className="bg-zinc-50 border border-black/5 rounded-xl px-3.5 py-2.5 text-sm outline-none focus:ring-2 focus:ring-red-500 tabular-nums"
                />
              )}
            </div>
            <input
              placeholder="Notification title (max 60)"
              maxLength={60}
              required
              value={pushForm.title}
              onChange={(e) => setPushForm({ ...pushForm, title: e.target.value })}
              className="w-full bg-zinc-50 border border-black/5 rounded-xl px-4 py-2.5 text-sm outline-none focus:ring-2 focus:ring-red-500"
            />
            <textarea
              placeholder="Message body (max 200)"
              maxLength={200}
              rows={3}
              required
              value={pushForm.body}
              onChange={(e) => setPushForm({ ...pushForm, body: e.target.value })}
              className="w-full bg-zinc-50 border border-black/5 rounded-xl px-4 py-2.5 text-sm outline-none focus:ring-2 focus:ring-red-500 resize-none"
            />
            {pushErr && <p className="text-xs font-semibold text-rose-600">{pushErr}</p>}
            {pushMsg && <p className="text-xs font-semibold text-emerald-600">{pushMsg}</p>}
            <button
              type="submit"
              disabled={pushBusy}
              className="w-full inline-flex items-center justify-center gap-2 py-3 rounded-xl bg-red-600 text-white font-bold text-sm hover:bg-red-700 disabled:opacity-50"
            >
              <Send size={15} />
              {pushBusy ? "Sending..." : "Send Push Notification"}
            </button>
          </form>

          <div className="pt-4 border-t border-black/5 space-y-2.5">
            <h5 className="text-xs font-bold uppercase tracking-wider text-zinc-400">Sent History</h5>
            {history.length === 0 ? (
              <p className="text-xs text-zinc-400">No notifications sent yet.</p>
            ) : (
              <div className="space-y-2 max-h-52 overflow-y-auto">
                {history.map((n) => (
                  <div key={n.id} className="p-3 rounded-2xl bg-zinc-50 text-xs space-y-0.5">
                    <div className="flex items-center justify-between gap-2">
                      <span className="font-bold text-zinc-900">{n.title}</span>
                      <span className="text-[11px] text-zinc-400 tabular-nums">{n.sentCount} delivered</span>
                    </div>
                    <p className="text-zinc-600">{n.body}</p>
                    <p className="text-[10px] text-zinc-400 pt-0.5">
                      {when(n.createdAt)} · {n.audience === "all" ? "All customers" : "One customer"}
                    </p>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* 4:5 In-App Popup Campaign Builder */}
        <div className="bg-white p-6 rounded-3xl border border-black/5 shadow-sm space-y-5">
          <div>
            <h4 className="font-bold text-zinc-900">In-App Popup Campaign (4:5)</h4>
            <p className="text-xs text-zinc-500">Create and persist portrait promotional popups with a corner close button</p>
          </div>

          <form onSubmit={publishPopup} className="space-y-3.5">
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-xs font-bold uppercase text-zinc-500 block mb-1">Badge Tag (optional)</label>
                <input
                  maxLength={30}
                  placeholder="Enter tag"
                  value={popupData.tag}
                  onChange={(e) => setPopupData({ ...popupData, tag: e.target.value })}
                  className="w-full bg-zinc-50 rounded-xl px-3.5 py-2.5 text-sm outline-none focus:ring-2 focus:ring-red-500"
                />
              </div>
              <div>
                <label className="text-xs font-bold uppercase text-zinc-500 block mb-1">Button Label</label>
                <input
                  required
                  maxLength={40}
                  placeholder="Enter CTA label"
                  value={popupData.buttonText}
                  onChange={(e) => setPopupData({ ...popupData, buttonText: e.target.value })}
                  className="w-full bg-zinc-50 rounded-xl px-3.5 py-2.5 text-sm outline-none focus:ring-2 focus:ring-red-500"
                />
              </div>
            </div>
            <div>
              <label className="text-xs font-bold uppercase text-zinc-500 block mb-1">Headline</label>
              <input
                required
                minLength={2}
                maxLength={80}
                placeholder="Enter campaign headline"
                value={popupData.title}
                onChange={(e) => setPopupData({ ...popupData, title: e.target.value })}
                className="w-full bg-zinc-50 rounded-xl px-3.5 py-2.5 text-sm outline-none focus:ring-2 focus:ring-red-500"
              />
            </div>
            <div>
              <label className="text-xs font-bold uppercase text-zinc-500 block mb-1">Description</label>
              <textarea
                rows={2}
                maxLength={240}
                placeholder="Enter short offer details"
                value={popupData.description}
                onChange={(e) => setPopupData({ ...popupData, description: e.target.value })}
                className="w-full bg-zinc-50 rounded-xl px-3.5 py-2.5 text-sm outline-none focus:ring-2 focus:ring-red-500 resize-none"
              />
            </div>
            <div>
              <label className="text-xs font-bold uppercase text-zinc-500 block mb-1">Background Image (4:5)</label>
              <div className="flex items-center gap-4">
                <div className="w-16 h-20 rounded-xl overflow-hidden bg-zinc-100 flex-shrink-0 border border-black/5 flex items-center justify-center">
                  {popupData.imageUrl ? (
                    <img src={popupData.imageUrl} alt="Uploaded campaign" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                  ) : (
                    <ImageIcon size={22} className="text-zinc-300" />
                  )}
                </div>
                <div className="space-y-1">
                  <label className="inline-flex items-center gap-2 cursor-pointer bg-zinc-100 hover:bg-zinc-200 text-zinc-800 px-4 py-2 rounded-xl text-xs font-bold transition-all">
                    <Upload size={14} />
                    {popupUploading ? "Uploading..." : "Upload 4:5 Image"}
                    <input type="file" accept="image/*" className="hidden" onChange={handlePopupImageUpload} disabled={popupUploading} />
                  </label>
                  <p className="text-[11px] text-zinc-400">PNG, JPEG, WebP, or GIF · Max 4 MB</p>
                </div>
              </div>
            </div>

            {popupErr && <p className="text-xs font-semibold text-rose-600">{popupErr}</p>}
            {popupNotice && <p className="text-xs font-semibold text-emerald-600">{popupNotice}</p>}

            <div className="flex gap-3 pt-1">
              <button
                type="button"
                disabled={!popupData.imageUrl && !popupData.title}
                onClick={() => setPreviewPopup(popupData)}
                className="flex-1 py-3 rounded-xl bg-zinc-100 text-zinc-900 font-bold text-sm hover:bg-zinc-200 transition-all disabled:opacity-40"
              >
                Preview 4:5
              </button>
              <button
                type="submit"
                disabled={popupBusy || popupUploading || !popupData.imageUrl}
                className="flex-1 py-3 rounded-xl bg-zinc-900 text-white font-bold text-sm hover:bg-black transition-all disabled:opacity-40"
              >
                {popupBusy ? "Publishing..." : "Publish Popup"}
              </button>
            </div>
          </form>

          {/* Saved Popup Campaigns List */}
          <div className="pt-4 border-t border-black/5 space-y-2.5">
            <h5 className="text-xs font-bold uppercase tracking-wider text-zinc-400">Saved Campaigns ({popups.length})</h5>
            {popups.length === 0 ? (
              <p className="text-xs text-zinc-400">No popup campaigns published yet.</p>
            ) : (
              <div className="space-y-2 max-h-56 overflow-y-auto">
                {popups.map((p) => (
                  <div key={p.id} className="p-3 rounded-2xl bg-zinc-50 flex items-center justify-between gap-3">
                    <div className="flex items-center gap-3 min-w-0">
                      <img
                        src={p.imageUrl}
                        alt={p.title}
                        className="w-10 h-12 rounded-lg object-cover bg-zinc-200 flex-shrink-0"
                        referrerPolicy="no-referrer"
                      />
                      <div className="min-w-0">
                        <p className="text-xs font-bold text-zinc-900 truncate">{p.title}</p>
                        <p className="text-[11px] text-zinc-500">
                          {p.active ? "Active" : "Paused"} · {when(p.createdAt)}
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center gap-1 flex-shrink-0">
                      <button
                        type="button"
                        onClick={() => setPreviewPopup(p)}
                        className="px-2.5 py-1.5 rounded-lg bg-white text-zinc-700 hover:text-zinc-900 text-[11px] font-bold border border-black/5"
                      >
                        Preview
                      </button>
                      <button
                        type="button"
                        onClick={() => togglePopup(p)}
                        title={p.active ? "Pause campaign" : "Activate campaign"}
                        className="p-1.5 rounded-lg bg-white text-zinc-600 hover:text-zinc-900 border border-black/5"
                      >
                        {p.active ? <Eye size={13} /> : <EyeOff size={13} />}
                      </button>
                      <button
                        type="button"
                        onClick={() => deletePopup(p.id)}
                        title="Delete campaign"
                        className="p-1.5 rounded-lg bg-white text-zinc-400 hover:text-rose-600 border border-black/5"
                      >
                        <Trash2 size={13} />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
