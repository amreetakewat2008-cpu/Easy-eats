import React, { useEffect, useState } from "react";
import { Eye, EyeOff, Image as ImageIcon, Plus, Search, Upload, X } from "lucide-react";
import { api } from "../api";
import type { CatalogueItem } from "../types";
import { cn, money } from "../utils";

function VegIndicator({ veg }: { veg: boolean }) {
  return (
    <span
      title={veg ? "Vegetarian" : "Non-Vegetarian"}
      className={cn(
        "inline-flex items-center justify-center w-4 h-4 rounded-sm border-[1.5px] flex-shrink-0 bg-white",
        veg ? "border-emerald-600" : "border-red-600"
      )}
    >
      <span className={cn("w-2 h-2 rounded-full", veg ? "bg-emerald-600" : "bg-red-600")} />
    </span>
  );
}

interface FormState {
  name: string;
  description: string;
  price: string;
  sellingPrice: string;
  category: string;
  isVeg: boolean;
  keywords: string;
  stock: string;
  imageUrl: string | null;
  isAvailable: boolean;
}

const EMPTY_FORM: FormState = {
  name: "",
  description: "",
  price: "",
  sellingPrice: "",
  category: "",
  isVeg: true,
  keywords: "",
  stock: "50",
  imageUrl: null,
  isAvailable: true,
};

function ItemModal({
  item,
  categories,
  onClose,
  onSaved,
}: {
  item: CatalogueItem | null;
  categories: string[];
  onClose: () => void;
  onSaved: () => void;
}) {
  const [f, setF] = useState<FormState>(
    item
      ? {
          name: item.name,
          description: item.description,
          price: String(item.pricePaise / 100),
          sellingPrice: String(item.sellingPricePaise / 100),
          category: item.category,
          isVeg: item.isVeg,
          keywords: item.keywords.join(", "),
          stock: String(item.stock),
          imageUrl: item.imageUrl,
          isAvailable: item.isAvailable,
        }
      : EMPTY_FORM
  );
  const [busy, setBusy] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [err, setErr] = useState("");

  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const form = new FormData();
    form.append("image", file);
    setUploading(true);
    setErr("");
    try {
      const r = await api<{ imageUrl: string }>("/admin/catalogue/image", { method: "POST", form });
      setF((prev) => ({ ...prev, imageUrl: r.imageUrl }));
    } catch (x: any) {
      setErr(x?.message || "Image upload failed");
    } finally {
      setUploading(false);
    }
  };

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setBusy(true);
    setErr("");
    const pricePaise = Math.round(parseFloat(f.price) * 100);
    const sellingPricePaise = f.sellingPrice ? Math.round(parseFloat(f.sellingPrice) * 100) : pricePaise;
    const body = {
      name: f.name,
      description: f.description,
      pricePaise,
      sellingPricePaise,
      isVeg: f.isVeg,
      category: f.category,
      keywords: f.keywords
        .split(",")
        .map((k) => k.trim().toLowerCase())
        .filter((k) => k.length >= 2),
      imageUrl: f.imageUrl,
      stock: parseInt(f.stock || "0", 10) || 0,
      isAvailable: f.isAvailable,
    };
    try {
      await api(item ? `/admin/catalogue/${item.id}` : "/admin/catalogue", {
        method: item ? "PUT" : "POST",
        body,
      });
      onSaved();
    } catch (x: any) {
      setErr(x?.message || "Could not save item");
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm" onClick={onClose}>
      <form
        onSubmit={submit}
        onClick={(e) => e.stopPropagation()}
        className="bg-white rounded-3xl w-full max-w-lg max-h-[90vh] overflow-y-auto shadow-2xl p-6 space-y-4"
      >
        <div className="flex items-center justify-between">
          <h3 className="text-lg font-bold">{item ? "Edit Menu Item" : "Add Menu Item"}</h3>
          <button type="button" onClick={onClose} className="p-2 rounded-xl text-zinc-400 hover:bg-zinc-100">
            <X size={18} />
          </button>
        </div>

        <div className="space-y-3">
          <div className="flex items-center gap-4">
            <div className="w-24 h-20 rounded-2xl bg-zinc-100 border border-black/5 overflow-hidden flex items-center justify-center flex-shrink-0">
              {f.imageUrl ? (
                <img src={f.imageUrl} alt="Preview" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
              ) : (
                <ImageIcon size={24} className="text-zinc-300" />
              )}
            </div>
            <div className="space-y-1.5">
              <label className="inline-flex items-center gap-2 cursor-pointer bg-zinc-100 hover:bg-zinc-200 text-zinc-800 px-4 py-2 rounded-xl text-xs font-bold transition-all">
                <Upload size={14} />
                {uploading ? "Uploading..." : "Upload Photo (max 4 MB)"}
                <input type="file" accept="image/*" className="hidden" onChange={handleImageUpload} disabled={uploading} />
              </label>
              <p className="text-[11px] text-zinc-400">Validated server-side · Stored securely in /media</p>
            </div>
          </div>

          <div>
            <label className="text-xs font-bold uppercase text-zinc-500 block mb-1">Title</label>
            <input
              required
              minLength={2}
              maxLength={80}
              value={f.name}
              onChange={(e) => setF({ ...f, name: e.target.value })}
              placeholder="Enter item title"
              className="w-full bg-zinc-50 border border-black/5 rounded-xl px-4 py-2.5 text-sm outline-none focus:ring-2 focus:ring-red-500"
            />
          </div>

          <div>
            <label className="text-xs font-bold uppercase text-zinc-500 block mb-1">Description</label>
            <textarea
              rows={2}
              maxLength={500}
              value={f.description}
              onChange={(e) => setF({ ...f, description: e.target.value })}
              placeholder="Enter item description"
              className="w-full bg-zinc-50 border border-black/5 rounded-xl px-4 py-2.5 text-sm outline-none focus:ring-2 focus:ring-red-500 resize-none"
            />
          </div>

          <div className="grid grid-cols-3 gap-3">
            <div>
              <label className="text-xs font-bold uppercase text-zinc-500 block mb-1">MRP (₹)</label>
              <input
                type="number"
                step="0.01"
                min="1"
                required
                value={f.price}
                onChange={(e) => setF({ ...f, price: e.target.value })}
                className="w-full bg-zinc-50 border border-black/5 rounded-xl px-3 py-2.5 text-sm outline-none focus:ring-2 focus:ring-red-500"
              />
            </div>
            <div>
              <label className="text-xs font-bold uppercase text-zinc-500 block mb-1">Selling (₹)</label>
              <input
                type="number"
                step="0.01"
                min="1"
                value={f.sellingPrice}
                onChange={(e) => setF({ ...f, sellingPrice: e.target.value })}
                placeholder="Same as MRP"
                className="w-full bg-zinc-50 border border-black/5 rounded-xl px-3 py-2.5 text-sm outline-none focus:ring-2 focus:ring-red-500"
              />
            </div>
            <div>
              <label className="text-xs font-bold uppercase text-zinc-500 block mb-1">Stock</label>
              <input
                type="number"
                min="0"
                value={f.stock}
                onChange={(e) => setF({ ...f, stock: e.target.value })}
                className="w-full bg-zinc-50 border border-black/5 rounded-xl px-3 py-2.5 text-sm outline-none focus:ring-2 focus:ring-red-500"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="text-xs font-bold uppercase text-zinc-500 block mb-1">Category</label>
              <input
                list="catalogue-categories"
                required
                value={f.category}
                onChange={(e) => setF({ ...f, category: e.target.value })}
                placeholder="Enter category"
                className="w-full bg-zinc-50 border border-black/5 rounded-xl px-4 py-2.5 text-sm outline-none focus:ring-2 focus:ring-red-500"
              />
              <datalist id="catalogue-categories">
                {categories.map((c) => (
                  <option key={c} value={c} />
                ))}
              </datalist>
            </div>
            <div>
              <label className="text-xs font-bold uppercase text-zinc-500 block mb-1">Dietary Tag</label>
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => setF({ ...f, isVeg: true })}
                  className={cn(
                    "py-2.5 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 border transition-all",
                    f.isVeg ? "bg-emerald-50 border-emerald-500 text-emerald-700" : "bg-zinc-50 border-transparent text-zinc-500"
                  )}
                >
                  <VegIndicator veg={true} /> Veg
                </button>
                <button
                  type="button"
                  onClick={() => setF({ ...f, isVeg: false })}
                  className={cn(
                    "py-2.5 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 border transition-all",
                    !f.isVeg ? "bg-red-50 border-red-500 text-red-700" : "bg-zinc-50 border-transparent text-zinc-500"
                  )}
                >
                  <VegIndicator veg={false} /> Non-Veg
                </button>
              </div>
            </div>
          </div>

          <div>
            <label className="text-xs font-bold uppercase text-zinc-500 block mb-1">Search Keywords (comma separated)</label>
            <input
              value={f.keywords}
              onChange={(e) => setF({ ...f, keywords: e.target.value })}
              placeholder="Comma-separated search keywords"
              className="w-full bg-zinc-50 border border-black/5 rounded-xl px-4 py-2.5 text-sm outline-none focus:ring-2 focus:ring-red-500"
            />
          </div>

          <label className="flex items-center justify-between bg-zinc-50 p-3.5 rounded-2xl cursor-pointer">
            <div>
              <p className="text-sm font-bold text-zinc-900">Available to order</p>
              <p className="text-[11px] text-zinc-500">Items are hidden rather than deleted to preserve order & money records</p>
            </div>
            <input
              type="checkbox"
              checked={f.isAvailable}
              onChange={(e) => setF({ ...f, isAvailable: e.target.checked })}
              className="w-5 h-5 accent-red-600 rounded"
            />
          </label>
        </div>

        {err && <p className="text-xs font-semibold text-rose-600 bg-rose-50 px-3 py-2 rounded-xl">{err}</p>}

        <div className="flex gap-3 pt-2">
          <button type="button" onClick={onClose} className="flex-1 py-3 rounded-xl bg-zinc-100 font-bold text-sm text-zinc-700 hover:bg-zinc-200">
            Cancel
          </button>
          <button
            type="submit"
            disabled={busy || uploading}
            className="flex-1 py-3 rounded-xl bg-red-600 text-white font-bold text-sm hover:bg-red-700 disabled:opacity-50"
          >
            {busy ? "Saving..." : item ? "Save Changes" : "Add Item"}
          </button>
        </div>
      </form>
    </div>
  );
}

export default function CataloguePage() {
  const [items, setItems] = useState<CatalogueItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [query, setQuery] = useState("");
  const [editing, setEditing] = useState<CatalogueItem | "new" | null>(null);

  const load = () => {
    setLoading(true);
    api<CatalogueItem[]>("/admin/catalogue")
      .then((res) => {
        setItems(res);
        setLoading(false);
      })
      .catch((e: any) => {
        setError(e?.message || "Failed to load catalogue");
        setLoading(false);
      });
  };

  useEffect(() => {
    load();
  }, []);

  const toggleAvailability = async (item: CatalogueItem) => {
    try {
      await api(`/admin/catalogue/${item.id}`, {
        method: "PUT",
        body: { ...item, isAvailable: !item.isAvailable },
      });
      load();
    } catch (e: any) {
      setError(e?.message || "Could not update item");
    }
  };

  const categories: string[] = Array.from(new Set<string>(items.map((i) => i.category)));
  const filtered = items.filter((i) =>
    `${i.name} ${i.category} ${i.description} ${i.keywords.join(" ")}`.toLowerCase().includes(query.toLowerCase())
  );

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h3 className="text-xl font-bold text-zinc-900">Product Catalogue</h3>
          <p className="text-xs text-zinc-500 mt-0.5">Manage menu photos, INR pricing, keywords, and live availability</p>
        </div>
        <button
          onClick={() => setEditing("new")}
          className="inline-flex items-center justify-center gap-2 bg-red-600 text-white px-5 py-2.5 rounded-2xl text-sm font-bold hover:bg-red-700 transition-all shadow-sm"
        >
          <Plus size={16} />
          Add Menu Item
        </button>
      </div>

      <div className="relative max-w-md">
        <Search size={16} className="absolute left-4 top-1/2 -translate-y-1/2 text-zinc-400" />
        <input
          type="text"
          placeholder="Search by title, category, or keyword..."
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          className="w-full pl-11 pr-4 py-2.5 bg-white border border-black/5 rounded-2xl text-sm shadow-sm outline-none focus:ring-2 focus:ring-red-500"
        />
      </div>

      {error && <div className="p-4 rounded-2xl bg-rose-50 text-rose-700 text-xs font-semibold">{error}</div>}

      {loading ? (
        <div className="py-12 text-center text-sm text-zinc-400">Loading catalogue...</div>
      ) : items.length === 0 ? (
        <div className="bg-white rounded-3xl border border-black/5 p-12 text-center space-y-3">
          <ImageIcon size={34} className="mx-auto text-zinc-300" />
          <div>
            <p className="text-sm font-bold text-zinc-800">No menu items yet</p>
            <p className="text-xs text-zinc-500 mt-1">Add your first dish with INR pricing and uploaded photos to build your catalogue.</p>
          </div>
          <button
            type="button"
            onClick={() => setEditing("new")}
            className="inline-flex items-center gap-2 bg-red-600 text-white px-5 py-2.5 rounded-2xl text-xs font-bold hover:bg-red-700 transition-all"
          >
            <Plus size={15} />
            Add First Item
          </button>
        </div>
      ) : filtered.length === 0 ? (
        <div className="bg-white rounded-3xl border border-black/5 p-12 text-center text-zinc-500">
          <p className="text-sm font-medium text-zinc-700">No menu items match "{query}".</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-5">
          {filtered.map((item) => (
            <div
              key={item.id}
              className={cn(
                "bg-white rounded-3xl border border-black/5 shadow-sm overflow-hidden flex flex-col transition-all",
                !item.isAvailable && "opacity-65"
              )}
            >
              <div className="relative h-44 bg-zinc-100">
                {item.imageUrl ? (
                  <img src={item.imageUrl} alt={item.name} className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                ) : (
                  <div className="w-full h-full flex items-center justify-center text-zinc-300">
                    <ImageIcon size={36} />
                  </div>
                )}
                <div className="absolute top-3 left-3 flex items-center gap-1.5">
                  <span className="bg-white/95 backdrop-blur px-2.5 py-1 rounded-full text-[11px] font-bold text-zinc-700 shadow-sm">
                    {item.category}
                  </span>
                  {!item.isAvailable && (
                    <span className="bg-rose-600 text-white px-2.5 py-1 rounded-full text-[11px] font-bold shadow-sm">
                      Hidden
                    </span>
                  )}
                </div>
                <div className="absolute top-3 right-3">
                  <VegIndicator veg={item.isVeg} />
                </div>
              </div>

              <div className="p-5 flex-1 flex flex-col">
                <div className="flex items-start justify-between gap-2 mb-1">
                  <h4 className="font-bold text-zinc-900 text-base leading-snug">{item.name}</h4>
                  <span className="text-xs font-semibold text-zinc-400 whitespace-nowrap">Stock: {item.stock}</span>
                </div>
                <p className="text-xs text-zinc-500 line-clamp-2 mb-3 flex-1">{item.description || "No description"}</p>

                {item.keywords.length > 0 && (
                  <div className="flex flex-wrap gap-1 mb-4">
                    {item.keywords.slice(0, 5).map((kw) => (
                      <span key={kw} className="px-2 py-0.5 bg-zinc-100 text-zinc-600 rounded-md text-[10px] font-semibold">
                        #{kw}
                      </span>
                    ))}
                  </div>
                )}

                <div className="flex items-center justify-between pt-3 border-t border-black/5">
                  <div className="flex items-baseline gap-2">
                    <span className="text-lg font-black text-zinc-900">{money(item.sellingPricePaise)}</span>
                    {item.pricePaise > item.sellingPricePaise && (
                      <span className="text-xs text-zinc-400 line-through">{money(item.pricePaise)}</span>
                    )}
                  </div>
                  <div className="flex items-center gap-1.5">
                    <button
                      type="button"
                      onClick={() => toggleAvailability(item)}
                      title={item.isAvailable ? "Hide from menu" : "Show on menu"}
                      className="p-2 rounded-xl bg-zinc-100 text-zinc-600 hover:bg-zinc-200 transition-all"
                    >
                      {item.isAvailable ? <Eye size={15} /> : <EyeOff size={15} />}
                    </button>
                    <button
                      type="button"
                      onClick={() => setEditing(item)}
                      className="px-3.5 py-2 rounded-xl bg-red-50 text-red-600 text-xs font-bold hover:bg-red-100 transition-all"
                    >
                      Edit
                    </button>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {editing && (
        <ItemModal
          item={editing === "new" ? null : editing}
          categories={categories}
          onClose={() => setEditing(null)}
          onSaved={() => {
            setEditing(null);
            load();
          }}
        />
      )}
    </div>
  );
}
