import React, { useEffect, useState } from "react";
import { CheckCircle2 } from "lucide-react";
import { api } from "../api";
import type { RestaurantSettings } from "../types";

export default function SettingsPage({ canAct }: { canAct: boolean }) {
  const [settings, setSettings] = useState<RestaurantSettings | null>(null);
  const [saved, setSaved] = useState(false);
  const [err, setErr] = useState("");
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    api<RestaurantSettings>("/admin/settings")
      .then(setSettings)
      .catch((e: any) => setErr(e?.message || "Failed to load settings"));
  }, []);

  const save = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!settings) return;
    setBusy(true);
    setSaved(false);
    setErr("");
    try {
      const updated = await api<RestaurantSettings>("/admin/settings", { method: "PUT", body: settings });
      setSettings(updated);
      setSaved(true);
    } catch (x: any) {
      setErr(x?.message || "Failed to save settings");
    } finally {
      setBusy(false);
    }
  };

  if (!settings) {
    return <div className="py-12 text-center text-sm text-zinc-400">{err || "Loading settings..."}</div>;
  }

  return (
    <form onSubmit={save} className="max-w-3xl mx-auto space-y-6">
      <div>
        <h3 className="text-xl font-bold text-zinc-900">Restaurant Settings</h3>
        <p className="text-xs text-zinc-500 mt-0.5">
          {canAct ? "Configure store availability, order alerts, and outlet details" : "Read-only view for your role"}
        </p>
      </div>

      <div className="bg-white rounded-3xl border border-black/5 shadow-sm divide-y divide-black/5 overflow-hidden">
        <label className="p-6 flex items-center justify-between gap-4 cursor-pointer">
          <div>
            <h4 className="font-bold text-sm text-zinc-900">Restaurant Status</h4>
            <p className="text-xs text-zinc-500 mt-0.5">Accepting incoming customer orders on the app</p>
          </div>
          <input
            type="checkbox"
            disabled={!canAct}
            checked={settings.restaurantOpen}
            onChange={(e) => setSettings({ ...settings, restaurantOpen: e.target.checked })}
            className="w-5 h-5 accent-emerald-600"
          />
        </label>

        <label className="p-6 flex items-center justify-between gap-4 cursor-pointer">
          <div>
            <h4 className="font-bold text-sm text-zinc-900">Auto-Accept Orders</h4>
            <p className="text-xs text-zinc-500 mt-0.5">Skip manual acceptance when kitchen is operating smoothly</p>
          </div>
          <input
            type="checkbox"
            disabled={!canAct}
            checked={settings.autoAcceptOrders}
            onChange={(e) => setSettings({ ...settings, autoAcceptOrders: e.target.checked })}
            className="w-5 h-5 accent-red-600"
          />
        </label>

        <label className="p-6 flex items-center justify-between gap-4 cursor-pointer">
          <div>
            <h4 className="font-bold text-sm text-zinc-900">Call-Style Order Sound</h4>
            <p className="text-xs text-zinc-500 mt-0.5">Play repeating ringtone when a new order arrives</p>
          </div>
          <input
            type="checkbox"
            disabled={!canAct}
            checked={settings.orderSoundEnabled}
            onChange={(e) => setSettings({ ...settings, orderSoundEnabled: e.target.checked })}
            className="w-5 h-5 accent-red-600"
          />
        </label>
      </div>

      <div className="bg-white rounded-3xl border border-black/5 shadow-sm p-6 grid grid-cols-1 md:grid-cols-2 gap-5">
        <div>
          <label className="text-xs font-bold uppercase text-zinc-500 block mb-1.5">Restaurant Name</label>
          <input
            disabled={!canAct}
            required
            minLength={2}
            placeholder="Enter restaurant name"
            value={settings.restaurantName}
            onChange={(e) => setSettings({ ...settings, restaurantName: e.target.value })}
            className="w-full bg-zinc-50 border border-black/5 rounded-xl px-4 py-3 text-sm outline-none focus:ring-2 focus:ring-red-500 disabled:opacity-60"
          />
        </div>
        <div>
          <label className="text-xs font-bold uppercase text-zinc-500 block mb-1.5">Contact Number</label>
          <input
            disabled={!canAct}
            required
            minLength={6}
            placeholder="Enter support phone number"
            value={settings.restaurantPhone}
            onChange={(e) => setSettings({ ...settings, restaurantPhone: e.target.value })}
            className="w-full bg-zinc-50 border border-black/5 rounded-xl px-4 py-3 text-sm outline-none focus:ring-2 focus:ring-red-500 disabled:opacity-60 tabular-nums"
          />
        </div>
        <div className="md:col-span-2">
          <label className="text-xs font-bold uppercase text-zinc-500 block mb-1.5">Outlet Address</label>
          <input
            disabled={!canAct}
            required
            minLength={5}
            placeholder="Enter full outlet address"
            value={settings.restaurantAddress}
            onChange={(e) => setSettings({ ...settings, restaurantAddress: e.target.value })}
            className="w-full bg-zinc-50 border border-black/5 rounded-xl px-4 py-3 text-sm outline-none focus:ring-2 focus:ring-red-500 disabled:opacity-60"
          />
        </div>

        {err && <p className="md:col-span-2 text-xs font-semibold text-rose-600">{err}</p>}
        {saved && (
          <p className="md:col-span-2 text-xs font-semibold text-emerald-600 flex items-center gap-1.5">
            <CheckCircle2 size={14} /> Settings saved successfully.
          </p>
        )}

        {canAct && (
          <div className="md:col-span-2 flex justify-end">
            <button
              type="submit"
              disabled={busy}
              className="px-7 py-3 rounded-xl bg-red-600 text-white font-bold text-sm hover:bg-red-700 disabled:opacity-50"
            >
              {busy ? "Saving..." : "Save Changes"}
            </button>
          </div>
        )}
      </div>
    </form>
  );
}
