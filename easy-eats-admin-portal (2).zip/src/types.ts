export type StaffRole =
  | "super_admin"
  | "restaurant_manager"
  | "marketing_lead"
  | "customer_support";

export type UserRole = StaffRole | "rider" | "customer";

export interface AuthUser {
  id: string;
  name: string;
  role: StaffRole;
}

export type OrderStatus =
  | "pending_payment"
  | "under_review"
  | "placed"
  | "accepted"
  | "preparing"
  | "out_for_delivery"
  | "delivered"
  | "cancelled"
  | "failed";

export interface AdminOrder {
  id: string;
  status: OrderStatus;
  paymentMethod: "online" | "cod";
  paid: boolean;
  subtotalPaise: number;
  discountPaise: number;
  deliveryPaise: number;
  totalPaise: number;
  createdAt: string;
  placedAt?: string | null;
  rejectReason?: string | null;
  customerName: string;
  riderName?: string | null;
  riskFlags: string[];
}

export interface OrderItemLine {
  name: string;
  qty: number;
  unitPricePaise: number;
}

export interface OrderDetail extends AdminOrder {
  items: OrderItemLine[];
  address: string;
  riskScore: number;
  expiresAt?: string | null;
}

export interface DashboardPeriodStats {
  orders: number;
  delivered: number;
  cancelled: number;
  revenue: number;
}

export interface DashboardData {
  current: DashboardPeriodStats;
  previous: DashboardPeriodStats;
  series: { day: string; orders: number; revenue: number }[];
  top: { name: string; qty: number; revenue: number }[];
  riders: { online: number; total: number };
  queue: { awaiting: number; review: number; active: number; refundsDue: number };
}

export interface CatalogueItem {
  id: string;
  name: string;
  description: string;
  pricePaise: number;
  sellingPricePaise: number;
  isVeg: boolean;
  category: string;
  keywords: string[];
  imageUrl: string | null;
  stock: number;
  isAvailable: boolean;
}

export interface AdminRider {
  id: string;
  name: string;
  phone: string;
  online: boolean;
  blocked: boolean;
  active: number;
  delivered: number;
}

export interface AdminCustomer {
  id: string;
  name: string;
  phone: string;
  joinedAt: string;
  blocked: boolean;
  orders: number;
  spentPaise: number;
}

export interface CustomerDetail {
  id: string;
  name: string;
  phone: string;
  blocked: boolean;
  joinedAt: string;
  orders: Omit<AdminOrder, "customerName" | "riskFlags">[];
}

export interface AdminReview {
  id: string;
  orderId: string;
  customerName: string;
  rating: number;
  comment: string;
  reply: string | null;
  hidden: boolean;
  createdAt: string;
}

export interface ReviewsResponse {
  summary: { count: number; avg: number };
  reviews: AdminReview[];
}

export interface NotificationItem {
  id: string;
  audience: "all" | "one";
  title: string;
  body: string;
  sentCount: number;
  createdAt: string;
}

export interface AdminCoupon {
  code: string;
  discountType: "percentage" | "fixed";
  discountValue: number;
  maxDiscountPaise: number;
  minOrderPaise: number;
  maxRedemptions: number;
  redeemedCount: number;
  expiresAt: string;
  active: boolean;
}

export interface PopupCampaign {
  id: string;
  tag: string;
  title: string;
  description: string;
  buttonText: string;
  imageUrl: string;
  active: boolean;
  createdAt: string;
}

export interface AdminPayment {
  id: string;
  orderId: string;
  amountPaise: number;
  createdAt: string;
  refundId: string | null;
  refundedAt: string | null;
  orderStatus: OrderStatus;
  orderTotalPaise: number;
  refundDue: boolean;
  mismatch: boolean;
}

export interface PaymentsResponse {
  gatewayConfigured: boolean;
  payments: AdminPayment[];
}

export interface StaffMember {
  id: string;
  name: string;
  role: UserRole;
  phone: string;
  blocked: boolean;
  createdAt: string;
}

export interface AuditLogEntry {
  id: number;
  action: string;
  detail: Record<string, unknown>;
  ip: string | null;
  createdAt: string;
  actorName: string | null;
  actorRole: string | null;
}

export interface RestaurantSettings {
  restaurantOpen: boolean;
  autoAcceptOrders: boolean;
  orderSoundEnabled: boolean;
  restaurantName: string;
  restaurantPhone: string;
  restaurantAddress: string;
}
