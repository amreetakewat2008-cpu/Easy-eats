import React, { useEffect, useState } from "react";
import { AlertTriangle, Check, PhoneCall, X } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { api } from "../api";
import { startRing, stopRing } from "../alerts";
import type { OrderDetail } from "../types";
import { money } from "../utils";

const REJECT_REASONS = ["Item unavailable", "Kitchen is closed", "Too busy right now"];

interface Props {
  queue: OrderDetail[];
  onResolved: (id: string) => void;
}

export default function IncomingOrderModal({ queue, onResolved }: Props) {
  const order = queue[0];
  const [now, setNow] = useState(Date.now());
  const [err, setErr] = useState("");
  const [rejecting, setRejecting] = useState(false);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (!order) return;
    startRing();
    const timer = setInterval(() => setNow(Date.now()), 1000);
    return () => {
      stopRing();
      clearInterval(timer);
    };
  }, [order?.id]);

  if (!order) return null;

  const left = order.expiresAt
    ? Math.max(0, Math.floor((new Date(order.expiresAt).getTime() - now) / 1000))
    : null;

  const runAction = async (fn: () => Promise<unknown>) => {
    setBusy(true);
    setErr("");
    try {
      await fn();
      setRejecting(false);
      onResolved(order.id);
    } catch (e: any) {
      setErr(e?.message || "Action failed");
    } finally {
      setBusy(false);
    }
  };

  const accept = () =>
    runAction(() => api(`/orders/${order.id}/status`, { method: "PATCH", body: { to: "accepted" } }));

  const reject = (reason: string) =>
    runAction(() => api(`/admin/orders/${order.id}/reject`, { method: "POST", body: { reason } }));

  return (
    <AnimatePresence>
      <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="absolute inset-0 bg-zinc-950/75 backdrop-blur-md"
        />
        <motion.div
          initial={{ opacity: 0, scale: 0.92, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.92, y: 20 }}
          className="relative z-10 w-full max-w-md bg-white rounded-3xl shadow-2xl p-6 sm:p-8 text-center space-y-5"
        >
          <div className="mx-auto w-20 h-20 rounded-full bg-red-600 text-white flex items-center justify-center shadow-lg shadow-red-600/30 animate-pulse">
            <PhoneCall size={34} />
          </div>

          <div>
            <span className="inline-block px-3 py-1 rounded-full bg-red-50 text-red-600 text-xs font-bold uppercase tracking-wider mb-2">
              Incoming Order
            </span>
            <h2 className="text-2xl font-black text-zinc-900">{order.customerName}</h2>
            <p className="text-sm text-zinc-500 mt-1">
              #{order.id.slice(0, 8)} · {order.paymentMethod === "cod" ? "Cash on delivery" : "Paid online"}
            </p>
          </div>

          <div className="bg-zinc-50 rounded-2xl p-4 text-left space-y-2 max-h-40 overflow-y-auto">
            {order.items.map((item, idx) => (
              <div key={`${item.name}-${idx}`} className="flex items-center justify-between text-sm">
                <span className="font-medium text-zinc-800">
                  {item.qty} × {item.name}
                </span>
                <span className="text-zinc-500 font-semibold">{money(item.unitPricePaise * item.qty)}</span>
              </div>
            ))}
          </div>

          <div>
            <p className="text-3xl font-black text-zinc-900">{money(order.totalPaise)}</p>
            {left !== null && (
              <p className="text-xs font-semibold text-amber-600 mt-1">
                Auto-cancels in {Math.floor(left / 60)}:{String(left % 60).padStart(2, "0")}
              </p>
            )}
            {queue.length > 1 && (
              <p className="text-xs text-zinc-500 mt-1">+{queue.length - 1} more order(s) waiting</p>
            )}
          </div>

          {err && (
            <div className="flex items-center gap-2 text-xs font-medium text-rose-600 bg-rose-50 px-3 py-2 rounded-xl text-left">
              <AlertTriangle size={14} className="flex-shrink-0" />
              <span>{err}</span>
            </div>
          )}

          {rejecting ? (
            <div className="space-y-2">
              <p className="text-xs font-bold uppercase tracking-wider text-zinc-400">Select rejection reason</p>
              {REJECT_REASONS.map((r) => (
                <button
                  key={r}
                  disabled={busy}
                  onClick={() => reject(r)}
                  className="w-full py-2.5 px-4 rounded-xl bg-rose-50 text-rose-700 font-semibold text-sm hover:bg-rose-100 transition-all"
                >
                  {r}
                </button>
              ))}
              <button
                disabled={busy}
                onClick={() => setRejecting(false)}
                className="w-full py-2.5 px-4 rounded-xl text-zinc-500 font-semibold text-sm hover:bg-zinc-100 transition-all"
              >
                Back
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-2 gap-3 pt-1">
              <button
                disabled={busy}
                onClick={() => setRejecting(true)}
                className="flex items-center justify-center gap-2 py-3.5 rounded-2xl bg-rose-50 text-rose-600 font-bold hover:bg-rose-100 transition-all"
              >
                <X size={18} />
                Reject
              </button>
              <button
                disabled={busy}
                onClick={accept}
                className="flex items-center justify-center gap-2 py-3.5 rounded-2xl bg-emerald-600 text-white font-bold hover:bg-emerald-700 shadow-lg shadow-emerald-600/20 transition-all"
              >
                <Check size={18} />
                Accept
              </button>
            </div>
          )}
        </motion.div>
      </div>
    </AnimatePresence>
  );
}
