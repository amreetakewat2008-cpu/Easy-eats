import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";
import type { OrderStatus, StaffRole, UserRole } from "./types";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function money(paise: number): string {
  return (
    "₹" +
    (paise / 100).toLocaleString("en-IN", {
      minimumFractionDigits: 2,
      maximumFractionDigits: 2,
    })
  );
}

export function when(iso: string): string {
  return new Date(iso).toLocaleString("en-IN", {
    day: "numeric",
    month: "short",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });
}

export function statusLabel(s: string): string {
  return s.replace(/_/g, " ");
}

export const STATUS_BADGE: Record<OrderStatus, string> = {
  placed: "bg-amber-50 text-amber-700 border border-amber-200/70",
  under_review: "bg-orange-50 text-orange-700 border border-orange-200/70",
  pending_payment: "bg-zinc-100 text-zinc-600 border border-zinc-200/70",
  accepted: "bg-sky-50 text-sky-700 border border-sky-200/70",
  preparing: "bg-blue-50 text-blue-700 border border-blue-200/70",
  out_for_delivery: "bg-purple-50 text-purple-700 border border-purple-200/70",
  delivered: "bg-emerald-50 text-emerald-700 border border-emerald-200/70",
  cancelled: "bg-rose-50 text-rose-700 border border-rose-200/70",
  failed: "bg-rose-50 text-rose-700 border border-rose-200/70",
};

export const ROLE_LABEL: Record<StaffRole, string> = {
  super_admin: "Super Admin",
  restaurant_manager: "Restaurant Manager",
  marketing_lead: "Marketing Lead",
  customer_support: "Customer Support",
};

export const ALL_ROLE_LABEL: Record<UserRole, string> = {
  ...ROLE_LABEL,
  rider: "Rider",
  customer: "Customer",
};
