import { api } from "./api";

let audioCtx: AudioContext | null = null;
let ringTimer: ReturnType<typeof setInterval> | null = null;

export const audioReady = () => audioCtx?.state === "running";

export function unlockAudio(): Promise<void> {
  const Ctx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
  if (!Ctx) return Promise.resolve();
  if (!audioCtx) audioCtx = new Ctx();
  return audioCtx.resume().catch(() => {});
}

function beep(at: number, freq: number) {
  if (!audioCtx) return;
  const osc = audioCtx.createOscillator();
  const gain = audioCtx.createGain();
  osc.frequency.value = freq;
  osc.connect(gain);
  gain.connect(audioCtx.destination);
  gain.gain.setValueAtTime(0.0001, at);
  gain.gain.exponentialRampToValueAtTime(0.45, at + 0.03);
  gain.gain.exponentialRampToValueAtTime(0.0001, at + 0.35);
  osc.start(at);
  osc.stop(at + 0.4);
}

export function startRing() {
  if (ringTimer || !audioReady() || !audioCtx) return;
  const play = () => {
    if (!audioCtx) return;
    const t = audioCtx.currentTime;
    beep(t, 880);
    beep(t + 0.45, 660);
    beep(t + 0.9, 880);
    navigator.vibrate?.([300, 150, 300]);
  };
  play();
  ringTimer = setInterval(play, 2200);
}

export function stopRing() {
  if (ringTimer) {
    clearInterval(ringTimer);
    ringTimer = null;
  }
}

const b64ToU8 = (s: string) =>
  Uint8Array.from(atob(s.replace(/-/g, "+").replace(/_/g, "/")), (c) => c.charCodeAt(0));

export async function enablePush(): Promise<boolean> {
  if (!("serviceWorker" in navigator) || !("PushManager" in window) || typeof Notification === "undefined") {
    return false;
  }
  const perm = await Notification.requestPermission().catch(() => "denied" as NotificationPermission);
  if (perm !== "granted") return false;
  const { key } = await api<{ key: string | null }>("/admin/push/key").catch(() => ({ key: null }));
  if (!key) return true;
  try {
    const reg = await navigator.serviceWorker.ready;
    const sub =
      (await reg.pushManager.getSubscription()) ??
      (await reg.pushManager.subscribe({ userVisibleOnly: true, applicationServerKey: b64ToU8(key) }));
    await api("/admin/push/subscribe", { method: "POST", body: sub.toJSON() });
  } catch {
    // Push subscription optional in dev preview
  }
  return true;
}
