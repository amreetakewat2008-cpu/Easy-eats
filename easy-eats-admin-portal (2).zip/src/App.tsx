import React, { useCallback, useEffect, useRef, useState } from "react";
import {
  Bell,
  Bike,
  CreditCard,
  LayoutDashboard,
  Lock,
  LogOut,
  Megaphone,
  Menu,
  Package,
  Search,
  Settings,
  ShieldCheck,
  ShoppingBag,
  Star,
  Users,
  Volume2,
  X,
} from "lucide-react";
import { AnimatePresence, motion } from "motion/react";
import {
  api,
  getSetupStatus,
  login,
  logout,
  onSessionExpired,
  openStream,
  restoreSession,
  setupSuperAdmin,
} from "./api";
import { audioReady, enablePush, unlockAudio } from "./alerts";
import IncomingOrderModal from "./components/IncomingOrderModal";
import CataloguePage from "./pages/CataloguePage";
import CustomersPage from "./pages/CustomersPage";
import DashboardPage from "./pages/DashboardPage";
import MarketingPage from "./pages/MarketingPage";
import NotificationsPage from "./pages/NotificationsPage";
import OrdersPage from "./pages/OrdersPage";
import PaymentsPage from "./pages/PaymentsPage";
import ReviewsPage from "./pages/ReviewsPage";
import RidersPage from "./pages/RidersPage";
import SettingsPage from "./pages/SettingsPage";
import StaffPage from "./pages/StaffPage";
import type { AdminOrder, AuthUser, OrderDetail, StaffRole } from "./types";
import { ROLE_LABEL, cn } from "./utils";

type ViewId =
  | "dashboard"
  | "orders"
  | "catalogue"
  | "riders"
  | "customers"
  | "marketing"
  | "reviews"
  | "payments"
  | "staff"
  | "notifications"
  | "settings";

const ALL_STAFF: StaffRole[] = ["super_admin", "restaurant_manager", "marketing_lead", "customer_support"];
const KITCHEN: StaffRole[] = ["super_admin", "restaurant_manager"];

interface NavItem {
  id: ViewId;
  label: string;
  icon: React.ComponentType<{ size?: number; className?: string }>;
  roles: StaffRole[];
  section?: "main" | "footer";
}

const NAV_ITEMS: NavItem[] = [
  { id: "dashboard", label: "Dashboard", icon: LayoutDashboard, roles: ALL_STAFF, section: "main" },
  { id: "orders", label: "Orders", icon: ShoppingBag, roles: [...KITCHEN, "customer_support"], section: "main" },
  { id: "catalogue", label: "Catalogue", icon: Package, roles: KITCHEN, section: "main" },
  { id: "riders", label: "Riders", icon: Bike, roles: KITCHEN, section: "main" },
  { id: "customers", label: "Customers", icon: Users, roles: ["super_admin", "customer_support"], section: "main" },
  { id: "marketing", label: "Marketing", icon: Megaphone, roles: ["super_admin", "marketing_lead"], section: "main" },
  { id: "reviews", label: "Reviews", icon: Star, roles: [...KITCHEN, "customer_support"], section: "main" },
  { id: "payments", label: "Payments", icon: CreditCard, roles: ["super_admin"], section: "main" },
  { id: "staff", label: "Staff", icon: ShieldCheck, roles: ["super_admin"], section: "main" },
  { id: "notifications", label: "Notifications", icon: Bell, roles: ALL_STAFF, section: "footer" },
  { id: "settings", label: "Settings", icon: Settings, roles: ALL_STAFF, section: "footer" },
];

const BRAND_LOGO = "/assets/aistudio/3_20261120_104527_0002_61f06ce0.png";

function InitialSetupScreen({ onComplete }: { onComplete: (user: AuthUser) => void }) {
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [err, setErr] = useState("");
  const [busy, setBusy] = useState(false);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErr("");
    const cleanPhone = phone.trim();
    if (!/^[6-9]\d{9}$/.test(cleanPhone)) {
      setErr("Enter a valid 10-digit Indian mobile number.");
      return;
    }
    if (password.length < 10) {
      setErr("Password must be at least 10 characters.");
      return;
    }
    if (password !== confirmPassword) {
      setErr("Passwords do not match.");
      return;
    }
    unlockAudio();
    setBusy(true);
    try {
      const user = await setupSuperAdmin(name.trim(), cleanPhone, password);
      onComplete(user);
    } catch (x: any) {
      setErr(x?.message || "Could not create Super Admin account");
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#F5F5F5] flex items-center justify-center p-4">
      <div className="w-full max-w-md bg-white rounded-3xl border border-black/5 shadow-xl p-8 space-y-6">
        <div className="text-center space-y-2.5">
          <img
            src={BRAND_LOGO}
            alt="EasyEats"
            className="w-16 h-16 rounded-2xl object-cover mx-auto shadow-lg shadow-red-600/20"
          />
          <h1 className="text-2xl font-black tracking-tight text-zinc-900">Create Super Admin</h1>
          <p className="text-xs text-zinc-500">
            One-time setup for your Easy Admin workspace. This screen locks permanently after creation.
          </p>
        </div>

        <form onSubmit={submit} className="space-y-4">
          <div>
            <label className="text-xs font-bold uppercase text-zinc-500 block mb-1.5">Full Name</label>
            <input
              type="text"
              autoComplete="name"
              placeholder="Enter full name"
              minLength={2}
              maxLength={60}
              value={name}
              onChange={(e) => setName(e.target.value)}
              required
              className="w-full bg-zinc-50 border border-black/10 rounded-xl px-4 py-3 text-sm outline-none focus:ring-2 focus:ring-red-500"
            />
          </div>
          <div>
            <label className="text-xs font-bold uppercase text-zinc-500 block mb-1.5">Mobile Number</label>
            <input
              type="text"
              inputMode="numeric"
              autoComplete="username"
              placeholder="10-digit mobile number"
              maxLength={10}
              value={phone}
              onChange={(e) => setPhone(e.target.value.replace(/\D/g, ""))}
              required
              className="w-full bg-zinc-50 border border-black/10 rounded-xl px-4 py-3 text-sm outline-none focus:ring-2 focus:ring-red-500 tabular-nums"
            />
          </div>
          <div>
            <label className="text-xs font-bold uppercase text-zinc-500 block mb-1.5">Password (10+ characters)</label>
            <input
              type="password"
              autoComplete="new-password"
              placeholder="Create a strong password"
              minLength={10}
              maxLength={72}
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
              className="w-full bg-zinc-50 border border-black/10 rounded-xl px-4 py-3 text-sm outline-none focus:ring-2 focus:ring-red-500"
            />
          </div>
          <div>
            <label className="text-xs font-bold uppercase text-zinc-500 block mb-1.5">Confirm Password</label>
            <input
              type="password"
              autoComplete="new-password"
              placeholder="Re-enter password"
              minLength={10}
              maxLength={72}
              value={confirmPassword}
              onChange={(e) => setConfirmPassword(e.target.value)}
              required
              className="w-full bg-zinc-50 border border-black/10 rounded-xl px-4 py-3 text-sm outline-none focus:ring-2 focus:ring-red-500"
            />
          </div>

          {err && (
            <div className="p-3 rounded-xl bg-rose-50 text-rose-700 text-xs font-semibold flex items-center gap-2">
              <Lock size={14} className="flex-shrink-0" />
              <span>{err}</span>
            </div>
          )}

          <button
            type="submit"
            disabled={busy}
            className="w-full py-3.5 rounded-xl bg-red-600 text-white font-bold text-sm hover:bg-red-700 transition-all shadow-md shadow-red-600/15 disabled:opacity-50"
          >
            {busy ? "Creating Account..." : "Create Super Admin & Sign In"}
          </button>
        </form>
      </div>
    </div>
  );
}

function LoginScreen({ onLogin }: { onLogin: (user: AuthUser) => void }) {
  const [identifier, setIdentifier] = useState("");
  const [password, setPassword] = useState("");
  const [err, setErr] = useState("");
  const [busy, setBusy] = useState(false);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    unlockAudio();
    setBusy(true);
    setErr("");
    try {
      const user = await login(identifier.trim(), password);
      onLogin(user);
    } catch (x: any) {
      setErr(x?.message || "Invalid credentials");
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#F5F5F5] flex items-center justify-center p-4">
      <div className="w-full max-w-md bg-white rounded-3xl border border-black/5 shadow-xl p-8 space-y-6">
        <div className="text-center space-y-2.5">
          <img
            src={BRAND_LOGO}
            alt="EasyEats"
            className="w-16 h-16 rounded-2xl object-cover mx-auto shadow-lg shadow-red-600/20"
          />
          <h1 className="text-2xl font-black tracking-tight text-red-600">Easy Admin</h1>
          <p className="text-xs text-zinc-500">Staff portal sign in · Role-based access & encrypted sessions</p>
        </div>

        <form onSubmit={submit} className="space-y-4">
          <div>
            <label className="text-xs font-bold uppercase text-zinc-500 block mb-1.5">Mobile Number or Username</label>
            <input
              type="text"
              autoComplete="username"
              placeholder="Mobile number or username"
              maxLength={60}
              value={identifier}
              onChange={(e) => setIdentifier(e.target.value)}
              required
              className="w-full bg-zinc-50 border border-black/10 rounded-xl px-4 py-3 text-sm outline-none focus:ring-2 focus:ring-red-500"
            />
          </div>
          <div>
            <label className="text-xs font-bold uppercase text-zinc-500 block mb-1.5">Password</label>
            <input
              type="password"
              autoComplete="current-password"
              placeholder="Enter password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
              className="w-full bg-zinc-50 border border-black/10 rounded-xl px-4 py-3 text-sm outline-none focus:ring-2 focus:ring-red-500"
            />
          </div>

          {err && (
            <div className="p-3 rounded-xl bg-rose-50 text-rose-700 text-xs font-semibold flex items-center gap-2">
              <Lock size={14} className="flex-shrink-0" />
              <span>{err}</span>
            </div>
          )}

          <button
            type="submit"
            disabled={busy}
            className="w-full py-3.5 rounded-xl bg-red-600 text-white font-bold text-sm hover:bg-red-700 transition-all shadow-md shadow-red-600/15 disabled:opacity-50"
          >
            {busy ? "Signing in..." : "Sign In"}
          </button>
        </form>
      </div>
    </div>
  );
}

function AdminShell({ me, onLogout }: { me: AuthUser; onLogout: () => void }) {
  const allowedNav = NAV_ITEMS.filter((item) => item.roles.includes(me.role));
  const mainNav = allowedNav.filter((item) => item.section === "main");
  const footerNav = allowedNav.filter((item) => item.section === "footer");

  const [activeView, setActiveView] = useState<ViewId>("dashboard");
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [showSearchDropdown, setShowSearchDropdown] = useState(false);
  const [tick, setTick] = useState(0);
  const [queue, setQueue] = useState<OrderDetail[]>([]);
  const [alertsEnabled, setAlertsEnabled] = useState(() => audioReady());
  const queueRef = useRef<OrderDetail[]>([]);
  queueRef.current = queue;

  const canAct = KITCHEN.includes(me.role);
  const currentView = allowedNav.some((n) => n.id === activeView) ? activeView : allowedNav[0].id;

  const addIncomingOrder = useCallback(async (id: string) => {
    try {
      const card = await api<OrderDetail>(`/admin/orders/${id}`);
      if (card.status === "placed") {
        setQueue((q) => (q.some((x) => x.id === id) ? q : [...q, card]));
      }
    } catch {
      // Retry on next poll
    }
  }, []);

  useEffect(() => {
    if (!canAct) return;
    const poll = async () => {
      try {
        const list = await api<AdminOrder[]>("/admin/orders?status=placed");
        for (const o of list) {
          if (!queueRef.current.some((x) => x.id === o.id)) {
            await addIncomingOrder(o.id);
          }
        }
      } catch {
        // Retry next interval
      }
    };
    poll();
    const interval = setInterval(poll, 15_000);
    const stopStream = openStream((ev, data) => {
      if (ev === "new_order" && data?.id) {
        setQueue((q) => (q.some((x) => x.id === data.id) ? q : [...q, data]));
      }
      if (ev === "order_status" && data?.id) {
        setQueue((q) => q.filter((x) => x.id !== data.id));
      }
      setTick((n) => n + 1);
    });
    return () => {
      clearInterval(interval);
      stopStream();
    };
  }, [canAct, addIncomingOrder]);

  const filteredSearchViews = allowedNav.filter((v) =>
    v.label.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleTurnOnAlerts = async () => {
    await unlockAudio();
    await enablePush().catch(() => {});
    setAlertsEnabled(true);
  };

  return (
    <div className="flex h-screen bg-[#F5F5F5] text-[#1A1A1A] font-sans overflow-hidden">
      {/* Mobile Sidebar Backdrop */}
      {isMobileMenuOpen && (
        <div
          className="fixed inset-0 bg-black/25 backdrop-blur-sm z-40 lg:hidden"
          onClick={() => setIsMobileMenuOpen(false)}
        />
      )}

      {/* Sidebar */}
      <aside
        className={cn(
          "fixed inset-y-0 left-0 z-50 w-64 bg-white border-r border-black/5 flex flex-col transition-transform duration-300 lg:relative lg:translate-x-0",
          isMobileMenuOpen ? "translate-x-0" : "-translate-x-full"
        )}
      >
        <div className="p-5 border-b border-black/5 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <img
              src={BRAND_LOGO}
              alt="EasyEats"
              className="w-10 h-10 rounded-xl object-cover shadow-sm flex-shrink-0"
            />
            <span className="text-lg font-black tracking-tight text-red-600 whitespace-nowrap">Easy Admin</span>
          </div>
          <button
            className="lg:hidden text-zinc-500 hover:text-zinc-900"
            onClick={() => setIsMobileMenuOpen(false)}
          >
            <X size={20} />
          </button>
        </div>

        <nav className="flex-1 p-4 space-y-1 overflow-y-auto">
          {mainNav.map((item) => {
            const Icon = item.icon;
            return (
              <button
                key={item.id}
                onClick={() => {
                  setActiveView(item.id);
                  setIsMobileMenuOpen(false);
                }}
                className={cn(
                  "w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-semibold transition-all",
                  currentView === item.id
                    ? "bg-red-50 text-red-600 shadow-sm"
                    : "text-zinc-500 hover:bg-zinc-50 hover:text-zinc-900"
                )}
              >
                <Icon size={18} />
                {item.label}
              </button>
            );
          })}
        </nav>

        <div className="p-4 border-t border-black/5 space-y-1">
          {footerNav.map((item) => {
            const Icon = item.icon;
            return (
              <button
                key={item.id}
                onClick={() => {
                  setActiveView(item.id);
                  setIsMobileMenuOpen(false);
                }}
                className={cn(
                  "w-full flex items-center gap-3 px-4 py-2.5 rounded-xl text-sm font-semibold transition-all",
                  currentView === item.id
                    ? "bg-red-50 text-red-600 shadow-sm"
                    : "text-zinc-500 hover:bg-zinc-50 hover:text-zinc-900"
                )}
              >
                <Icon size={18} />
                {item.label}
              </button>
            );
          })}
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 overflow-y-auto w-full flex flex-col">
        <header className="h-16 bg-white border-b border-black/5 flex items-center justify-between px-4 lg:px-8 sticky top-0 z-20 flex-shrink-0">
          <div className="flex items-center gap-3">
            <button
              className="lg:hidden p-2 -ml-2 text-zinc-500 hover:text-zinc-900"
              onClick={() => setIsMobileMenuOpen(true)}
            >
              <Menu size={20} />
            </button>
            <h2 className="text-lg font-bold capitalize text-zinc-900">
              {allowedNav.find((n) => n.id === currentView)?.label || currentView}
            </h2>
          </div>

          <div className="flex items-center gap-3">
            {/* Search Navigation */}
            <div className="relative hidden sm:block">
              <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 text-zinc-400" size={15} />
              <input
                type="text"
                placeholder="Jump to section..."
                value={searchQuery}
                onChange={(e) => {
                  setSearchQuery(e.target.value);
                  setShowSearchDropdown(true);
                }}
                onFocus={() => setShowSearchDropdown(true)}
                onBlur={() => setTimeout(() => setShowSearchDropdown(false), 180)}
                className="pl-10 pr-4 py-2 bg-zinc-100 border-none rounded-full text-xs w-44 lg:w-60 focus:ring-2 focus:ring-red-500 outline-none transition-all"
              />
              <AnimatePresence>
                {showSearchDropdown && searchQuery && (
                  <motion.div
                    initial={{ opacity: 0, y: 8 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: 8 }}
                    className="absolute top-full mt-2 w-full bg-white rounded-2xl shadow-xl border border-black/5 overflow-hidden z-50"
                  >
                    {filteredSearchViews.length > 0 ? (
                      <div className="py-1.5">
                        {filteredSearchViews.map((v) => {
                          const Icon = v.icon;
                          return (
                            <button
                              key={v.id}
                              onClick={() => {
                                setActiveView(v.id);
                                setSearchQuery("");
                                setShowSearchDropdown(false);
                              }}
                              className="w-full flex items-center gap-2.5 px-4 py-2 text-xs font-semibold text-zinc-700 hover:bg-zinc-50"
                            >
                              <Icon size={14} className="text-zinc-400" />
                              {v.label}
                            </button>
                          );
                        })}
                      </div>
                    ) : (
                      <div className="p-3 text-center text-xs text-zinc-400">No matching section</div>
                    )}
                  </motion.div>
                )}
              </AnimatePresence>
            </div>

            {/* Signed-in Staff Pill */}
            <div className="flex items-center gap-2.5 bg-zinc-100 pl-3 pr-2 py-1.5 rounded-full">
              <div className="text-right hidden md:block">
                <p className="text-xs font-bold text-zinc-900 leading-none">{me.name}</p>
                <p className="text-[10px] font-semibold text-red-600 leading-none mt-0.5">{ROLE_LABEL[me.role]}</p>
              </div>
              <button
                onClick={onLogout}
                title="Sign out"
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-white text-zinc-700 hover:text-red-600 text-xs font-bold shadow-xs transition-all"
              >
                <LogOut size={13} />
                <span className="hidden sm:inline">Sign out</span>
              </button>
            </div>
          </div>
        </header>

        {canAct && !alertsEnabled && (
          <div className="bg-amber-50 border-b border-amber-200 px-4 lg:px-8 py-2.5 flex items-center justify-between gap-3">
            <div className="flex items-center gap-2 text-xs font-semibold text-amber-900">
              <Volume2 size={15} className="text-amber-600 flex-shrink-0" />
              <span>Turn on live audio alerts so incoming orders ring like a phone call.</span>
            </div>
            <button
              onClick={handleTurnOnAlerts}
              className="px-3.5 py-1.5 rounded-xl bg-red-600 text-white text-xs font-bold hover:bg-red-700 flex-shrink-0"
            >
              Turn on
            </button>
          </div>
        )}

        <div className="p-4 lg:p-8 flex-1">
          {currentView === "dashboard" && <DashboardPage tick={tick} />}
          {currentView === "orders" && <OrdersPage tick={tick} canAct={canAct} />}
          {currentView === "catalogue" && <CataloguePage />}
          {currentView === "riders" && <RidersPage tick={tick} />}
          {currentView === "customers" && <CustomersPage />}
          {currentView === "marketing" && <MarketingPage />}
          {currentView === "reviews" && <ReviewsPage />}
          {currentView === "payments" && <PaymentsPage />}
          {currentView === "staff" && <StaffPage me={me} />}
          {currentView === "notifications" && <NotificationsPage />}
          {currentView === "settings" && <SettingsPage canAct={canAct} />}
        </div>
      </main>

      {canAct && (
        <IncomingOrderModal
          queue={queue}
          onResolved={(id) => {
            setQueue((q) => q.filter((x) => x.id !== id));
            setTick((n) => n + 1);
          }}
        />
      )}
    </div>
  );
}

export default function App() {
  const [me, setMe] = useState<AuthUser | null | undefined>(undefined);
  const [needsSetup, setNeedsSetup] = useState<boolean>(false);

  useEffect(() => {
    onSessionExpired(() => setMe(null));
    Promise.all([restoreSession(), getSetupStatus()])
      .then(([user, status]) => {
        setNeedsSetup(status.needsSetup);
        setMe(user);
      })
      .catch(() => {
        setMe(null);
      });
  }, []);

  if (me === undefined) {
    return (
      <div className="flex h-screen items-center justify-center bg-[#F5F5F5]">
        <div className="flex flex-col items-center gap-3">
          <div className="w-10 h-10 border-4 border-red-200 border-t-red-600 rounded-full animate-spin" />
          <p className="text-sm font-medium text-zinc-500">Checking session...</p>
        </div>
      </div>
    );
  }

  if (!me) {
    if (needsSetup) {
      return (
        <InitialSetupScreen
          onComplete={(user) => {
            setNeedsSetup(false);
            setMe(user);
          }}
        />
      );
    }
    return <LoginScreen onLogin={setMe} />;
  }

  return (
    <AdminShell
      me={me}
      onLogout={async () => {
        await logout();
        setMe(null);
      }}
    />
  );
}
